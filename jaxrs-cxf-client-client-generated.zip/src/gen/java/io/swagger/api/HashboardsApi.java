package io.swagger.api;

import io.swagger.model.AsicStatsResponse;
import io.swagger.model.HashboardStats;
import io.swagger.model.HashboardsInfo;
import io.swagger.model.LogsResponse;
import io.swagger.model.MessageResponse;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Mining Development Kit API
 *
 * <p>The Mining Development Kit API serves as a means to access information from the mining device and make necessary adjustments to its settings.
 *
 */
@Path("/")
public interface HashboardsApi  {

    @GET
    @Path("/api/v1/hashboards")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "All hashboard information", content = @Content(mediaType = "application/json", schema = @Schema(implementation = HashboardsInfo.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public HashboardsInfo getAllHashboards();

    @GET
    @Path("/api/v1/hashboards/{hb_sn}/{asic_id}")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successfully returned the statistics for the specified ASIC on specified hashboard.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = AsicStatsResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "422", description = "Unprocessable request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public AsicStatsResponse getAsicStatus(@PathParam("hb_sn") String hbSn, @PathParam("asic_id") String asicId);

    @GET
    @Path("/api/v1/hashboards/{hb_sn}/logs")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successfully returned the statistics information for the specified hashboard.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = LogsResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "422", description = "Unprocessable request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public LogsResponse getHashboardLogs(@PathParam("hb_sn") String hbSn, @QueryParam("lines")@DefaultValue("100") Integer lines);

    @GET
    @Path("/api/v1/hashboards/{hb_sn}")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successfully returned the statistics information for the specified hashboard.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = HashboardStats.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public HashboardStats getHashboardStatus(@PathParam("hb_sn") String hbSn);
}
