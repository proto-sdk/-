package io.swagger.api;

import io.swagger.model.MessageResponse;
import io.swagger.model.TemperatureResponse;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Mining Development Kit API
 *
 * <p>The Mining Development Kit API serves as a means to access information from the mining device and make necessary adjustments to its settings.
 *
 */
@Path("/")
public interface TemperatureApi  {

    @GET
    @Path("/api/v1/temperature/{hb_sn}/{asic_id}")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successfully returned the requested ASIC-level temperature data.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TemperatureResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public TemperatureResponse getAsicTemperature(@PathParam("hb_sn") String hbSn, @PathParam("asic_id") Integer asicId, @QueryParam("duration")@DefaultValue("12h") String duration, @QueryParam("granularity")@DefaultValue("1m") String granularity);

    @GET
    @Path("/api/v1/temperature/{hb_sn}")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successfully returned the requested miner-level temperature data.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TemperatureResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "422", description = "Unprocessable request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public TemperatureResponse getHashboardTemperature(@PathParam("hb_sn") String hbSn, @QueryParam("duration")@DefaultValue("12h") String duration);

    @GET
    @Path("/api/v1/temperature")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successfully returned the requested miner-level temperature data.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = TemperatureResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public TemperatureResponse getMinerTemperature(@QueryParam("duration")@DefaultValue("12h") String duration);
}
