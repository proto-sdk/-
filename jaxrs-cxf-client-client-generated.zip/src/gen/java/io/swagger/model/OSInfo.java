package io.swagger.model;

import io.swagger.model.OSStatus;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class OSInfo   {
  
  @Schema(example = "BTCM Linux Distribution", description = "")
  private String name = null;
  
  @Schema(example = "1.0.1", description = "")
  private String version = null;
  
  @Schema(example = "1213423223", description = "")
  private String gitHash = null;
  public enum VariantEnum {
    RELEASE("release"),
    MFG("mfg"),
    DEV("dev"),
    UNKNOWN("unknown");

    private String value;

    VariantEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static VariantEnum fromValue(String text) {
      for (VariantEnum b : VariantEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(example = "release", description = "")
  private VariantEnum variant = null;
  
  @Schema(example = "20231208T220633Z", description = "")
  private String buildDatetimeUtc = null;
  
  @Schema(example = "btcm-c1-p0", description = "")
  private String machine = null;
  
  @Schema(description = "")
  private OSStatus status = null;
 /**
   * Get name
   * @return name
  **/
  @JsonProperty("name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public OSInfo name(String name) {
    this.name = name;
    return this;
  }

 /**
   * Get version
   * @return version
  **/
  @JsonProperty("version")
  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public OSInfo version(String version) {
    this.version = version;
    return this;
  }

 /**
   * Get gitHash
   * @return gitHash
  **/
  @JsonProperty("git_hash")
  public String getGitHash() {
    return gitHash;
  }

  public void setGitHash(String gitHash) {
    this.gitHash = gitHash;
  }

  public OSInfo gitHash(String gitHash) {
    this.gitHash = gitHash;
    return this;
  }

 /**
   * Get variant
   * @return variant
  **/
  @JsonProperty("variant")
  public String getVariant() {
    if (variant == null) {
      return null;
    }
    return variant.getValue();
  }

  public void setVariant(VariantEnum variant) {
    this.variant = variant;
  }

  public OSInfo variant(VariantEnum variant) {
    this.variant = variant;
    return this;
  }

 /**
   * Get buildDatetimeUtc
   * @return buildDatetimeUtc
  **/
  @JsonProperty("build_datetime_utc")
  public String getBuildDatetimeUtc() {
    return buildDatetimeUtc;
  }

  public void setBuildDatetimeUtc(String buildDatetimeUtc) {
    this.buildDatetimeUtc = buildDatetimeUtc;
  }

  public OSInfo buildDatetimeUtc(String buildDatetimeUtc) {
    this.buildDatetimeUtc = buildDatetimeUtc;
    return this;
  }

 /**
   * Get machine
   * @return machine
  **/
  @JsonProperty("machine")
  public String getMachine() {
    return machine;
  }

  public void setMachine(String machine) {
    this.machine = machine;
  }

  public OSInfo machine(String machine) {
    this.machine = machine;
    return this;
  }

 /**
   * Get status
   * @return status
  **/
  @JsonProperty("status")
  public OSStatus getStatus() {
    return status;
  }

  public void setStatus(OSStatus status) {
    this.status = status;
  }

  public OSInfo status(OSStatus status) {
    this.status = status;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OSInfo {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    gitHash: ").append(toIndentedString(gitHash)).append("\n");
    sb.append("    variant: ").append(toIndentedString(variant)).append("\n");
    sb.append("    buildDatetimeUtc: ").append(toIndentedString(buildDatetimeUtc)).append("\n");
    sb.append("    machine: ").append(toIndentedString(machine)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
