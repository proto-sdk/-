package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class OSStatus   {
  
  @Schema(example = "233712", description = "")
  private Integer memTotalKb = null;
  
  @Schema(example = "192784", description = "")
  private Integer memFreeKb = null;
  
  @Schema(example = "30.2", description = "")
  private BigDecimal cpuLoadPercent = null;
  
  @Schema(example = "1024", description = "")
  private Integer rootfsTotalMb = null;
  
  @Schema(example = "600", description = "")
  private Integer rootfsFreeMb = null;
 /**
   * Get memTotalKb
   * @return memTotalKb
  **/
  @JsonProperty("mem_total_kb")
  public Integer getMemTotalKb() {
    return memTotalKb;
  }

  public void setMemTotalKb(Integer memTotalKb) {
    this.memTotalKb = memTotalKb;
  }

  public OSStatus memTotalKb(Integer memTotalKb) {
    this.memTotalKb = memTotalKb;
    return this;
  }

 /**
   * Get memFreeKb
   * @return memFreeKb
  **/
  @JsonProperty("mem_free_kb")
  public Integer getMemFreeKb() {
    return memFreeKb;
  }

  public void setMemFreeKb(Integer memFreeKb) {
    this.memFreeKb = memFreeKb;
  }

  public OSStatus memFreeKb(Integer memFreeKb) {
    this.memFreeKb = memFreeKb;
    return this;
  }

 /**
   * Get cpuLoadPercent
   * @return cpuLoadPercent
  **/
  @JsonProperty("cpu_load_percent")
  public BigDecimal getCpuLoadPercent() {
    return cpuLoadPercent;
  }

  public void setCpuLoadPercent(BigDecimal cpuLoadPercent) {
    this.cpuLoadPercent = cpuLoadPercent;
  }

  public OSStatus cpuLoadPercent(BigDecimal cpuLoadPercent) {
    this.cpuLoadPercent = cpuLoadPercent;
    return this;
  }

 /**
   * Get rootfsTotalMb
   * @return rootfsTotalMb
  **/
  @JsonProperty("rootfs_total_mb")
  public Integer getRootfsTotalMb() {
    return rootfsTotalMb;
  }

  public void setRootfsTotalMb(Integer rootfsTotalMb) {
    this.rootfsTotalMb = rootfsTotalMb;
  }

  public OSStatus rootfsTotalMb(Integer rootfsTotalMb) {
    this.rootfsTotalMb = rootfsTotalMb;
    return this;
  }

 /**
   * Get rootfsFreeMb
   * @return rootfsFreeMb
  **/
  @JsonProperty("rootfs_free_mb")
  public Integer getRootfsFreeMb() {
    return rootfsFreeMb;
  }

  public void setRootfsFreeMb(Integer rootfsFreeMb) {
    this.rootfsFreeMb = rootfsFreeMb;
  }

  public OSStatus rootfsFreeMb(Integer rootfsFreeMb) {
    this.rootfsFreeMb = rootfsFreeMb;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OSStatus {\n");
    
    sb.append("    memTotalKb: ").append(toIndentedString(memTotalKb)).append("\n");
    sb.append("    memFreeKb: ").append(toIndentedString(memFreeKb)).append("\n");
    sb.append("    cpuLoadPercent: ").append(toIndentedString(cpuLoadPercent)).append("\n");
    sb.append("    rootfsTotalMb: ").append(toIndentedString(rootfsTotalMb)).append("\n");
    sb.append("    rootfsFreeMb: ").append(toIndentedString(rootfsFreeMb)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
