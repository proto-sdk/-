package io.swagger.model;


import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class PoolConfigResponseInner   {
  
  @Schema(example = "pool1.com:3333", description = "The pool URL is used to establish communication with the mining pool and it is essential that it includes the port information.")
 /**
   * The pool URL is used to establish communication with the mining pool and it is essential that it includes the port information.  
  **/
  private String url = null;
  
  @Schema(example = "user1", description = "The user is an account that is used for authentication with the mining pool. In some cases, if the user has multiple mining devices, the pool may assign a worker name as the username for each mining device.")
 /**
   * The user is an account that is used for authentication with the mining pool. In some cases, if the user has multiple mining devices, the pool may assign a worker name as the username for each mining device.  
  **/
  private String username = null;
  
  @Schema(description = "Connection priority for this pool. Lower numbers are higher priorities, with 0 being the maximum.")
 /**
   * Connection priority for this pool. Lower numbers are higher priorities, with 0 being the maximum.  
  **/
  private Integer priority = null;
 /**
   * The pool URL is used to establish communication with the mining pool and it is essential that it includes the port information.
   * @return url
  **/
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public PoolConfigResponseInner url(String url) {
    this.url = url;
    return this;
  }

 /**
   * The user is an account that is used for authentication with the mining pool. In some cases, if the user has multiple mining devices, the pool may assign a worker name as the username for each mining device.
   * @return username
  **/
  @JsonProperty("username")
  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public PoolConfigResponseInner username(String username) {
    this.username = username;
    return this;
  }

 /**
   * Connection priority for this pool. Lower numbers are higher priorities, with 0 being the maximum.
   * @return priority
  **/
  @JsonProperty("priority")
  public Integer getPriority() {
    return priority;
  }

  public void setPriority(Integer priority) {
    this.priority = priority;
  }

  public PoolConfigResponseInner priority(Integer priority) {
    this.priority = priority;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PoolConfigResponseInner {\n");
    
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    priority: ").append(toIndentedString(priority)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
