package io.swagger.model;


import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class NetworkInfoNetworkinfo   {
  
  @Schema(example = "82:11:D2:94:0D:6D", description = "")
  private String mac = null;
  
  @Schema(example = "true", description = "")
  private Boolean dhcp = null;
  
  @Schema(example = "172.27.244.179", description = "")
  private String ip = null;
  
  @Schema(example = "255.255.255.240", description = "")
  private String netmask = null;
  
  @Schema(example = "172.27.244.177", description = "")
  private String gateway = null;
 /**
   * Get mac
   * @return mac
  **/
  @JsonProperty("mac")
  public String getMac() {
    return mac;
  }

  public void setMac(String mac) {
    this.mac = mac;
  }

  public NetworkInfoNetworkinfo mac(String mac) {
    this.mac = mac;
    return this;
  }

 /**
   * Get dhcp
   * @return dhcp
  **/
  @JsonProperty("dhcp")
  public Boolean isDhcp() {
    return dhcp;
  }

  public void setDhcp(Boolean dhcp) {
    this.dhcp = dhcp;
  }

  public NetworkInfoNetworkinfo dhcp(Boolean dhcp) {
    this.dhcp = dhcp;
    return this;
  }

 /**
   * Get ip
   * @return ip
  **/
  @JsonProperty("ip")
  public String getIp() {
    return ip;
  }

  public void setIp(String ip) {
    this.ip = ip;
  }

  public NetworkInfoNetworkinfo ip(String ip) {
    this.ip = ip;
    return this;
  }

 /**
   * Get netmask
   * @return netmask
  **/
  @JsonProperty("netmask")
  public String getNetmask() {
    return netmask;
  }

  public void setNetmask(String netmask) {
    this.netmask = netmask;
  }

  public NetworkInfoNetworkinfo netmask(String netmask) {
    this.netmask = netmask;
    return this;
  }

 /**
   * Get gateway
   * @return gateway
  **/
  @JsonProperty("gateway")
  public String getGateway() {
    return gateway;
  }

  public void setGateway(String gateway) {
    this.gateway = gateway;
  }

  public NetworkInfoNetworkinfo gateway(String gateway) {
    this.gateway = gateway;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class NetworkInfoNetworkinfo {\n");
    
    sb.append("    mac: ").append(toIndentedString(mac)).append("\n");
    sb.append("    dhcp: ").append(toIndentedString(dhcp)).append("\n");
    sb.append("    ip: ").append(toIndentedString(ip)).append("\n");
    sb.append("    netmask: ").append(toIndentedString(netmask)).append("\n");
    sb.append("    gateway: ").append(toIndentedString(gateway)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
