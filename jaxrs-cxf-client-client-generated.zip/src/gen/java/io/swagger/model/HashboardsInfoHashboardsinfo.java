package io.swagger.model;

import io.swagger.model.FWInfo;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class HashboardsInfoHashboardsinfo   {
  
  @Schema(example = "YWWLMMMMRRFSSSSS", description = "Hashboard serial number.")
 /**
   * Hashboard serial number.  
  **/
  private String hbSn = null;
  
  @Schema(description = "")
  private FWInfo firmware = null;
  
  @Schema(description = "")
  private FWInfo bootloader = null;
  
  @Schema(example = "1.0", description = "")
  private String apiVersion = null;
  public enum BoardEnum {
    NOT_SET("NOT_SET"),
    PROTO0_A("PROTO0_A"),
    PROTO0_B("PROTO0_B"),
    EVT("EVT"),
    DVT("DVT"),
    PVT("PVT"),
    EVB("EVB"),
    EPIC("EPIC"),
    EE_TEST("EE_TEST");

    private String value;

    BoardEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static BoardEnum fromValue(String text) {
      for (BoardEnum b : BoardEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(example = "PROTO0_B", description = "")
  private BoardEnum board = null;
  
  @Schema(example = "ABC123", description = "")
  private String chipId = null;
  public enum MiningAsicEnum {
    BZM("BZM"),
    MC1("MC1"),
    MC2("MC2");

    private String value;

    MiningAsicEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static MiningAsicEnum fromValue(String text) {
      for (MiningAsicEnum b : MiningAsicEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(example = "BZM", description = "")
  private MiningAsicEnum miningAsic = null;
  
  @Schema(example = "100", description = "Number of asics on the hashboard.")
 /**
   * Number of asics on the hashboard.  
  **/
  private Integer miningAsicCount = null;
  
  @Schema(example = "3", description = "Number of temperature sensors on the hashboard.")
 /**
   * Number of temperature sensors on the hashboard.  
  **/
  private Integer tempSensorCount = null;
  
  @Schema(example = "0", description = "The USB port number the hashboard is connected to.")
 /**
   * The USB port number the hashboard is connected to.  
  **/
  private Integer port = null;
  
  @Schema(example = "/var/log/ec_logs", description = "The absolute path where EC logs are stored.")
 /**
   * The absolute path where EC logs are stored.  
  **/
  private String ecLogsPath = null;
 /**
   * Hashboard serial number.
   * @return hbSn
  **/
  @JsonProperty("hb_sn")
  public String getHbSn() {
    return hbSn;
  }

  public void setHbSn(String hbSn) {
    this.hbSn = hbSn;
  }

  public HashboardsInfoHashboardsinfo hbSn(String hbSn) {
    this.hbSn = hbSn;
    return this;
  }

 /**
   * Get firmware
   * @return firmware
  **/
  @JsonProperty("firmware")
  public FWInfo getFirmware() {
    return firmware;
  }

  public void setFirmware(FWInfo firmware) {
    this.firmware = firmware;
  }

  public HashboardsInfoHashboardsinfo firmware(FWInfo firmware) {
    this.firmware = firmware;
    return this;
  }

 /**
   * Get bootloader
   * @return bootloader
  **/
  @JsonProperty("bootloader")
  public FWInfo getBootloader() {
    return bootloader;
  }

  public void setBootloader(FWInfo bootloader) {
    this.bootloader = bootloader;
  }

  public HashboardsInfoHashboardsinfo bootloader(FWInfo bootloader) {
    this.bootloader = bootloader;
    return this;
  }

 /**
   * Get apiVersion
   * @return apiVersion
  **/
  @JsonProperty("api_version")
  public String getApiVersion() {
    return apiVersion;
  }

  public void setApiVersion(String apiVersion) {
    this.apiVersion = apiVersion;
  }

  public HashboardsInfoHashboardsinfo apiVersion(String apiVersion) {
    this.apiVersion = apiVersion;
    return this;
  }

 /**
   * Get board
   * @return board
  **/
  @JsonProperty("board")
  public String getBoard() {
    if (board == null) {
      return null;
    }
    return board.getValue();
  }

  public void setBoard(BoardEnum board) {
    this.board = board;
  }

  public HashboardsInfoHashboardsinfo board(BoardEnum board) {
    this.board = board;
    return this;
  }

 /**
   * Get chipId
   * @return chipId
  **/
  @JsonProperty("chip_id")
  public String getChipId() {
    return chipId;
  }

  public void setChipId(String chipId) {
    this.chipId = chipId;
  }

  public HashboardsInfoHashboardsinfo chipId(String chipId) {
    this.chipId = chipId;
    return this;
  }

 /**
   * Get miningAsic
   * @return miningAsic
  **/
  @JsonProperty("mining_asic")
  public String getMiningAsic() {
    if (miningAsic == null) {
      return null;
    }
    return miningAsic.getValue();
  }

  public void setMiningAsic(MiningAsicEnum miningAsic) {
    this.miningAsic = miningAsic;
  }

  public HashboardsInfoHashboardsinfo miningAsic(MiningAsicEnum miningAsic) {
    this.miningAsic = miningAsic;
    return this;
  }

 /**
   * Number of asics on the hashboard.
   * @return miningAsicCount
  **/
  @JsonProperty("mining_asic_count")
  public Integer getMiningAsicCount() {
    return miningAsicCount;
  }

  public void setMiningAsicCount(Integer miningAsicCount) {
    this.miningAsicCount = miningAsicCount;
  }

  public HashboardsInfoHashboardsinfo miningAsicCount(Integer miningAsicCount) {
    this.miningAsicCount = miningAsicCount;
    return this;
  }

 /**
   * Number of temperature sensors on the hashboard.
   * @return tempSensorCount
  **/
  @JsonProperty("temp_sensor_count")
  public Integer getTempSensorCount() {
    return tempSensorCount;
  }

  public void setTempSensorCount(Integer tempSensorCount) {
    this.tempSensorCount = tempSensorCount;
  }

  public HashboardsInfoHashboardsinfo tempSensorCount(Integer tempSensorCount) {
    this.tempSensorCount = tempSensorCount;
    return this;
  }

 /**
   * The USB port number the hashboard is connected to.
   * @return port
  **/
  @JsonProperty("port")
  public Integer getPort() {
    return port;
  }

  public void setPort(Integer port) {
    this.port = port;
  }

  public HashboardsInfoHashboardsinfo port(Integer port) {
    this.port = port;
    return this;
  }

 /**
   * The absolute path where EC logs are stored.
   * @return ecLogsPath
  **/
  @JsonProperty("ec_logs_path")
  public String getEcLogsPath() {
    return ecLogsPath;
  }

  public void setEcLogsPath(String ecLogsPath) {
    this.ecLogsPath = ecLogsPath;
  }

  public HashboardsInfoHashboardsinfo ecLogsPath(String ecLogsPath) {
    this.ecLogsPath = ecLogsPath;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HashboardsInfoHashboardsinfo {\n");
    
    sb.append("    hbSn: ").append(toIndentedString(hbSn)).append("\n");
    sb.append("    firmware: ").append(toIndentedString(firmware)).append("\n");
    sb.append("    bootloader: ").append(toIndentedString(bootloader)).append("\n");
    sb.append("    apiVersion: ").append(toIndentedString(apiVersion)).append("\n");
    sb.append("    board: ").append(toIndentedString(board)).append("\n");
    sb.append("    chipId: ").append(toIndentedString(chipId)).append("\n");
    sb.append("    miningAsic: ").append(toIndentedString(miningAsic)).append("\n");
    sb.append("    miningAsicCount: ").append(toIndentedString(miningAsicCount)).append("\n");
    sb.append("    tempSensorCount: ").append(toIndentedString(tempSensorCount)).append("\n");
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("    ecLogsPath: ").append(toIndentedString(ecLogsPath)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
