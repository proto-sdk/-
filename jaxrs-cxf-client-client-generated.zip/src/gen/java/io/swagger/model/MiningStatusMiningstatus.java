package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class MiningStatusMiningstatus   {
  public enum StatusEnum {
    UNINITIALIZED("Uninitialized"),
    POWERINGON("PoweringOn"),
    MINING("Mining"),
    DEGRADEDMINING("DegradedMining"),
    POWERINGOFF("PoweringOff"),
    STOPPED("Stopped"),
    NOPOOLS("NoPools"),
    ERROR("Error");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(example = "Mining", description = "The indication will reveal whether the mining operation is currently active or has ceased")
 /**
   * The indication will reveal whether the mining operation is currently active or has ceased  
  **/
  private StatusEnum status = null;
  
  @Schema(example = "521", description = "The amount of time in seconds that has passed since the start of the mining operation.")
 /**
   * The amount of time in seconds that has passed since the start of the mining operation.  
  **/
  private Integer miningUptimeS = null;
  
  @Schema(example = "521", description = "The amount of time in seconds that has passed since the last reboot of the system.")
 /**
   * The amount of time in seconds that has passed since the last reboot of the system.  
  **/
  private Integer rebootUptimeS = null;
  
  @Schema(example = "110000.2", description = "The average hash rate in giga-hashes per second, since the device started mining. average_hashrate_ghs = Total hash count / (elapsed_time_s * 10^9)")
 /**
   * The average hash rate in giga-hashes per second, since the device started mining. average_hashrate_ghs = Total hash count / (elapsed_time_s * 10^9)  
  **/
  private BigDecimal averageHashrateGhs = null;
  
  @Schema(example = "112000", description = "Expected hashrate determined by the current power level.")
 /**
   * Expected hashrate determined by the current power level.  
  **/
  private BigDecimal idealHashrateGhs = null;
  
  @Schema(example = "3100", description = "Amount of power being consumed by mining in watts.")
 /**
   * Amount of power being consumed by mining in watts.  
  **/
  private BigDecimal powerUsageWatts = null;
  
  @Schema(example = "3120", description = "Amount of power in watts for the system to target.")
 /**
   * Amount of power in watts for the system to target.  
  **/
  private BigDecimal powerTargetWatts = null;
  
  @Schema(description = "The average efficiency in joules per terahash, since the device started mining.")
 /**
   * The average efficiency in joules per terahash, since the device started mining.  
  **/
  private BigDecimal averageEfficiencyJth = null;
  
  @Schema(example = "60", description = "Average temperature of the ASICs in the mining device.")
 /**
   * Average temperature of the ASICs in the mining device.  
  **/
  private BigDecimal averageAsicTempC = null;
  
  @Schema(example = "60", description = "Average temperature of the mining device.")
 /**
   * Average temperature of the mining device.  
  **/
  private BigDecimal averageHbTempC = null;
  
  @Schema(example = "100", description = "The number of hardware errors that have occurred during the mining operation.")
 /**
   * The number of hardware errors that have occurred during the mining operation.  
  **/
  private Integer hwErrors = null;
  
  @Schema(example = "This reserved space can be utilized to include additional debug information.", description = "")
  private String message = null;
 /**
   * The indication will reveal whether the mining operation is currently active or has ceased
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.getValue();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public MiningStatusMiningstatus status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * The amount of time in seconds that has passed since the start of the mining operation.
   * @return miningUptimeS
  **/
  @JsonProperty("mining_uptime_s")
  public Integer getMiningUptimeS() {
    return miningUptimeS;
  }

  public void setMiningUptimeS(Integer miningUptimeS) {
    this.miningUptimeS = miningUptimeS;
  }

  public MiningStatusMiningstatus miningUptimeS(Integer miningUptimeS) {
    this.miningUptimeS = miningUptimeS;
    return this;
  }

 /**
   * The amount of time in seconds that has passed since the last reboot of the system.
   * @return rebootUptimeS
  **/
  @JsonProperty("reboot_uptime_s")
  public Integer getRebootUptimeS() {
    return rebootUptimeS;
  }

  public void setRebootUptimeS(Integer rebootUptimeS) {
    this.rebootUptimeS = rebootUptimeS;
  }

  public MiningStatusMiningstatus rebootUptimeS(Integer rebootUptimeS) {
    this.rebootUptimeS = rebootUptimeS;
    return this;
  }

 /**
   * The average hash rate in giga-hashes per second, since the device started mining. average_hashrate_ghs &#x3D; Total hash count / (elapsed_time_s * 10^9)
   * @return averageHashrateGhs
  **/
  @JsonProperty("average_hashrate_ghs")
  public BigDecimal getAverageHashrateGhs() {
    return averageHashrateGhs;
  }

  public void setAverageHashrateGhs(BigDecimal averageHashrateGhs) {
    this.averageHashrateGhs = averageHashrateGhs;
  }

  public MiningStatusMiningstatus averageHashrateGhs(BigDecimal averageHashrateGhs) {
    this.averageHashrateGhs = averageHashrateGhs;
    return this;
  }

 /**
   * Expected hashrate determined by the current power level.
   * @return idealHashrateGhs
  **/
  @JsonProperty("ideal_hashrate_ghs")
  public BigDecimal getIdealHashrateGhs() {
    return idealHashrateGhs;
  }

  public void setIdealHashrateGhs(BigDecimal idealHashrateGhs) {
    this.idealHashrateGhs = idealHashrateGhs;
  }

  public MiningStatusMiningstatus idealHashrateGhs(BigDecimal idealHashrateGhs) {
    this.idealHashrateGhs = idealHashrateGhs;
    return this;
  }

 /**
   * Amount of power being consumed by mining in watts.
   * @return powerUsageWatts
  **/
  @JsonProperty("power_usage_watts")
  public BigDecimal getPowerUsageWatts() {
    return powerUsageWatts;
  }

  public void setPowerUsageWatts(BigDecimal powerUsageWatts) {
    this.powerUsageWatts = powerUsageWatts;
  }

  public MiningStatusMiningstatus powerUsageWatts(BigDecimal powerUsageWatts) {
    this.powerUsageWatts = powerUsageWatts;
    return this;
  }

 /**
   * Amount of power in watts for the system to target.
   * @return powerTargetWatts
  **/
  @JsonProperty("power_target_watts")
  public BigDecimal getPowerTargetWatts() {
    return powerTargetWatts;
  }

  public void setPowerTargetWatts(BigDecimal powerTargetWatts) {
    this.powerTargetWatts = powerTargetWatts;
  }

  public MiningStatusMiningstatus powerTargetWatts(BigDecimal powerTargetWatts) {
    this.powerTargetWatts = powerTargetWatts;
    return this;
  }

 /**
   * The average efficiency in joules per terahash, since the device started mining.
   * @return averageEfficiencyJth
  **/
  @JsonProperty("average_efficiency_jth")
  public BigDecimal getAverageEfficiencyJth() {
    return averageEfficiencyJth;
  }

  public void setAverageEfficiencyJth(BigDecimal averageEfficiencyJth) {
    this.averageEfficiencyJth = averageEfficiencyJth;
  }

  public MiningStatusMiningstatus averageEfficiencyJth(BigDecimal averageEfficiencyJth) {
    this.averageEfficiencyJth = averageEfficiencyJth;
    return this;
  }

 /**
   * Average temperature of the ASICs in the mining device.
   * @return averageAsicTempC
  **/
  @JsonProperty("average_asic_temp_c")
  public BigDecimal getAverageAsicTempC() {
    return averageAsicTempC;
  }

  public void setAverageAsicTempC(BigDecimal averageAsicTempC) {
    this.averageAsicTempC = averageAsicTempC;
  }

  public MiningStatusMiningstatus averageAsicTempC(BigDecimal averageAsicTempC) {
    this.averageAsicTempC = averageAsicTempC;
    return this;
  }

 /**
   * Average temperature of the mining device.
   * @return averageHbTempC
  **/
  @JsonProperty("average_hb_temp_c")
  public BigDecimal getAverageHbTempC() {
    return averageHbTempC;
  }

  public void setAverageHbTempC(BigDecimal averageHbTempC) {
    this.averageHbTempC = averageHbTempC;
  }

  public MiningStatusMiningstatus averageHbTempC(BigDecimal averageHbTempC) {
    this.averageHbTempC = averageHbTempC;
    return this;
  }

 /**
   * The number of hardware errors that have occurred during the mining operation.
   * @return hwErrors
  **/
  @JsonProperty("hw_errors")
  public Integer getHwErrors() {
    return hwErrors;
  }

  public void setHwErrors(Integer hwErrors) {
    this.hwErrors = hwErrors;
  }

  public MiningStatusMiningstatus hwErrors(Integer hwErrors) {
    this.hwErrors = hwErrors;
    return this;
  }

 /**
   * Get message
   * @return message
  **/
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public MiningStatusMiningstatus message(String message) {
    this.message = message;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MiningStatusMiningstatus {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    miningUptimeS: ").append(toIndentedString(miningUptimeS)).append("\n");
    sb.append("    rebootUptimeS: ").append(toIndentedString(rebootUptimeS)).append("\n");
    sb.append("    averageHashrateGhs: ").append(toIndentedString(averageHashrateGhs)).append("\n");
    sb.append("    idealHashrateGhs: ").append(toIndentedString(idealHashrateGhs)).append("\n");
    sb.append("    powerUsageWatts: ").append(toIndentedString(powerUsageWatts)).append("\n");
    sb.append("    powerTargetWatts: ").append(toIndentedString(powerTargetWatts)).append("\n");
    sb.append("    averageEfficiencyJth: ").append(toIndentedString(averageEfficiencyJth)).append("\n");
    sb.append("    averageAsicTempC: ").append(toIndentedString(averageAsicTempC)).append("\n");
    sb.append("    averageHbTempC: ").append(toIndentedString(averageHbTempC)).append("\n");
    sb.append("    hwErrors: ").append(toIndentedString(hwErrors)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
