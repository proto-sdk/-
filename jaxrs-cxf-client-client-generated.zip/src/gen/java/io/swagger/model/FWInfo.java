package io.swagger.model;


import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class FWInfo   {
  
  @Schema(example = "1.0", description = "")
  private String version = null;
  
  @Schema(example = "1213423223", description = "")
  private String gitHash = null;
  
  @Schema(example = "1213423223", description = "")
  private String imageHash = null;
  public enum BuildEnum {
    DEBUG("debug"),
    RELEASE("release");

    private String value;

    BuildEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static BuildEnum fromValue(String text) {
      for (BuildEnum b : BuildEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(example = "release", description = "")
  private BuildEnum build = null;
 /**
   * Get version
   * @return version
  **/
  @JsonProperty("version")
  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public FWInfo version(String version) {
    this.version = version;
    return this;
  }

 /**
   * Get gitHash
   * @return gitHash
  **/
  @JsonProperty("git_hash")
  public String getGitHash() {
    return gitHash;
  }

  public void setGitHash(String gitHash) {
    this.gitHash = gitHash;
  }

  public FWInfo gitHash(String gitHash) {
    this.gitHash = gitHash;
    return this;
  }

 /**
   * Get imageHash
   * @return imageHash
  **/
  @JsonProperty("image_hash")
  public String getImageHash() {
    return imageHash;
  }

  public void setImageHash(String imageHash) {
    this.imageHash = imageHash;
  }

  public FWInfo imageHash(String imageHash) {
    this.imageHash = imageHash;
    return this;
  }

 /**
   * Get build
   * @return build
  **/
  @JsonProperty("build")
  public String getBuild() {
    if (build == null) {
      return null;
    }
    return build.getValue();
  }

  public void setBuild(BuildEnum build) {
    this.build = build;
  }

  public FWInfo build(BuildEnum build) {
    this.build = build;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FWInfo {\n");
    
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    gitHash: ").append(toIndentedString(gitHash)).append("\n");
    sb.append("    imageHash: ").append(toIndentedString(imageHash)).append("\n");
    sb.append("    build: ").append(toIndentedString(build)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
