package io.swagger.model;

import io.swagger.model.FanInfo;
import java.util.ArrayList;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class CoolingStatusCoolingstatus   {
  public enum FanModeEnum {
    OFF("Off"),
    AUTO("Auto"),
    MAX("Max");

    private String value;

    FanModeEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static FanModeEnum fromValue(String text) {
      for (FanModeEnum b : FanModeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(example = "Auto", description = "Parameter to show the current fan mode.")
 /**
   * Parameter to show the current fan mode.  
  **/
  private FanModeEnum fanMode = null;
  
  @Schema(description = "This will show speed of all fans in the system.")
 /**
   * This will show speed of all fans in the system.  
  **/
  private List<FanInfo> fans = null;
 /**
   * Parameter to show the current fan mode.
   * @return fanMode
  **/
  @JsonProperty("fan_mode")
  public String getFanMode() {
    if (fanMode == null) {
      return null;
    }
    return fanMode.getValue();
  }

  public void setFanMode(FanModeEnum fanMode) {
    this.fanMode = fanMode;
  }

  public CoolingStatusCoolingstatus fanMode(FanModeEnum fanMode) {
    this.fanMode = fanMode;
    return this;
  }

 /**
   * This will show speed of all fans in the system.
   * @return fans
  **/
  @JsonProperty("fans")
  public List<FanInfo> getFans() {
    return fans;
  }

  public void setFans(List<FanInfo> fans) {
    this.fans = fans;
  }

  public CoolingStatusCoolingstatus fans(List<FanInfo> fans) {
    this.fans = fans;
    return this;
  }

  public CoolingStatusCoolingstatus addFansItem(FanInfo fansItem) {
    this.fans.add(fansItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CoolingStatusCoolingstatus {\n");
    
    sb.append("    fanMode: ").append(toIndentedString(fanMode)).append("\n");
    sb.append("    fans: ").append(toIndentedString(fans)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
