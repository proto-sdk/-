package io.swagger.model;


import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class FanInfo   {
  
  @Schema(example = "0", description = "Each fan is assigned a unique identifier starting from 0.")
 /**
   * Each fan is assigned a unique identifier starting from 0.  
  **/
  private Integer id = null;
  
  @Schema(example = "1200", description = "The fan's current rotations per minute (RPM).")
 /**
   * The fan's current rotations per minute (RPM).  
  **/
  private Integer rpm = null;
 /**
   * Each fan is assigned a unique identifier starting from 0.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public FanInfo id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * The fan&#x27;s current rotations per minute (RPM).
   * @return rpm
  **/
  @JsonProperty("rpm")
  public Integer getRpm() {
    return rpm;
  }

  public void setRpm(Integer rpm) {
    this.rpm = rpm;
  }

  public FanInfo rpm(Integer rpm) {
    this.rpm = rpm;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FanInfo {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    rpm: ").append(toIndentedString(rpm)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
