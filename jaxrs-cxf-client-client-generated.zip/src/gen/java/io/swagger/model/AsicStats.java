package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class AsicStats   {
  
  @Schema(example = "0", description = "Unique identifier assigned to each ASIC located on a hashboard, starting from 0.")
 /**
   * Unique identifier assigned to each ASIC located on a hashboard, starting from 0.  
  **/
  private Integer id = null;
  
  @Schema(example = "0", description = "Physical row location of the ASIC on the hashboard.")
 /**
   * Physical row location of the ASIC on the hashboard.  
  **/
  private Integer row = null;
  
  @Schema(example = "10", description = "Physical column location of the ASIC on the hashboard.")
 /**
   * Physical column location of the ASIC on the hashboard.  
  **/
  private Integer column = null;
  
  @Schema(example = "650", description = "The frequency of the ASIC measured in megahertz.")
 /**
   * The frequency of the ASIC measured in megahertz.  
  **/
  private BigDecimal freqMhz = null;
  
  @Schema(example = "45.5", description = "Current temperature of the ASIC in celsius")
 /**
   * Current temperature of the ASIC in celsius  
  **/
  private BigDecimal tempC = null;
  
  @Schema(example = "300", description = "The current hash rate of the ASIC, measured in GH/s.")
 /**
   * The current hash rate of the ASIC, measured in GH/s.  
  **/
  private BigDecimal hashrateGhs = null;
  
  @Schema(example = "300", description = "The expected hashrate determined by the clock frequency of the ASIC, measured in GH/s.")
 /**
   * The expected hashrate determined by the clock frequency of the ASIC, measured in GH/s.  
  **/
  private BigDecimal idealHashrateGhs = null;
  
  @Schema(example = "3.3", description = "The number of times that the ASIC produced an incorrect hash or an error during a specific period of time.  Error Rate (%) = (Number of incorrect hash / Total number of expected Hash) x 100%")
 /**
   * The number of times that the ASIC produced an incorrect hash or an error during a specific period of time.  Error Rate (%) = (Number of incorrect hash / Total number of expected Hash) x 100%  
  **/
  private BigDecimal errorRate = null;
 /**
   * Unique identifier assigned to each ASIC located on a hashboard, starting from 0.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public AsicStats id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Physical row location of the ASIC on the hashboard.
   * @return row
  **/
  @JsonProperty("row")
  public Integer getRow() {
    return row;
  }

  public void setRow(Integer row) {
    this.row = row;
  }

  public AsicStats row(Integer row) {
    this.row = row;
    return this;
  }

 /**
   * Physical column location of the ASIC on the hashboard.
   * @return column
  **/
  @JsonProperty("column")
  public Integer getColumn() {
    return column;
  }

  public void setColumn(Integer column) {
    this.column = column;
  }

  public AsicStats column(Integer column) {
    this.column = column;
    return this;
  }

 /**
   * The frequency of the ASIC measured in megahertz.
   * @return freqMhz
  **/
  @JsonProperty("freq_mhz")
  public BigDecimal getFreqMhz() {
    return freqMhz;
  }

  public void setFreqMhz(BigDecimal freqMhz) {
    this.freqMhz = freqMhz;
  }

  public AsicStats freqMhz(BigDecimal freqMhz) {
    this.freqMhz = freqMhz;
    return this;
  }

 /**
   * Current temperature of the ASIC in celsius
   * @return tempC
  **/
  @JsonProperty("temp_c")
  public BigDecimal getTempC() {
    return tempC;
  }

  public void setTempC(BigDecimal tempC) {
    this.tempC = tempC;
  }

  public AsicStats tempC(BigDecimal tempC) {
    this.tempC = tempC;
    return this;
  }

 /**
   * The current hash rate of the ASIC, measured in GH/s.
   * @return hashrateGhs
  **/
  @JsonProperty("hashrate_ghs")
  public BigDecimal getHashrateGhs() {
    return hashrateGhs;
  }

  public void setHashrateGhs(BigDecimal hashrateGhs) {
    this.hashrateGhs = hashrateGhs;
  }

  public AsicStats hashrateGhs(BigDecimal hashrateGhs) {
    this.hashrateGhs = hashrateGhs;
    return this;
  }

 /**
   * The expected hashrate determined by the clock frequency of the ASIC, measured in GH/s.
   * @return idealHashrateGhs
  **/
  @JsonProperty("ideal_hashrate_ghs")
  public BigDecimal getIdealHashrateGhs() {
    return idealHashrateGhs;
  }

  public void setIdealHashrateGhs(BigDecimal idealHashrateGhs) {
    this.idealHashrateGhs = idealHashrateGhs;
  }

  public AsicStats idealHashrateGhs(BigDecimal idealHashrateGhs) {
    this.idealHashrateGhs = idealHashrateGhs;
    return this;
  }

 /**
   * The number of times that the ASIC produced an incorrect hash or an error during a specific period of time.  Error Rate (%) &#x3D; (Number of incorrect hash / Total number of expected Hash) x 100%
   * @return errorRate
  **/
  @JsonProperty("error_rate")
  public BigDecimal getErrorRate() {
    return errorRate;
  }

  public void setErrorRate(BigDecimal errorRate) {
    this.errorRate = errorRate;
  }

  public AsicStats errorRate(BigDecimal errorRate) {
    this.errorRate = errorRate;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AsicStats {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    row: ").append(toIndentedString(row)).append("\n");
    sb.append("    column: ").append(toIndentedString(column)).append("\n");
    sb.append("    freqMhz: ").append(toIndentedString(freqMhz)).append("\n");
    sb.append("    tempC: ").append(toIndentedString(tempC)).append("\n");
    sb.append("    hashrateGhs: ").append(toIndentedString(hashrateGhs)).append("\n");
    sb.append("    idealHashrateGhs: ").append(toIndentedString(idealHashrateGhs)).append("\n");
    sb.append("    errorRate: ").append(toIndentedString(errorRate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
