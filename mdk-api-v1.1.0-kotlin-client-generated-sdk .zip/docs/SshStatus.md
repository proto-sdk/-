# SshStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | [**kotlin.Boolean**](.md) |  |  [optional]
