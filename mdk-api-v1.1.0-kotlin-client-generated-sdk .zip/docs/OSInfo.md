# OSInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**kotlin.String**](.md) |  |  [optional]
**version** | [**kotlin.String**](.md) |  |  [optional]
**gitHash** | [**kotlin.String**](.md) |  |  [optional]
**variant** | [**inline**](#Variant) |  |  [optional]
**buildDatetimeUtc** | [**kotlin.String**](.md) |  |  [optional]
**machine** | [**kotlin.String**](.md) |  |  [optional]
**status** | [**OSStatus**](OSStatus.md) |  |  [optional]

<a name="Variant"></a>
## Enum: variant
Name | Value
---- | -----
variant | release, mfg, dev, unknown
