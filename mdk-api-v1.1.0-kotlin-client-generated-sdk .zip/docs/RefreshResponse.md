# RefreshResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessToken** | [**kotlin.String**](.md) | A new JWT access token. | 
