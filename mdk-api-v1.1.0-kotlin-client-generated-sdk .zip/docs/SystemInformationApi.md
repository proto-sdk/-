# SystemInformationApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getSystemStatus**](SystemInformationApi.md#getSystemStatus) | **GET** /api/v1/system/status | 

<a name="getSystemStatus"></a>
# **getSystemStatus**
> SystemStatuses getSystemStatus()



Get system statuses

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SystemInformationApi()
try {
    val result : SystemStatuses = apiInstance.getSystemStatus()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SystemInformationApi#getSystemStatus")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SystemInformationApi#getSystemStatus")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SystemStatuses**](SystemStatuses.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

