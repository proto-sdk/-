# AuthTokens

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**refreshToken** | [**kotlin.String**](.md) | JWT refresh token. | 
**accessToken** | [**kotlin.String**](.md) | JWT access token. | 
