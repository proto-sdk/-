# FWInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | [**kotlin.String**](.md) |  |  [optional]
**gitHash** | [**kotlin.String**](.md) |  |  [optional]
**imageHash** | [**kotlin.String**](.md) |  |  [optional]
**build** | [**inline**](#Build) |  |  [optional]

<a name="Build"></a>
## Enum: build
Name | Value
---- | -----
build | debug, release
