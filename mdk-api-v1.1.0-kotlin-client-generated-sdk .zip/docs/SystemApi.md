# SystemApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getSSH**](SystemApi.md#getSSH) | **GET** /api/v1/system/ssh | 
[**getSystemInfo**](SystemApi.md#getSystemInfo) | **GET** /api/v1/system | 
[**getSystemLogs**](SystemApi.md#getSystemLogs) | **GET** /api/v1/system/logs | 
[**locateSystem**](SystemApi.md#locateSystem) | **POST** /api/v1/system/locate | 
[**rebootSystem**](SystemApi.md#rebootSystem) | **POST** /api/v1/system/reboot | 
[**setSSH**](SystemApi.md#setSSH) | **PUT** /api/v1/system/ssh | 
[**updateSystem**](SystemApi.md#updateSystem) | **POST** /api/v1/system/update | 

<a name="getSSH"></a>
# **getSSH**
> SshResponse getSSH()



The get ssh endpoint returns if SSH is enabled or disabled on the control board

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SystemApi()
try {
    val result : SshResponse = apiInstance.getSSH()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SystemApi#getSSH")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SystemApi#getSSH")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SshResponse**](SshResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSystemInfo"></a>
# **getSystemInfo**
> SystemInfo getSystemInfo()



The system endpoint provides information related to the control board including OS, software, and hardware component details.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SystemApi()
try {
    val result : SystemInfo = apiInstance.getSystemInfo()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SystemApi#getSystemInfo")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SystemApi#getSystemInfo")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SystemInfo**](SystemInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSystemLogs"></a>
# **getSystemLogs**
> LogsResponse getSystemLogs(lines, source)



The logs endpoint provides the most recent log lines from a given source, either OS, pool software, or miner logs.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SystemApi()
val lines : kotlin.Int = 56 // kotlin.Int | Number of log lines to return from the tail of the log, up to a maximum of 10000 lines. Defaults to 100 lines.
val source : kotlin.String = source_example // kotlin.String | Source of logs to fetch. Defaults to miner software logs.
try {
    val result : LogsResponse = apiInstance.getSystemLogs(lines, source)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SystemApi#getSystemLogs")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SystemApi#getSystemLogs")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lines** | **kotlin.Int**| Number of log lines to return from the tail of the log, up to a maximum of 10000 lines. Defaults to 100 lines. | [optional] [default to 100]
 **source** | **kotlin.String**| Source of logs to fetch. Defaults to miner software logs. | [optional] [default to miner_sw] [enum: os, pool_sw, miner_sw, miner_web_server]

### Return type

[**LogsResponse**](LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="locateSystem"></a>
# **locateSystem**
> MessageResponse locateSystem(ledOnTime)



The locate system endpoint can be used to flash the indicator LED on the control board to assist in finding the miner.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SystemApi()
val ledOnTime : kotlin.Int = 56 // kotlin.Int | The duration in seconds for which to turn on the LED, with a max value of 300 seconds. If not specified, a default value of 30 seconds will be used. Requests made while the LED is on will be ignored.
try {
    val result : MessageResponse = apiInstance.locateSystem(ledOnTime)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SystemApi#locateSystem")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SystemApi#locateSystem")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ledOnTime** | **kotlin.Int**| The duration in seconds for which to turn on the LED, with a max value of 300 seconds. If not specified, a default value of 30 seconds will be used. Requests made while the LED is on will be ignored. | [optional] [default to 30]

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="rebootSystem"></a>
# **rebootSystem**
> MessageResponse rebootSystem()



The reboot endpoint can be used to reboot the entire system.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SystemApi()
try {
    val result : MessageResponse = apiInstance.rebootSystem()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SystemApi#rebootSystem")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SystemApi#rebootSystem")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="setSSH"></a>
# **setSSH**
> SshResponse setSSH(body)



The put ssh endpoint enables/disables SSH on the control board

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SystemApi()
val body : SshConfig =  // SshConfig | 
try {
    val result : SshResponse = apiInstance.setSSH(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SystemApi#setSSH")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SystemApi#setSSH")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SshConfig**](SshConfig.md)|  |

### Return type

[**SshResponse**](SshResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="updateSystem"></a>
# **updateSystem**
> MessageResponse updateSystem()



The update system endpoint can be used to initiate a system update of the miner software.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = SystemApi()
try {
    val result : MessageResponse = apiInstance.updateSystem()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling SystemApi#updateSystem")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling SystemApi#updateSystem")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

