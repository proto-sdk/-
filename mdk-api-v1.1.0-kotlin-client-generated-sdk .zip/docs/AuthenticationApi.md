# AuthenticationApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1AuthLogoutPost**](AuthenticationApi.md#apiV1AuthLogoutPost) | **POST** /api/v1/auth/logout | User logout
[**apiV1AuthRefreshPost**](AuthenticationApi.md#apiV1AuthRefreshPost) | **POST** /api/v1/auth/refresh | Refresh JWT access token
[**login**](AuthenticationApi.md#login) | **POST** /api/v1/auth/login | 
[**setPassword**](AuthenticationApi.md#setPassword) | **PUT** /api/v1/auth/password | 

<a name="apiV1AuthLogoutPost"></a>
# **apiV1AuthLogoutPost**
> MessageResponse apiV1AuthLogoutPost(body)

User logout

Validates and blacklists JWT tokens, effectively logging out the user.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AuthenticationApi()
val body : AuthTokens =  // AuthTokens | 
try {
    val result : MessageResponse = apiInstance.apiV1AuthLogoutPost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AuthenticationApi#apiV1AuthLogoutPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AuthenticationApi#apiV1AuthLogoutPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AuthTokens**](AuthTokens.md)|  |

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="apiV1AuthRefreshPost"></a>
# **apiV1AuthRefreshPost**
> RefreshResponse apiV1AuthRefreshPost(body)

Refresh JWT access token

Validates the provided refresh token and returns a new JWT access token.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AuthenticationApi()
val body : RefreshRequest =  // RefreshRequest | 
try {
    val result : RefreshResponse = apiInstance.apiV1AuthRefreshPost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AuthenticationApi#apiV1AuthRefreshPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AuthenticationApi#apiV1AuthRefreshPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RefreshRequest**](RefreshRequest.md)|  |

### Return type

[**RefreshResponse**](RefreshResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="login"></a>
# **login**
> AuthTokens login(body)



Authenticates a user using a password and returns a JWT access and refresh token pair.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AuthenticationApi()
val body : PasswordRequest =  // PasswordRequest | 
try {
    val result : AuthTokens = apiInstance.login(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AuthenticationApi#login")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AuthenticationApi#login")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PasswordRequest**](PasswordRequest.md)|  |

### Return type

[**AuthTokens**](AuthTokens.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="setPassword"></a>
# **setPassword**
> MessageResponse setPassword(body)



The password endpoint allows users to set a password during onboarding

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = AuthenticationApi()
val body : PasswordRequest =  // PasswordRequest | 
try {
    val result : MessageResponse = apiInstance.setPassword(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling AuthenticationApi#setPassword")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling AuthenticationApi#setPassword")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PasswordRequest**](PasswordRequest.md)|  |

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

