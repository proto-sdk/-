# PowerApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getHashboardPower**](PowerApi.md#getHashboardPower) | **GET** /api/v1/power/{hb_sn} | 
[**getMinerPower**](PowerApi.md#getMinerPower) | **GET** /api/v1/power | 

<a name="getHashboardPower"></a>
# **getHashboardPower**
> PowerResponse getHashboardPower(hbSn, duration)



The power endpoint provides hashboard-level historical operation data.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PowerApi()
val hbSn : kotlin.String = hbSn_example // kotlin.String | The serial number of the hashboard to provide power information for.
val duration : kotlin.String = duration_example // kotlin.String | 
try {
    val result : PowerResponse = apiInstance.getHashboardPower(hbSn, duration)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PowerApi#getHashboardPower")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PowerApi#getHashboardPower")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **kotlin.String**| The serial number of the hashboard to provide power information for. |
 **duration** | **kotlin.String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**PowerResponse**](PowerResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMinerPower"></a>
# **getMinerPower**
> PowerResponse getMinerPower(duration)



The power endpoint provides miner-level historical power operation data.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PowerApi()
val duration : kotlin.String = duration_example // kotlin.String | 
try {
    val result : PowerResponse = apiInstance.getMinerPower(duration)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PowerApi#getMinerPower")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PowerApi#getMinerPower")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **kotlin.String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**PowerResponse**](PowerResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

