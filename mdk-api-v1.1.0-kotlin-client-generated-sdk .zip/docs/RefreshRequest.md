# RefreshRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**refreshToken** | [**kotlin.String**](.md) | The JWT refresh token to be validated. | 
