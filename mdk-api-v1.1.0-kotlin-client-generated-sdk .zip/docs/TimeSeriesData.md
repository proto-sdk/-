# TimeSeriesData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datetime** | [**kotlin.Int**](.md) | Unix time epoch. |  [optional]
**value** | [**kotlin.Int**](.md) | Value of data requested at the given datetime. |  [optional]
