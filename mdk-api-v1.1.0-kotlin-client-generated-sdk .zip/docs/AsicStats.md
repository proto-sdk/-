# AsicStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**kotlin.Int**](.md) | Unique identifier assigned to each ASIC located on a hashboard, starting from 0. |  [optional]
**row** | [**kotlin.Int**](.md) | Physical row location of the ASIC on the hashboard. |  [optional]
**column** | [**kotlin.Int**](.md) | Physical column location of the ASIC on the hashboard. |  [optional]
**freqMhz** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | The frequency of the ASIC measured in megahertz. |  [optional]
**tempC** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | Current temperature of the ASIC in celsius |  [optional]
**hashrateGhs** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | The current hash rate of the ASIC, measured in GH/s. |  [optional]
**idealHashrateGhs** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | The expected hashrate determined by the clock frequency of the ASIC, measured in GH/s. |  [optional]
**errorRate** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | The number of times that the ASIC produced an incorrect hash or an error during a specific period of time.  Error Rate (%) &#x3D; (Number of incorrect hash / Total number of expected Hash) x 100% |  [optional]
