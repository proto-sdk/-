# HashboardsInfoHashboardsinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hbSn** | [**kotlin.String**](.md) | Hashboard serial number. |  [optional]
**firmware** | [**FWInfo**](FWInfo.md) |  |  [optional]
**bootloader** | [**FWInfo**](FWInfo.md) |  |  [optional]
**apiVersion** | [**kotlin.String**](.md) |  |  [optional]
**board** | [**inline**](#Board) |  |  [optional]
**chipId** | [**kotlin.String**](.md) |  |  [optional]
**miningAsic** | [**inline**](#MiningAsic) |  |  [optional]
**miningAsicCount** | [**kotlin.Int**](.md) | Number of asics on the hashboard. |  [optional]
**tempSensorCount** | [**kotlin.Int**](.md) | Number of temperature sensors on the hashboard. |  [optional]
**port** | [**kotlin.Int**](.md) | The USB port number the hashboard is connected to. |  [optional]
**ecLogsPath** | [**kotlin.String**](.md) | The absolute path where EC logs are stored. |  [optional]

<a name="Board"></a>
## Enum: board
Name | Value
---- | -----
board | NOT_SET, PROTO0_A, PROTO0_B, EVT, DVT, PVT, EVB, EPIC, EE_TEST

<a name="MiningAsic"></a>
## Enum: mining_asic
Name | Value
---- | -----
miningAsic | BZM, MC1, MC2
