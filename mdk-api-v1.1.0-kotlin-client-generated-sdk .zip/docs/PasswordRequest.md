# PasswordRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**password** | [**kotlin.String**](.md) | The password for the user | 
