# TemperatureApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAsicTemperature**](TemperatureApi.md#getAsicTemperature) | **GET** /api/v1/temperature/{hb_sn}/{asic_id} | 
[**getHashboardTemperature**](TemperatureApi.md#getHashboardTemperature) | **GET** /api/v1/temperature/{hb_sn} | 
[**getMinerTemperature**](TemperatureApi.md#getMinerTemperature) | **GET** /api/v1/temperature | 

<a name="getAsicTemperature"></a>
# **getAsicTemperature**
> TemperatureResponse getAsicTemperature(hbSn, asicId, duration, granularity)



The hashrate endpoint provides ASIC-level historical temperature operation data.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = TemperatureApi()
val hbSn : kotlin.String = hbSn_example // kotlin.String | The serial number of the hashboard to provide temperature information for.
val asicId : kotlin.Int = 56 // kotlin.Int | The ID of the ASIC to provide temperature information for.
val duration : kotlin.String = duration_example // kotlin.String | 
val granularity : kotlin.String = granularity_example // kotlin.String | 
try {
    val result : TemperatureResponse = apiInstance.getAsicTemperature(hbSn, asicId, duration, granularity)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling TemperatureApi#getAsicTemperature")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling TemperatureApi#getAsicTemperature")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **kotlin.String**| The serial number of the hashboard to provide temperature information for. |
 **asicId** | **kotlin.Int**| The ID of the ASIC to provide temperature information for. |
 **duration** | **kotlin.String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]
 **granularity** | **kotlin.String**|  | [optional] [default to 1m] [enum: 1m, 5m, 15m]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getHashboardTemperature"></a>
# **getHashboardTemperature**
> TemperatureResponse getHashboardTemperature(hbSn, duration)



The temperature endpoint provides hashboard-level historical operation data.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = TemperatureApi()
val hbSn : kotlin.String = hbSn_example // kotlin.String | The serial number of the hashboard to provide temperature information for.
val duration : kotlin.String = duration_example // kotlin.String | 
try {
    val result : TemperatureResponse = apiInstance.getHashboardTemperature(hbSn, duration)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling TemperatureApi#getHashboardTemperature")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling TemperatureApi#getHashboardTemperature")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **kotlin.String**| The serial number of the hashboard to provide temperature information for. |
 **duration** | **kotlin.String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMinerTemperature"></a>
# **getMinerTemperature**
> TemperatureResponse getMinerTemperature(duration)



The temperature endpoint provides miner-level historical temperature operation data.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = TemperatureApi()
val duration : kotlin.String = duration_example // kotlin.String | 
try {
    val result : TemperatureResponse = apiInstance.getMinerTemperature(duration)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling TemperatureApi#getMinerTemperature")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling TemperatureApi#getMinerTemperature")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **kotlin.String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

