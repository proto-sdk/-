# PoolConfigResponseInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | [**kotlin.String**](.md) | The pool URL is used to establish communication with the mining pool and it is essential that it includes the port information. |  [optional]
**username** | [**kotlin.String**](.md) | The user is an account that is used for authentication with the mining pool. In some cases, if the user has multiple mining devices, the pool may assign a worker name as the username for each mining device. |  [optional]
**priority** | [**kotlin.Int**](.md) | Connection priority for this pool. Lower numbers are higher priorities, with 0 being the maximum. |  [optional]
