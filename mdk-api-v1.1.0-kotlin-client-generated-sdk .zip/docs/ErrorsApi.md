# ErrorsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getErrors**](ErrorsApi.md#getErrors) | **GET** /api/v1/errors | 

<a name="getErrors"></a>
# **getErrors**
> ErrorListResponse getErrors()



The errors endpoint provides alerts to be surfaced on the UI with different severity levels such as errors or warnings. This endpoint should be polled periodically to surface any issues that arise during mining operation.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = ErrorsApi()
try {
    val result : ErrorListResponse = apiInstance.getErrors()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling ErrorsApi#getErrors")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling ErrorsApi#getErrors")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ErrorListResponse**](ErrorListResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

