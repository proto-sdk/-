# MessageResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**kotlin.String**](.md) |  |  [optional]
