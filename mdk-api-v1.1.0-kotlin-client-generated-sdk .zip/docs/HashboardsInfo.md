# HashboardsInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hashboardsInfo** | [**kotlin.Array&lt;HashboardsInfoHashboardsinfo&gt;**](HashboardsInfoHashboardsinfo.md) |  |  [optional]
