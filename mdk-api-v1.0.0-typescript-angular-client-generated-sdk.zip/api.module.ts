import { NgModule, ModuleWithProviders, SkipSelf, Optional } from '@angular/core';
import { Configuration } from './configuration';
import { HttpClient } from '@angular/common/http';


import { AuthenticationService } from './api/authentication.service';
import { CoolingService } from './api/cooling.service';
import { EfficiencyService } from './api/efficiency.service';
import { ErrorsService } from './api/errors.service';
import { HashboardsService } from './api/hashboards.service';
import { HashrateService } from './api/hashrate.service';
import { MiningService } from './api/mining.service';
import { NetworkService } from './api/network.service';
import { PoolsService } from './api/pools.service';
import { PowerService } from './api/power.service';
import { SystemService } from './api/system.service';
import { SystemInformationService } from './api/systemInformation.service';
import { TemperatureService } from './api/temperature.service';

@NgModule({
  imports:      [],
  declarations: [],
  exports:      [],
  providers: [
    AuthenticationService,
    CoolingService,
    EfficiencyService,
    ErrorsService,
    HashboardsService,
    HashrateService,
    MiningService,
    NetworkService,
    PoolsService,
    PowerService,
    SystemService,
    SystemInformationService,
    TemperatureService ]
})
export class ApiModule {
    public static forRoot(configurationFactory: () => Configuration): ModuleWithProviders<ApiModule> {
        return {
            ngModule: ApiModule,
            providers: [ { provide: Configuration, useFactory: configurationFactory } ]
        };
    }

    constructor( @Optional() @SkipSelf() parentModule: ApiModule,
                 @Optional() http: HttpClient) {
        if (parentModule) {
            throw new Error('ApiModule is already loaded. Import in your base AppModule only.');
        }
        if (!http) {
            throw new Error('You need to import the HttpClientModule in your AppModule! \n' +
            'See also https://github.com/angular/angular/issues/20575');
        }
    }
}
