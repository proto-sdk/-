# CoolingApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getCooling**](CoolingApi.md#getCooling) | **GET** /api/v1/cooling | 
[**setCoolingMode**](CoolingApi.md#setCoolingMode) | **PUT** /api/v1/cooling | 

<a name="getCooling"></a>
# **getCooling**
> CoolingStatus getCooling()



The cooling endpoint provides information on the cooling status of the device, including mode and current fan RPM.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CoolingApi;


CoolingApi apiInstance = new CoolingApi();
try {
    CoolingStatus result = apiInstance.getCooling();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CoolingApi#getCooling");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**CoolingStatus**](CoolingStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="setCoolingMode"></a>
# **setCoolingMode**
> CoolingConfig setCoolingMode(body)



The cooling configuration endpoint allows the user to control the fan mode.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.CoolingApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


CoolingApi apiInstance = new CoolingApi();
CoolingConfig body = new CoolingConfig(); // CoolingConfig | 
try {
    CoolingConfig result = apiInstance.setCoolingMode(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CoolingApi#setCoolingMode");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CoolingConfig**](CoolingConfig.md)|  |

### Return type

[**CoolingConfig**](CoolingConfig.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

