# TemperatureResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**temperatureData** | [**TemperatureResponseTemperaturedata**](TemperatureResponseTemperaturedata.md) |  |  [optional]
