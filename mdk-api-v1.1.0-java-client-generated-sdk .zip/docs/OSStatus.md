# OSStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memTotalKb** | **Integer** |  |  [optional]
**memFreeKb** | **Integer** |  |  [optional]
**cpuLoadPercent** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**rootfsTotalMb** | **Integer** |  |  [optional]
**rootfsFreeMb** | **Integer** |  |  [optional]
