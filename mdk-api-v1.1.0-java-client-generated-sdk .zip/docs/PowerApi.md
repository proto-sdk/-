# PowerApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getHashboardPower**](PowerApi.md#getHashboardPower) | **GET** /api/v1/power/{hb_sn} | 
[**getMinerPower**](PowerApi.md#getMinerPower) | **GET** /api/v1/power | 

<a name="getHashboardPower"></a>
# **getHashboardPower**
> PowerResponse getHashboardPower(hbSn, duration)



The power endpoint provides hashboard-level historical operation data.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PowerApi;


PowerApi apiInstance = new PowerApi();
String hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide power information for.
String duration = "12h"; // String | 
try {
    PowerResponse result = apiInstance.getHashboardPower(hbSn, duration);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PowerApi#getHashboardPower");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide power information for. |
 **duration** | **String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**PowerResponse**](PowerResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMinerPower"></a>
# **getMinerPower**
> PowerResponse getMinerPower(duration)



The power endpoint provides miner-level historical power operation data.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PowerApi;


PowerApi apiInstance = new PowerApi();
String duration = "12h"; // String | 
try {
    PowerResponse result = apiInstance.getMinerPower(duration);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PowerApi#getMinerPower");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**PowerResponse**](PowerResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

