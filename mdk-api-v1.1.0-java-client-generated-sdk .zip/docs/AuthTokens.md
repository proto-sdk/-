# AuthTokens

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**refreshToken** | **String** | JWT refresh token. | 
**accessToken** | **String** | JWT access token. | 
