# EfficiencyResponseEfficiencydata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**duration** | [**DurationEnum**](#DurationEnum) | Duration of power data returned. |  [optional]
**data** | [**List&lt;TimeSeriesData&gt;**](TimeSeriesData.md) |  |  [optional]
**aggregates** | [**Aggregates**](Aggregates.md) |  |  [optional]

<a name="DurationEnum"></a>
## Enum: DurationEnum
Name | Value
---- | -----
_12H | &quot;12h&quot;
_24H | &quot;24h&quot;
_48H | &quot;48h&quot;
_5D | &quot;5d&quot;
