# HashboardStatsHashboardstats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hbSn** | **String** | Manufacturing serial number of the hashboard, used for subsequent API calls. |  [optional]
**hbId** | **String** | Internal ID of the hashboard, assigned to each hashboard starting from 0. |  [optional]
**status** | [**StatusEnum**](#StatusEnum) | The current state or condition of the hashboard. |  [optional]
**powerUsageWatts** | **Integer** | The power consumption of the hashboard in watts. |  [optional]
**voltageMv** | **Integer** | The present voltage being supplied to the hashboard in millivolts. |  [optional]
**avgAsicTempC** | [**BigDecimal**](BigDecimal.md) | Current average temperature of the hashboard in celsius. |  [optional]
**hashrateGhs** | [**BigDecimal**](BigDecimal.md) | The current hash rate of the hashboard, measured in GH/s. It will be sum of all ASIC hashrate_ghs values. |  [optional]
**idealHashrateGhs** | [**BigDecimal**](BigDecimal.md) | The expected hashrate is determined by the clock frequency of the all ASIC on the hash board, measured in GH/s. |  [optional]
**efficiencyJth** | [**BigDecimal**](BigDecimal.md) | The efficiency of the hashboard in joules per terahash. |  [optional]
**asics** | [**List&lt;AsicStats&gt;**](AsicStats.md) |  |  [optional]

<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----
RUNNING | &quot;Running&quot;
STOPPED | &quot;Stopped&quot;
ERROR | &quot;Error&quot;
OVERHEATED | &quot;Overheated&quot;
UNKNOWN | &quot;Unknown&quot;
