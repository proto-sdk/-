# AuthenticationApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1AuthLogoutPost**](AuthenticationApi.md#apiV1AuthLogoutPost) | **POST** /api/v1/auth/logout | User logout
[**apiV1AuthRefreshPost**](AuthenticationApi.md#apiV1AuthRefreshPost) | **POST** /api/v1/auth/refresh | Refresh JWT access token
[**login**](AuthenticationApi.md#login) | **POST** /api/v1/auth/login | 
[**setPassword**](AuthenticationApi.md#setPassword) | **PUT** /api/v1/auth/password | 

<a name="apiV1AuthLogoutPost"></a>
# **apiV1AuthLogoutPost**
> MessageResponse apiV1AuthLogoutPost(body)

User logout

Validates and blacklists JWT tokens, effectively logging out the user.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AuthenticationApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


AuthenticationApi apiInstance = new AuthenticationApi();
AuthTokens body = new AuthTokens(); // AuthTokens | 
try {
    MessageResponse result = apiInstance.apiV1AuthLogoutPost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AuthenticationApi#apiV1AuthLogoutPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AuthTokens**](AuthTokens.md)|  |

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="apiV1AuthRefreshPost"></a>
# **apiV1AuthRefreshPost**
> RefreshResponse apiV1AuthRefreshPost(body)

Refresh JWT access token

Validates the provided refresh token and returns a new JWT access token.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AuthenticationApi;


AuthenticationApi apiInstance = new AuthenticationApi();
RefreshRequest body = new RefreshRequest(); // RefreshRequest | 
try {
    RefreshResponse result = apiInstance.apiV1AuthRefreshPost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AuthenticationApi#apiV1AuthRefreshPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RefreshRequest**](RefreshRequest.md)|  |

### Return type

[**RefreshResponse**](RefreshResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="login"></a>
# **login**
> AuthTokens login(body)



Authenticates a user using a password and returns a JWT access and refresh token pair.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AuthenticationApi;


AuthenticationApi apiInstance = new AuthenticationApi();
PasswordRequest body = new PasswordRequest(); // PasswordRequest | 
try {
    AuthTokens result = apiInstance.login(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AuthenticationApi#login");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PasswordRequest**](PasswordRequest.md)|  |

### Return type

[**AuthTokens**](AuthTokens.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="setPassword"></a>
# **setPassword**
> MessageResponse setPassword(body)



The password endpoint allows users to set a password during onboarding

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.AuthenticationApi;


AuthenticationApi apiInstance = new AuthenticationApi();
PasswordRequest body = new PasswordRequest(); // PasswordRequest | 
try {
    MessageResponse result = apiInstance.setPassword(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AuthenticationApi#setPassword");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PasswordRequest**](PasswordRequest.md)|  |

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

