# MiningStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**miningStatus** | [**MiningStatusMiningstatus**](MiningStatusMiningstatus.md) |  |  [optional]
