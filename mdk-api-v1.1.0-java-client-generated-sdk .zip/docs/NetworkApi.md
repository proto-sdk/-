# NetworkApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getNetwork**](NetworkApi.md#getNetwork) | **GET** /api/v1/network | 
[**setNetworkConfig**](NetworkApi.md#setNetworkConfig) | **PUT** /api/v1/network | 

<a name="getNetwork"></a>
# **getNetwork**
> NetworkInfo getNetwork()



The network GET endpoint provides information related to the network configuration of the miner including IP address, gateways, and MAC address.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.NetworkApi;


NetworkApi apiInstance = new NetworkApi();
try {
    NetworkInfo result = apiInstance.getNetwork();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling NetworkApi#getNetwork");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="setNetworkConfig"></a>
# **setNetworkConfig**
> NetworkInfo setNetworkConfig(body)



The network PUT endpoint allows the user to change the configuration of the miner between DHCP and a static IP.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.NetworkApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


NetworkApi apiInstance = new NetworkApi();
NetworkConfig body = new NetworkConfig(); // NetworkConfig | 
try {
    NetworkInfo result = apiInstance.setNetworkConfig(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling NetworkApi#setNetworkConfig");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NetworkConfig**](NetworkConfig.md)|  |

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

