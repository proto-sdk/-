# HashboardsInfoHashboardsinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HbSn** | **string** | Hashboard serial number. | [optional] [default to null]
**Firmware** | [***FwInfo**](FWInfo.md) |  | [optional] [default to null]
**Bootloader** | [***FwInfo**](FWInfo.md) |  | [optional] [default to null]
**ApiVersion** | **string** |  | [optional] [default to null]
**Board** | **string** |  | [optional] [default to null]
**ChipId** | **string** |  | [optional] [default to null]
**MiningAsic** | **string** |  | [optional] [default to null]
**MiningAsicCount** | **int32** | Number of asics on the hashboard. | [optional] [default to null]
**TempSensorCount** | **int32** | Number of temperature sensors on the hashboard. | [optional] [default to null]
**Port** | **int32** | The USB port number the hashboard is connected to. | [optional] [default to null]
**EcLogsPath** | **string** | The absolute path where EC logs are stored. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

