# NotificationError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Source** | **string** |  | [optional] [default to null]
**ComponentIndex** | **int32** |  | [optional] [default to null]
**HashboardIndex** | **int32** |  | [optional] [default to null]
**AsicIndex** | **int32** |  | [optional] [default to null]
**ErrorCode** | **string** |  | [optional] [default to null]
**InsertedAt** | **int32** |  | [optional] [default to null]
**ExpiredAt** | **int32** |  | [optional] [default to null]
**ErrorLevel** | **string** |  | [optional] [default to null]
**Message** | **string** |  | [optional] [default to null]
**Details** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

