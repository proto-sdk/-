# RefreshRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RefreshToken** | **string** | The JWT refresh token to be validated. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

