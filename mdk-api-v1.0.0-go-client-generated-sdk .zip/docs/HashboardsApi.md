# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAllHashboards**](HashboardsApi.md#GetAllHashboards) | **Get** /api/v1/hashboards | 
[**GetAsicStatus**](HashboardsApi.md#GetAsicStatus) | **Get** /api/v1/hashboards/{hb_sn}/{asic_id} | 
[**GetHashboardLogs**](HashboardsApi.md#GetHashboardLogs) | **Get** /api/v1/hashboards/{hb_sn}/logs | 
[**GetHashboardStatus**](HashboardsApi.md#GetHashboardStatus) | **Get** /api/v1/hashboards/{hb_sn} | 

# **GetAllHashboards**
> HashboardsInfo GetAllHashboards(ctx, )


The hashboards endpoint provides information about all of the hashboards connected to the system, including firmware version, MCU, ASIC count, API version, and hardware serial numbers.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**HashboardsInfo**](HashboardsInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetAsicStatus**
> AsicStatsResponse GetAsicStatus(ctx, hbSn, asicId)


The hashboard status endpoint returns current operating statistics for a single ASIC on the specified hashboard in the system based on serial number and ASIC ID.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **hbSn** | **string**| The serial number of the hashboard to provide statistics for. | 
  **asicId** | **string**| The id of an ASIC to provide statistics for. | 

### Return type

[**AsicStatsResponse**](AsicStatsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetHashboardLogs**
> LogsResponse GetHashboardLogs(ctx, hbSn, optional)


The hashboard logs endpoint provides the most recent log lines from the specified hashboard.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **hbSn** | **string**| The serial number of the hashboard to provide statistics for. | 
 **optional** | ***HashboardsApiGetHashboardLogsOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a HashboardsApiGetHashboardLogsOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **lines** | **optional.Int32**| The number of most recent logs to return. Maximum of 500, defaults to 100. | [default to 100]

### Return type

[**LogsResponse**](LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetHashboardStatus**
> HashboardStats GetHashboardStatus(ctx, hbSn)


The hashboard status endpoint returns current operating statistics for a single hashboard in the system based on its serial number.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **hbSn** | **string**| The serial number of the hashboard to provide statistics for. | 

### Return type

[**HashboardStats**](HashboardStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

