# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetSystemStatus**](SystemInformationApi.md#GetSystemStatus) | **Get** /api/v1/system/status | 

# **GetSystemStatus**
> SystemStatuses GetSystemStatus(ctx, )


Get system statuses

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**SystemStatuses**](SystemStatuses.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

