# AsicStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Unique identifier assigned to each ASIC located on a hashboard, starting from 0. | [optional] [default to null]
**Row** | **int32** | Physical row location of the ASIC on the hashboard. | [optional] [default to null]
**Column** | **int32** | Physical column location of the ASIC on the hashboard. | [optional] [default to null]
**FreqMhz** | **float64** | The frequency of the ASIC measured in megahertz. | [optional] [default to null]
**TempC** | **float64** | Current temperature of the ASIC in celsius | [optional] [default to null]
**HashrateGhs** | **float64** | The current hash rate of the ASIC, measured in GH/s. | [optional] [default to null]
**IdealHashrateGhs** | **float64** | The expected hashrate determined by the clock frequency of the ASIC, measured in GH/s. | [optional] [default to null]
**ErrorRate** | **float64** | The number of times that the ASIC produced an incorrect hash or an error during a specific period of time.  Error Rate (%) &#x3D; (Number of incorrect hash / Total number of expected Hash) x 100% | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

