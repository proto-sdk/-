# AuthTokens

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RefreshToken** | **string** | JWT refresh token. | [default to null]
**AccessToken** | **string** | JWT access token. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

