# HashboardStatsHashboardstats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HbSn** | **string** | Manufacturing serial number of the hashboard, used for subsequent API calls. | [optional] [default to null]
**HbId** | **string** | Internal ID of the hashboard, assigned to each hashboard starting from 0. | [optional] [default to null]
**Status** | **string** | The current state or condition of the hashboard. | [optional] [default to null]
**PowerUsageWatts** | **int32** | The power consumption of the hashboard in watts. | [optional] [default to null]
**VoltageMv** | **int32** | The present voltage being supplied to the hashboard in millivolts. | [optional] [default to null]
**AvgAsicTempC** | **float64** | Current average temperature of the hashboard in celsius. | [optional] [default to null]
**HashrateGhs** | **float64** | The current hash rate of the hashboard, measured in GH/s. It will be sum of all ASIC hashrate_ghs values. | [optional] [default to null]
**IdealHashrateGhs** | **float64** | The expected hashrate is determined by the clock frequency of the all ASIC on the hash board, measured in GH/s. | [optional] [default to null]
**EfficiencyJth** | **float64** | The efficiency of the hashboard in joules per terahash. | [optional] [default to null]
**Asics** | [**[]AsicStats**](AsicStats.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

