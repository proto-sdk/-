# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetHashboardEfficiency**](EfficiencyApi.md#GetHashboardEfficiency) | **Get** /api/v1/efficiency/{hb_sn} | 
[**GetMinerEfficiency**](EfficiencyApi.md#GetMinerEfficiency) | **Get** /api/v1/efficiency | 

# **GetHashboardEfficiency**
> EfficiencyResponse GetHashboardEfficiency(ctx, hbSn, optional)


The efficiency endpoint provides hashboard-level historical operation data.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **hbSn** | **string**| The serial number of the hashboard to provide power information for. | 
 **optional** | ***EfficiencyApiGetHashboardEfficiencyOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a EfficiencyApiGetHashboardEfficiencyOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **duration** | **optional.String**|  | [default to 12h]

### Return type

[**EfficiencyResponse**](EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetMinerEfficiency**
> EfficiencyResponse GetMinerEfficiency(ctx, optional)


The efficiency endpoint provides miner-level historical power operation data.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***EfficiencyApiGetMinerEfficiencyOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a EfficiencyApiGetMinerEfficiencyOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **optional.String**|  | [default to 12h]

### Return type

[**EfficiencyResponse**](EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

