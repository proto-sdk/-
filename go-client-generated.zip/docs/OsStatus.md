# OsStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MemTotalKb** | **int32** |  | [optional] [default to null]
**MemFreeKb** | **int32** |  | [optional] [default to null]
**CpuLoadPercent** | **float64** |  | [optional] [default to null]
**RootfsTotalMb** | **int32** |  | [optional] [default to null]
**RootfsFreeMb** | **int32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

