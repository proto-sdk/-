# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**EditMiningTarget**](MiningApi.md#EditMiningTarget) | **Put** /api/v1/mining/target | 
[**GetMiningStatus**](MiningApi.md#GetMiningStatus) | **Get** /api/v1/mining | 
[**GetMiningTarget**](MiningApi.md#GetMiningTarget) | **Get** /api/v1/mining/target | 
[**StartMining**](MiningApi.md#StartMining) | **Post** /api/v1/mining/start | 
[**StopMining**](MiningApi.md#StopMining) | **Post** /api/v1/mining/stop | 

# **EditMiningTarget**
> MiningTarget EditMiningTarget(ctx, body)


The mining target endpoint can be used to set a target power consumption for the miner. Once set, the mining device will operate to consume as close to that amount of power as possible. In the event that the device is unable to maintain its temperature within the allowed range, it may scale down and use less power.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**MiningTarget**](MiningTarget.md)|  | 

### Return type

[**MiningTarget**](MiningTarget.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetMiningStatus**
> MiningStatus GetMiningStatus(ctx, )


The mining endpoint provides summary information about the mining operations of the device. This includes device level hashrate statistics, overall miner status, and current power usage and target information.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**MiningStatus**](MiningStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetMiningTarget**
> MiningTarget GetMiningTarget(ctx, )


The mining target endpoint returns the current power target in watts that the miner is controlling for.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**MiningTarget**](MiningTarget.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **StartMining**
> MessageResponse StartMining(ctx, )


The start mining endpoint can be used to make the device start mining, into account the current power target of the system.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **StopMining**
> MessageResponse StopMining(ctx, )


The stop mining endpoint can be used to stop the device from mining, going into a minimal power mode with only the control board running.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

