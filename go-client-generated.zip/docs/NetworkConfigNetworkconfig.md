# NetworkConfigNetworkconfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Dhcp** | **bool** |  | [optional] [default to null]
**Ip** | **string** |  | [optional] [default to null]
**Netmask** | **string** |  | [optional] [default to null]
**Gateway** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

