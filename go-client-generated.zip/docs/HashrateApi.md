# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAsicHashrate**](HashrateApi.md#GetAsicHashrate) | **Get** /api/v1/hashrate/{hb_sn}/{asic_id} | 
[**GetHashboardHashrate**](HashrateApi.md#GetHashboardHashrate) | **Get** /api/v1/hashrate/{hb_sn} | 
[**GetMinerHashrate**](HashrateApi.md#GetMinerHashrate) | **Get** /api/v1/hashrate | 

# **GetAsicHashrate**
> HashrateResponse GetAsicHashrate(ctx, hbSn, asicId, optional)


The hashrate endpoint provides ASIC-level historical hashrate operation data.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **hbSn** | **string**| The serial number of the hashboard to provide hashrate information for. | 
  **asicId** | **int32**| The ID of the ASIC to provide hashrate information for. | 
 **optional** | ***HashrateApiGetAsicHashrateOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a HashrateApiGetAsicHashrateOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **duration** | **optional.String**|  | [default to 12h]
 **granularity** | **optional.String**|  | [default to 1m]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetHashboardHashrate**
> HashrateResponse GetHashboardHashrate(ctx, hbSn, optional)


The hashrate endpoint provides hashboard-level historical operation data.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **hbSn** | **string**| The serial number of the hashboard to provide hashrate information for. | 
 **optional** | ***HashrateApiGetHashboardHashrateOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a HashrateApiGetHashboardHashrateOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **duration** | **optional.String**|  | [default to 12h]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetMinerHashrate**
> HashrateResponse GetMinerHashrate(ctx, optional)


The hashrate endpoint provides miner-level historical hashrate operation data.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***HashrateApiGetMinerHashrateOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a HashrateApiGetMinerHashrateOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **optional.String**|  | [default to 12h]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

