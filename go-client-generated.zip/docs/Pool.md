# Pool

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Each pool has a unique ID from 0 to 2, with 0 representing the highest priority and 2 representing the lowest priority. | [optional] [default to null]
**Priority** | **int32** | Connection priority for this pool. Lower numbers are higher priorities, with 0 being the maximum. Duplicate priorities are not allowed. | [optional] [default to null]
**Url** | **string** | The pool URL is used to establish communication with the mining pool and it is essential that it includes the port information. | [optional] [default to null]
**User** | **string** | The user is an account that is used for authentication with the mining pool. In some cases, if the user has multiple mining devices, the pool may assign a worker name as the username for each mining device. | [optional] [default to null]
**Status** | **string** | The status field indicates the state of the mining pool. An \&quot;Idle\&quot; status indiciates that the pool is available but not currently in use (due to priority). An \&quot;Active\&quot; status means that the pool is currently active. A \&quot;Dead\&quot; status indicates that the mining device is unable to establish a connection with the pool. | [optional] [default to null]
**Protocol** | **string** | The protocol being used for communication with the mining pool. | [optional] [default to null]
**Accepted** | **int32** | The number of shares that have been accepted by the mining pool as valid solutions to a mining problem. | [optional] [default to null]
**Rejected** | **int32** | The number of shares submitted by the miner to the pool that were not accepted because they did not meet the required difficulty level or other criteria. | [optional] [default to null]
**Invalid** | **int32** | The number of shares the pool interface rejected due to being too low difficulty (did not forward to the pool). | [optional] [default to null]
**NotifysReceived** | **int32** | The number of notify messages (new jobs) received from the pool. | [optional] [default to null]
**WorksGenerated** | **int32** | The number of works that were generated from the job notify messages. | [optional] [default to null]
**BlocksSeen** | **int32** | The number of mined blocks seen during mining (not necessarily found by miner). | [optional] [default to null]
**CurrentWorks** | **float64** | The current number of works in use by the miner. | [optional] [default to null]
**CurrentDifficulty** | **float64** | The current difficulty from the pool. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

