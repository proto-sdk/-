# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetSystemInfo**](SystemApi.md#GetSystemInfo) | **Get** /api/v1/system | 
[**GetSystemLogs**](SystemApi.md#GetSystemLogs) | **Get** /api/v1/system/logs | 
[**LocateSystem**](SystemApi.md#LocateSystem) | **Post** /api/v1/system/locate | 
[**RebootSystem**](SystemApi.md#RebootSystem) | **Post** /api/v1/system/reboot | 

# **GetSystemInfo**
> SystemInfo GetSystemInfo(ctx, )


The system endpoint provides information related to the control board including OS, software, and hardware component details.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**SystemInfo**](SystemInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetSystemLogs**
> LogsResponse GetSystemLogs(ctx, optional)


The logs endpoint provides the most recent log lines from a given source, either OS, pool software, or miner logs.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***SystemApiGetSystemLogsOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a SystemApiGetSystemLogsOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lines** | **optional.Int32**| Number of log lines to return from the tail of the log, up to a maximum of 10000 lines. Defaults to 100 lines. | [default to 100]
 **source** | **optional.String**| Source of logs to fetch. Defaults to miner software logs. | [default to miner_sw]

### Return type

[**LogsResponse**](LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **LocateSystem**
> MessageResponse LocateSystem(ctx, optional)


The locate system endpoint can be used to flash the indicator LED on the control board to assist in finding the miner.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***SystemApiLocateSystemOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a SystemApiLocateSystemOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ledOnTime** | **optional.Int32**| The duration in seconds for which to turn on the LED, with a max value of 300 seconds. If not specified, a default value of 30 seconds will be used. Requests made while the LED is on will be ignored. | [default to 30]

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **RebootSystem**
> MessageResponse RebootSystem(ctx, )


The reboot endpoint can be used to reboot the entire system.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

