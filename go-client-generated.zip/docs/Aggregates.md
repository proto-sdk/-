# Aggregates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Min** | **int32** | Minimum value in data. | [optional] [default to null]
**Avg** | **int32** | Average value in data. | [optional] [default to null]
**Max** | **int32** | Maximum value in data. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

