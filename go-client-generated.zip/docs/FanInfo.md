# FanInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Each fan is assigned a unique identifier starting from 0. | [optional] [default to null]
**Rpm** | **int32** | The fan&#x27;s current rotations per minute (RPM). | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

