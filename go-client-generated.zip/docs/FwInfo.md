# FwInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Version** | **string** |  | [optional] [default to null]
**GitHash** | **string** |  | [optional] [default to null]
**ImageHash** | **string** |  | [optional] [default to null]
**Build** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

