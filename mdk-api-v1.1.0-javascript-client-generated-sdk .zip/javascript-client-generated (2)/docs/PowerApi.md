# MiningDevelopmentKitApi.PowerApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getHashboardPower**](PowerApi.md#getHashboardPower) | **GET** /api/v1/power/{hb_sn} | 
[**getMinerPower**](PowerApi.md#getMinerPower) | **GET** /api/v1/power | 

<a name="getHashboardPower"></a>
# **getHashboardPower**
> PowerResponse getHashboardPower(hbSn, opts)



The power endpoint provides hashboard-level historical operation data.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.PowerApi();
let hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide power information for.
let opts = { 
  'duration': "12h" // String | 
};
apiInstance.getHashboardPower(hbSn, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide power information for. | 
 **duration** | **String**|  | [optional] [default to 12h]

### Return type

[**PowerResponse**](PowerResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMinerPower"></a>
# **getMinerPower**
> PowerResponse getMinerPower(opts)



The power endpoint provides miner-level historical power operation data.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.PowerApi();
let opts = { 
  'duration': "12h" // String | 
};
apiInstance.getMinerPower(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **String**|  | [optional] [default to 12h]

### Return type

[**PowerResponse**](PowerResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

