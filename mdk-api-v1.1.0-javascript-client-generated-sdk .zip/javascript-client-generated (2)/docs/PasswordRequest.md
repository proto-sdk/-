# MiningDevelopmentKitApi.PasswordRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**password** | **String** | The password for the user | 
