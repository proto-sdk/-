# MiningDevelopmentKitApi.CoolingStatusCoolingstatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fanMode** | **String** | Parameter to show the current fan mode. | [optional] 
**fans** | [**[FanInfo]**](FanInfo.md) | This will show speed of all fans in the system. | [optional] 

<a name="FanModeEnum"></a>
## Enum: FanModeEnum

* `off` (value: `"Off"`)
* `auto` (value: `"Auto"`)
* `max` (value: `"Max"`)

