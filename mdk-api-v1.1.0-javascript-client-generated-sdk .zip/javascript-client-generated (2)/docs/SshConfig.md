# MiningDevelopmentKitApi.SshConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sshStatus** | [**SshStatus**](SshStatus.md) |  | [optional] 
