# MiningDevelopmentKitApi.LogsResponseLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source** | **String** | Source of logs. | [optional] 
**lines** | **Number** | Number of lines returned. | [optional] 
**content** | **[String]** |  | [optional] 
