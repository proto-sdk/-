# MiningDevelopmentKitApi.HashrateApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAsicHashrate**](HashrateApi.md#getAsicHashrate) | **GET** /api/v1/hashrate/{hb_sn}/{asic_id} | 
[**getHashboardHashrate**](HashrateApi.md#getHashboardHashrate) | **GET** /api/v1/hashrate/{hb_sn} | 
[**getMinerHashrate**](HashrateApi.md#getMinerHashrate) | **GET** /api/v1/hashrate | 

<a name="getAsicHashrate"></a>
# **getAsicHashrate**
> HashrateResponse getAsicHashrate(hbSn, asicId, opts)



The hashrate endpoint provides ASIC-level historical hashrate operation data.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.HashrateApi();
let hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide hashrate information for.
let asicId = 56; // Number | The ID of the ASIC to provide hashrate information for.
let opts = { 
  'duration': "12h", // String | 
  'granularity': "1m" // String | 
};
apiInstance.getAsicHashrate(hbSn, asicId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide hashrate information for. | 
 **asicId** | **Number**| The ID of the ASIC to provide hashrate information for. | 
 **duration** | **String**|  | [optional] [default to 12h]
 **granularity** | **String**|  | [optional] [default to 1m]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getHashboardHashrate"></a>
# **getHashboardHashrate**
> HashrateResponse getHashboardHashrate(hbSn, opts)



The hashrate endpoint provides hashboard-level historical operation data.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.HashrateApi();
let hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide hashrate information for.
let opts = { 
  'duration': "12h" // String | 
};
apiInstance.getHashboardHashrate(hbSn, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide hashrate information for. | 
 **duration** | **String**|  | [optional] [default to 12h]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMinerHashrate"></a>
# **getMinerHashrate**
> HashrateResponse getMinerHashrate(opts)



The hashrate endpoint provides miner-level historical hashrate operation data.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.HashrateApi();
let opts = { 
  'duration': "12h" // String | 
};
apiInstance.getMinerHashrate(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **String**|  | [optional] [default to 12h]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

