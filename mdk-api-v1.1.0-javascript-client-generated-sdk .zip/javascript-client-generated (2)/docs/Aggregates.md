# MiningDevelopmentKitApi.Aggregates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min** | **Number** | Minimum value in data. | [optional] 
**avg** | **Number** | Average value in data. | [optional] 
**max** | **Number** | Maximum value in data. | [optional] 
