# MiningDevelopmentKitApi.OSStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memTotalKb** | **Number** |  | [optional] 
**memFreeKb** | **Number** |  | [optional] 
**cpuLoadPercent** | **Number** |  | [optional] 
**rootfsTotalMb** | **Number** |  | [optional] 
**rootfsFreeMb** | **Number** |  | [optional] 
