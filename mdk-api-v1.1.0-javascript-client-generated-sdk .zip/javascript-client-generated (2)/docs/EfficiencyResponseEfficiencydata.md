# MiningDevelopmentKitApi.EfficiencyResponseEfficiencydata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**duration** | **String** | Duration of power data returned. | [optional] 
**data** | [**[TimeSeriesData]**](TimeSeriesData.md) |  | [optional] 
**aggregates** | [**Aggregates**](Aggregates.md) |  | [optional] 

<a name="DurationEnum"></a>
## Enum: DurationEnum

* `_12h` (value: `"12h"`)
* `_24h` (value: `"24h"`)
* `_48h` (value: `"48h"`)
* `_5d` (value: `"5d"`)

