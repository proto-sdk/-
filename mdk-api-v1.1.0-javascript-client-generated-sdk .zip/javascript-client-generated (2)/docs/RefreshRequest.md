# MiningDevelopmentKitApi.RefreshRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**refreshToken** | **String** | The JWT refresh token to be validated. | 
