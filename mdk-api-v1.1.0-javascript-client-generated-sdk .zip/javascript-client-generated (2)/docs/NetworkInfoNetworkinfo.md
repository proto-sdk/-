# MiningDevelopmentKitApi.NetworkInfoNetworkinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mac** | **String** |  | [optional] 
**dhcp** | **Boolean** |  | [optional] 
**ip** | **String** |  | [optional] 
**netmask** | **String** |  | [optional] 
**gateway** | **String** |  | [optional] 
