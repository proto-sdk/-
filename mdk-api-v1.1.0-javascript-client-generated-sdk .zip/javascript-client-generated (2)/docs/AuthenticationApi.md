# MiningDevelopmentKitApi.AuthenticationApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1AuthLogoutPost**](AuthenticationApi.md#apiV1AuthLogoutPost) | **POST** /api/v1/auth/logout | User logout
[**apiV1AuthRefreshPost**](AuthenticationApi.md#apiV1AuthRefreshPost) | **POST** /api/v1/auth/refresh | Refresh JWT access token
[**login**](AuthenticationApi.md#login) | **POST** /api/v1/auth/login | 
[**setPassword**](AuthenticationApi.md#setPassword) | **PUT** /api/v1/auth/password | 

<a name="apiV1AuthLogoutPost"></a>
# **apiV1AuthLogoutPost**
> MessageResponse apiV1AuthLogoutPost(body)

User logout

Validates and blacklists JWT tokens, effectively logging out the user.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';
let defaultClient = MiningDevelopmentKitApi.ApiClient.instance;


let apiInstance = new MiningDevelopmentKitApi.AuthenticationApi();
let body = new MiningDevelopmentKitApi.AuthTokens(); // AuthTokens | 

apiInstance.apiV1AuthLogoutPost(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AuthTokens**](AuthTokens.md)|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="apiV1AuthRefreshPost"></a>
# **apiV1AuthRefreshPost**
> RefreshResponse apiV1AuthRefreshPost(body)

Refresh JWT access token

Validates the provided refresh token and returns a new JWT access token.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.AuthenticationApi();
let body = new MiningDevelopmentKitApi.RefreshRequest(); // RefreshRequest | 

apiInstance.apiV1AuthRefreshPost(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RefreshRequest**](RefreshRequest.md)|  | 

### Return type

[**RefreshResponse**](RefreshResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="login"></a>
# **login**
> AuthTokens login(body)



Authenticates a user using a password and returns a JWT access and refresh token pair.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.AuthenticationApi();
let body = new MiningDevelopmentKitApi.PasswordRequest(); // PasswordRequest | 

apiInstance.login(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PasswordRequest**](PasswordRequest.md)|  | 

### Return type

[**AuthTokens**](AuthTokens.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="setPassword"></a>
# **setPassword**
> MessageResponse setPassword(body)



The password endpoint allows users to set a password during onboarding

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.AuthenticationApi();
let body = new MiningDevelopmentKitApi.PasswordRequest(); // PasswordRequest | 

apiInstance.setPassword(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PasswordRequest**](PasswordRequest.md)|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

