# MiningDevelopmentKitApi.NetworkConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**networkConfig** | [**NetworkConfigNetworkconfig**](NetworkConfigNetworkconfig.md) |  | [optional] 
