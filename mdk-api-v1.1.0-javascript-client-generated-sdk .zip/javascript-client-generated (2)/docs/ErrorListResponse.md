# MiningDevelopmentKitApi.ErrorListResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
