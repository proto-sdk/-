# MiningDevelopmentKitApi.NotificationError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source** | **String** |  | [optional] 
**componentIndex** | **Number** |  | [optional] 
**hashboardIndex** | **Number** |  | [optional] 
**asicIndex** | **Number** |  | [optional] 
**errorCode** | **String** |  | [optional] 
**insertedAt** | **Number** |  | [optional] 
**expiredAt** | **Number** |  | [optional] 
**errorLevel** | **String** |  | [optional] 
**message** | **String** |  | [optional] 
**details** | **String** |  | [optional] 

<a name="SourceEnum"></a>
## Enum: SourceEnum

* `miner` (value: `"Miner"`)
* `hashboard` (value: `"Hashboard"`)
* `ASIC` (value: `"ASIC"`)


<a name="ErrorLevelEnum"></a>
## Enum: ErrorLevelEnum

* `error` (value: `"Error"`)
* `warning` (value: `"Warning"`)

