# MiningDevelopmentKitApi.SshResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sshStatus** | [**SshStatus**](SshStatus.md) |  | [optional] 
