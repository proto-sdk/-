# MiningDevelopmentKitApi.FWInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** |  | [optional] 
**gitHash** | **String** |  | [optional] 
**imageHash** | **String** |  | [optional] 
**build** | **String** |  | [optional] 

<a name="BuildEnum"></a>
## Enum: BuildEnum

* `debug` (value: `"debug"`)
* `release` (value: `"release"`)

