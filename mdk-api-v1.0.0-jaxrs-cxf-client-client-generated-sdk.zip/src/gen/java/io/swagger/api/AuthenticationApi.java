package io.swagger.api;

import io.swagger.model.AuthTokens;
import io.swagger.model.MessageResponse;
import io.swagger.model.PasswordRequest;
import io.swagger.model.RefreshRequest;
import io.swagger.model.RefreshResponse;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Mining Development Kit API
 *
 * <p>The Mining Development Kit API serves as a means to access information from the mining device and make necessary adjustments to its settings.
 *
 */
@Path("/")
public interface AuthenticationApi  {

    /**
     * User logout
     *
     * Validates and blacklists JWT tokens, effectively logging out the user.
     *
     */
    @POST
    @Path("/api/v1/auth/logout")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "User logout", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful logout.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "401", description = "Unauthorized.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public MessageResponse apiV1AuthLogoutPost(AuthTokens body);

    /**
     * Refresh JWT access token
     *
     * Validates the provided refresh token and returns a new JWT access token.
     *
     */
    @POST
    @Path("/api/v1/auth/refresh")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "Refresh JWT access token", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful refresh, returns a new access token.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = RefreshResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "401", description = "Unauthorized, invalid or expired refresh token.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public RefreshResponse apiV1AuthRefreshPost(RefreshRequest body);

    @POST
    @Path("/api/v1/auth/login")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successful login, returns JWT tokens.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = AuthTokens.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "401", description = "Unauthorized.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "403", description = "Forbidden.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public AuthTokens login(PasswordRequest body);

    @PUT
    @Path("/api/v1/auth/password")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Password successfully set.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "403", description = "Forbidden.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public MessageResponse setPassword(PasswordRequest body);
}
