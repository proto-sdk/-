package io.swagger.api;

import io.swagger.model.SystemStatuses;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Mining Development Kit API
 *
 * <p>The Mining Development Kit API serves as a means to access information from the mining device and make necessary adjustments to its settings.
 *
 */
@Path("/")
public interface SystemInformationApi  {

    @GET
    @Path("/api/v1/system/status")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "The onboarded status of the mining device.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = SystemStatuses.class))) })
    public SystemStatuses getSystemStatus();
}
