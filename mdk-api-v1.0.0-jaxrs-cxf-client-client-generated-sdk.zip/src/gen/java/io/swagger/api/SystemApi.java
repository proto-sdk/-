package io.swagger.api;

import io.swagger.model.LogsResponse;
import io.swagger.model.MessageResponse;
import io.swagger.model.SshConfig;
import io.swagger.model.SshResponse;
import io.swagger.model.SystemInfo;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Mining Development Kit API
 *
 * <p>The Mining Development Kit API serves as a means to access information from the mining device and make necessary adjustments to its settings.
 *
 */
@Path("/")
public interface SystemApi  {

    @GET
    @Path("/api/v1/system/ssh")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "The SSH status was successfully returned.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = SshResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public SshResponse getSSH();

    @GET
    @Path("/api/v1/system")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "The mining device system information.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = SystemInfo.class))) })
    public SystemInfo getSystemInfo();

    @GET
    @Path("/api/v1/system/logs")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Successfully returned linux system, miner pool interface, or MCDD logs.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = LogsResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "422", description = "Unprocessable request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public LogsResponse getSystemLogs(@QueryParam("lines")@DefaultValue("100") Integer lines, @QueryParam("source")@DefaultValue("miner_sw") String source);

    @POST
    @Path("/api/v1/system/locate")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "202", description = "The mining device's LED has started flashing for the specified duration", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "422", description = "Unprocessable request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public MessageResponse locateSystem(@QueryParam("led_on_time")@DefaultValue("30") Integer ledOnTime);

    @POST
    @Path("/api/v1/system/reboot")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "202", description = "System reboot command was accepted.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "401", description = "Authentication failed.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public MessageResponse rebootSystem();

    @PUT
    @Path("/api/v1/system/ssh")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "The SSH status was successfully updated", content = @Content(mediaType = "application/json", schema = @Schema(implementation = SshResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "401", description = "Authentication failed.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "422", description = "Unprocessable request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public SshResponse setSSH(SshConfig body);

    @POST
    @Path("/api/v1/system/update")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "202", description = "The mining device has successfully started the update process.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "401", description = "Authentication failed.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "422", description = "Unprocessable request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public MessageResponse updateSystem();
}
