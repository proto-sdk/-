package io.swagger.api;

import io.swagger.model.MessageResponse;
import io.swagger.model.MiningStatus;
import io.swagger.model.MiningTarget;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.MediaType;
import org.apache.cxf.jaxrs.ext.multipart.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Mining Development Kit API
 *
 * <p>The Mining Development Kit API serves as a means to access information from the mining device and make necessary adjustments to its settings.
 *
 */
@Path("/")
public interface MiningApi  {

    @PUT
    @Path("/api/v1/mining/target")
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "The mining target has been successfully updated.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MiningTarget.class))),
        @ApiResponse(responseCode = "400", description = "Bad request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "401", description = "Authentication failed.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "422", description = "Unprocessable request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public MiningTarget editMiningTarget(MiningTarget body);

    @GET
    @Path("/api/v1/mining")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Mining status information has been successfully returned.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MiningStatus.class))),
        @ApiResponse(responseCode = "204", description = "No mining statistics available.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public MiningStatus getMiningStatus();

    @GET
    @Path("/api/v1/mining/target")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "The mining target value was successfully returned.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MiningTarget.class))),
        @ApiResponse(responseCode = "204", description = "No mining statistics available.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public MiningTarget getMiningTarget();

    @POST
    @Path("/api/v1/mining/start")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "202", description = "Mining start command has been accepted.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "401", description = "Authentication failed.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "422", description = "Unprocessable request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public MessageResponse startMining();

    @POST
    @Path("/api/v1/mining/stop")
    @Produces({ "application/json" })
    @Operation(summary = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "202", description = "Mining stop command has been accepted.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "401", description = "Authentication failed.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "422", description = "Unprocessable request.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error.", content = @Content(mediaType = "application/json", schema = @Schema(implementation = MessageResponse.class))) })
    public MessageResponse stopMining();
}
