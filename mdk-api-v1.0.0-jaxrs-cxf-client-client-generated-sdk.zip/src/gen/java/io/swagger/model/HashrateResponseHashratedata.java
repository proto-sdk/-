package io.swagger.model;

import io.swagger.model.Aggregates;
import io.swagger.model.TimeSeriesData;
import java.util.ArrayList;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class HashrateResponseHashratedata   {
  public enum DurationEnum {
    _12H("12h"),
    _24H("24h"),
    _48H("48h"),
    _5D("5d");

    private String value;

    DurationEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static DurationEnum fromValue(String text) {
      for (DurationEnum b : DurationEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(description = "Duration of hashrate data returned.")
 /**
   * Duration of hashrate data returned.  
  **/
  private DurationEnum duration = null;
  
  @Schema(description = "")
  private List<TimeSeriesData> data = null;
  
  @Schema(description = "")
  private Aggregates aggregates = null;
 /**
   * Duration of hashrate data returned.
   * @return duration
  **/
  @JsonProperty("duration")
  public String getDuration() {
    if (duration == null) {
      return null;
    }
    return duration.getValue();
  }

  public void setDuration(DurationEnum duration) {
    this.duration = duration;
  }

  public HashrateResponseHashratedata duration(DurationEnum duration) {
    this.duration = duration;
    return this;
  }

 /**
   * Get data
   * @return data
  **/
  @JsonProperty("data")
  public List<TimeSeriesData> getData() {
    return data;
  }

  public void setData(List<TimeSeriesData> data) {
    this.data = data;
  }

  public HashrateResponseHashratedata data(List<TimeSeriesData> data) {
    this.data = data;
    return this;
  }

  public HashrateResponseHashratedata addDataItem(TimeSeriesData dataItem) {
    this.data.add(dataItem);
    return this;
  }

 /**
   * Get aggregates
   * @return aggregates
  **/
  @JsonProperty("aggregates")
  public Aggregates getAggregates() {
    return aggregates;
  }

  public void setAggregates(Aggregates aggregates) {
    this.aggregates = aggregates;
  }

  public HashrateResponseHashratedata aggregates(Aggregates aggregates) {
    this.aggregates = aggregates;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HashrateResponseHashratedata {\n");
    
    sb.append("    duration: ").append(toIndentedString(duration)).append("\n");
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("    aggregates: ").append(toIndentedString(aggregates)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
