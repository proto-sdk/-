package io.swagger.model;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class Pool   {
  
  @Schema(example = "0", description = "Each pool has a unique ID from 0 to 2, with 0 representing the highest priority and 2 representing the lowest priority.")
 /**
   * Each pool has a unique ID from 0 to 2, with 0 representing the highest priority and 2 representing the lowest priority.  
  **/
  private Integer id = null;
  
  @Schema(description = "Connection priority for this pool. Lower numbers are higher priorities, with 0 being the maximum. Duplicate priorities are not allowed.")
 /**
   * Connection priority for this pool. Lower numbers are higher priorities, with 0 being the maximum. Duplicate priorities are not allowed.  
  **/
  private Integer priority = null;
  
  @Schema(example = "pool1.com:3333", description = "The pool URL is used to establish communication with the mining pool and it is essential that it includes the port information.")
 /**
   * The pool URL is used to establish communication with the mining pool and it is essential that it includes the port information.  
  **/
  private String url = null;
  
  @Schema(example = "user1", description = "The user is an account that is used for authentication with the mining pool. In some cases, if the user has multiple mining devices, the pool may assign a worker name as the username for each mining device.")
 /**
   * The user is an account that is used for authentication with the mining pool. In some cases, if the user has multiple mining devices, the pool may assign a worker name as the username for each mining device.  
  **/
  private String user = null;
  public enum StatusEnum {
    UNKNOWN("Unknown"),
    IDLE("Idle"),
    ACTIVE("Active"),
    DEAD("Dead");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(description = "The status field indicates the state of the mining pool. An \"Idle\" status indiciates that the pool is available but not currently in use (due to priority). An \"Active\" status means that the pool is currently active. A \"Dead\" status indicates that the mining device is unable to establish a connection with the pool.")
 /**
   * The status field indicates the state of the mining pool. An \"Idle\" status indiciates that the pool is available but not currently in use (due to priority). An \"Active\" status means that the pool is currently active. A \"Dead\" status indicates that the mining device is unable to establish a connection with the pool.  
  **/
  private StatusEnum status = null;
  public enum ProtocolEnum {
    UNKNOWN("Unknown"),
    STRATUMV1("StratumV1"),
    STRATUMV2("StratumV2");

    private String value;

    ProtocolEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static ProtocolEnum fromValue(String text) {
      for (ProtocolEnum b : ProtocolEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(description = "The protocol being used for communication with the mining pool.")
 /**
   * The protocol being used for communication with the mining pool.  
  **/
  private ProtocolEnum protocol = null;
  
  @Schema(example = "100", description = "The number of shares that have been accepted by the mining pool as valid solutions to a mining problem.")
 /**
   * The number of shares that have been accepted by the mining pool as valid solutions to a mining problem.  
  **/
  private Integer accepted = null;
  
  @Schema(example = "20", description = "The number of shares submitted by the miner to the pool that were not accepted because they did not meet the required difficulty level or other criteria.")
 /**
   * The number of shares submitted by the miner to the pool that were not accepted because they did not meet the required difficulty level or other criteria.  
  **/
  private Integer rejected = null;
  
  @Schema(example = "10", description = "The number of shares the pool interface rejected due to being too low difficulty (did not forward to the pool).")
 /**
   * The number of shares the pool interface rejected due to being too low difficulty (did not forward to the pool).  
  **/
  private Integer invalid = null;
  
  @Schema(example = "10", description = "The number of notify messages (new jobs) received from the pool.")
 /**
   * The number of notify messages (new jobs) received from the pool.  
  **/
  private Integer notifysReceived = null;
  
  @Schema(example = "10", description = "The number of works that were generated from the job notify messages.")
 /**
   * The number of works that were generated from the job notify messages.  
  **/
  private Integer worksGenerated = null;
  
  @Schema(example = "10", description = "The number of mined blocks seen during mining (not necessarily found by miner).")
 /**
   * The number of mined blocks seen during mining (not necessarily found by miner).  
  **/
  private Integer blocksSeen = null;
  
  @Schema(example = "134000", description = "The current number of works in use by the miner.")
 /**
   * The current number of works in use by the miner.  
  **/
  private BigDecimal currentWorks = null;
  
  @Schema(example = "134000", description = "The current difficulty from the pool.")
 /**
   * The current difficulty from the pool.  
  **/
  private BigDecimal currentDifficulty = null;
 /**
   * Each pool has a unique ID from 0 to 2, with 0 representing the highest priority and 2 representing the lowest priority.
   * @return id
  **/
  @JsonProperty("id")
  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Pool id(Integer id) {
    this.id = id;
    return this;
  }

 /**
   * Connection priority for this pool. Lower numbers are higher priorities, with 0 being the maximum. Duplicate priorities are not allowed.
   * @return priority
  **/
  @JsonProperty("priority")
  public Integer getPriority() {
    return priority;
  }

  public void setPriority(Integer priority) {
    this.priority = priority;
  }

  public Pool priority(Integer priority) {
    this.priority = priority;
    return this;
  }

 /**
   * The pool URL is used to establish communication with the mining pool and it is essential that it includes the port information.
   * @return url
  **/
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public Pool url(String url) {
    this.url = url;
    return this;
  }

 /**
   * The user is an account that is used for authentication with the mining pool. In some cases, if the user has multiple mining devices, the pool may assign a worker name as the username for each mining device.
   * @return user
  **/
  @JsonProperty("user")
  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public Pool user(String user) {
    this.user = user;
    return this;
  }

 /**
   * The status field indicates the state of the mining pool. An \&quot;Idle\&quot; status indiciates that the pool is available but not currently in use (due to priority). An \&quot;Active\&quot; status means that the pool is currently active. A \&quot;Dead\&quot; status indicates that the mining device is unable to establish a connection with the pool.
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.getValue();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public Pool status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * The protocol being used for communication with the mining pool.
   * @return protocol
  **/
  @JsonProperty("protocol")
  public String getProtocol() {
    if (protocol == null) {
      return null;
    }
    return protocol.getValue();
  }

  public void setProtocol(ProtocolEnum protocol) {
    this.protocol = protocol;
  }

  public Pool protocol(ProtocolEnum protocol) {
    this.protocol = protocol;
    return this;
  }

 /**
   * The number of shares that have been accepted by the mining pool as valid solutions to a mining problem.
   * @return accepted
  **/
  @JsonProperty("accepted")
  public Integer getAccepted() {
    return accepted;
  }

  public void setAccepted(Integer accepted) {
    this.accepted = accepted;
  }

  public Pool accepted(Integer accepted) {
    this.accepted = accepted;
    return this;
  }

 /**
   * The number of shares submitted by the miner to the pool that were not accepted because they did not meet the required difficulty level or other criteria.
   * @return rejected
  **/
  @JsonProperty("rejected")
  public Integer getRejected() {
    return rejected;
  }

  public void setRejected(Integer rejected) {
    this.rejected = rejected;
  }

  public Pool rejected(Integer rejected) {
    this.rejected = rejected;
    return this;
  }

 /**
   * The number of shares the pool interface rejected due to being too low difficulty (did not forward to the pool).
   * @return invalid
  **/
  @JsonProperty("invalid")
  public Integer getInvalid() {
    return invalid;
  }

  public void setInvalid(Integer invalid) {
    this.invalid = invalid;
  }

  public Pool invalid(Integer invalid) {
    this.invalid = invalid;
    return this;
  }

 /**
   * The number of notify messages (new jobs) received from the pool.
   * @return notifysReceived
  **/
  @JsonProperty("notifys_received")
  public Integer getNotifysReceived() {
    return notifysReceived;
  }

  public void setNotifysReceived(Integer notifysReceived) {
    this.notifysReceived = notifysReceived;
  }

  public Pool notifysReceived(Integer notifysReceived) {
    this.notifysReceived = notifysReceived;
    return this;
  }

 /**
   * The number of works that were generated from the job notify messages.
   * @return worksGenerated
  **/
  @JsonProperty("works_generated")
  public Integer getWorksGenerated() {
    return worksGenerated;
  }

  public void setWorksGenerated(Integer worksGenerated) {
    this.worksGenerated = worksGenerated;
  }

  public Pool worksGenerated(Integer worksGenerated) {
    this.worksGenerated = worksGenerated;
    return this;
  }

 /**
   * The number of mined blocks seen during mining (not necessarily found by miner).
   * @return blocksSeen
  **/
  @JsonProperty("blocks_seen")
  public Integer getBlocksSeen() {
    return blocksSeen;
  }

  public void setBlocksSeen(Integer blocksSeen) {
    this.blocksSeen = blocksSeen;
  }

  public Pool blocksSeen(Integer blocksSeen) {
    this.blocksSeen = blocksSeen;
    return this;
  }

 /**
   * The current number of works in use by the miner.
   * @return currentWorks
  **/
  @JsonProperty("current_works")
  public BigDecimal getCurrentWorks() {
    return currentWorks;
  }

  public void setCurrentWorks(BigDecimal currentWorks) {
    this.currentWorks = currentWorks;
  }

  public Pool currentWorks(BigDecimal currentWorks) {
    this.currentWorks = currentWorks;
    return this;
  }

 /**
   * The current difficulty from the pool.
   * @return currentDifficulty
  **/
  @JsonProperty("current_difficulty")
  public BigDecimal getCurrentDifficulty() {
    return currentDifficulty;
  }

  public void setCurrentDifficulty(BigDecimal currentDifficulty) {
    this.currentDifficulty = currentDifficulty;
  }

  public Pool currentDifficulty(BigDecimal currentDifficulty) {
    this.currentDifficulty = currentDifficulty;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Pool {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    priority: ").append(toIndentedString(priority)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    user: ").append(toIndentedString(user)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    protocol: ").append(toIndentedString(protocol)).append("\n");
    sb.append("    accepted: ").append(toIndentedString(accepted)).append("\n");
    sb.append("    rejected: ").append(toIndentedString(rejected)).append("\n");
    sb.append("    invalid: ").append(toIndentedString(invalid)).append("\n");
    sb.append("    notifysReceived: ").append(toIndentedString(notifysReceived)).append("\n");
    sb.append("    worksGenerated: ").append(toIndentedString(worksGenerated)).append("\n");
    sb.append("    blocksSeen: ").append(toIndentedString(blocksSeen)).append("\n");
    sb.append("    currentWorks: ").append(toIndentedString(currentWorks)).append("\n");
    sb.append("    currentDifficulty: ").append(toIndentedString(currentDifficulty)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
