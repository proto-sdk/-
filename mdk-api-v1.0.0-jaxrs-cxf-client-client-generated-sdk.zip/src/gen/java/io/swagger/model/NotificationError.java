package io.swagger.model;


import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class NotificationError   {
  public enum SourceEnum {
    MINER("Miner"),
    HASHBOARD("Hashboard"),
    ASIC("ASIC");

    private String value;

    SourceEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static SourceEnum fromValue(String text) {
      for (SourceEnum b : SourceEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(example = "Miner", description = "")
  private SourceEnum source = null;
  
  @Schema(description = "")
  private Integer componentIndex = null;
  
  @Schema(description = "")
  private Integer hashboardIndex = null;
  
  @Schema(description = "")
  private Integer asicIndex = null;
  
  @Schema(example = "FanSlow", description = "")
  private String errorCode = null;
  
  @Schema(description = "")
  private Integer insertedAt = null;
  
  @Schema(description = "")
  private Integer expiredAt = null;
  public enum ErrorLevelEnum {
    ERROR("Error"),
    WARNING("Warning");

    private String value;

    ErrorLevelEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static ErrorLevelEnum fromValue(String text) {
      for (ErrorLevelEnum b : ErrorLevelEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(description = "")
  private ErrorLevelEnum errorLevel = null;
  
  @Schema(example = "Fan 1 is not operating correctly.", description = "")
  private String message = null;
  
  @Schema(example = "{\"FanSlow\":{\"fan_rpm_target\":1000,\"fan_rpm_tach\":900}}", description = "")
  private String details = null;
 /**
   * Get source
   * @return source
  **/
  @JsonProperty("source")
  public String getSource() {
    if (source == null) {
      return null;
    }
    return source.getValue();
  }

  public void setSource(SourceEnum source) {
    this.source = source;
  }

  public NotificationError source(SourceEnum source) {
    this.source = source;
    return this;
  }

 /**
   * Get componentIndex
   * @return componentIndex
  **/
  @JsonProperty("component_index")
  public Integer getComponentIndex() {
    return componentIndex;
  }

  public void setComponentIndex(Integer componentIndex) {
    this.componentIndex = componentIndex;
  }

  public NotificationError componentIndex(Integer componentIndex) {
    this.componentIndex = componentIndex;
    return this;
  }

 /**
   * Get hashboardIndex
   * @return hashboardIndex
  **/
  @JsonProperty("hashboard_index")
  public Integer getHashboardIndex() {
    return hashboardIndex;
  }

  public void setHashboardIndex(Integer hashboardIndex) {
    this.hashboardIndex = hashboardIndex;
  }

  public NotificationError hashboardIndex(Integer hashboardIndex) {
    this.hashboardIndex = hashboardIndex;
    return this;
  }

 /**
   * Get asicIndex
   * @return asicIndex
  **/
  @JsonProperty("asic_index")
  public Integer getAsicIndex() {
    return asicIndex;
  }

  public void setAsicIndex(Integer asicIndex) {
    this.asicIndex = asicIndex;
  }

  public NotificationError asicIndex(Integer asicIndex) {
    this.asicIndex = asicIndex;
    return this;
  }

 /**
   * Get errorCode
   * @return errorCode
  **/
  @JsonProperty("error_code")
  public String getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  public NotificationError errorCode(String errorCode) {
    this.errorCode = errorCode;
    return this;
  }

 /**
   * Get insertedAt
   * @return insertedAt
  **/
  @JsonProperty("inserted_at")
  public Integer getInsertedAt() {
    return insertedAt;
  }

  public void setInsertedAt(Integer insertedAt) {
    this.insertedAt = insertedAt;
  }

  public NotificationError insertedAt(Integer insertedAt) {
    this.insertedAt = insertedAt;
    return this;
  }

 /**
   * Get expiredAt
   * @return expiredAt
  **/
  @JsonProperty("expired_at")
  public Integer getExpiredAt() {
    return expiredAt;
  }

  public void setExpiredAt(Integer expiredAt) {
    this.expiredAt = expiredAt;
  }

  public NotificationError expiredAt(Integer expiredAt) {
    this.expiredAt = expiredAt;
    return this;
  }

 /**
   * Get errorLevel
   * @return errorLevel
  **/
  @JsonProperty("error_level")
  public String getErrorLevel() {
    if (errorLevel == null) {
      return null;
    }
    return errorLevel.getValue();
  }

  public void setErrorLevel(ErrorLevelEnum errorLevel) {
    this.errorLevel = errorLevel;
  }

  public NotificationError errorLevel(ErrorLevelEnum errorLevel) {
    this.errorLevel = errorLevel;
    return this;
  }

 /**
   * Get message
   * @return message
  **/
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public NotificationError message(String message) {
    this.message = message;
    return this;
  }

 /**
   * Get details
   * @return details
  **/
  @JsonProperty("details")
  public String getDetails() {
    return details;
  }

  public void setDetails(String details) {
    this.details = details;
  }

  public NotificationError details(String details) {
    this.details = details;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class NotificationError {\n");
    
    sb.append("    source: ").append(toIndentedString(source)).append("\n");
    sb.append("    componentIndex: ").append(toIndentedString(componentIndex)).append("\n");
    sb.append("    hashboardIndex: ").append(toIndentedString(hashboardIndex)).append("\n");
    sb.append("    asicIndex: ").append(toIndentedString(asicIndex)).append("\n");
    sb.append("    errorCode: ").append(toIndentedString(errorCode)).append("\n");
    sb.append("    insertedAt: ").append(toIndentedString(insertedAt)).append("\n");
    sb.append("    expiredAt: ").append(toIndentedString(expiredAt)).append("\n");
    sb.append("    errorLevel: ").append(toIndentedString(errorLevel)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
