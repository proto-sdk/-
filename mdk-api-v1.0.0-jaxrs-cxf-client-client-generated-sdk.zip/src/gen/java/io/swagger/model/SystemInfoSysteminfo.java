package io.swagger.model;

import io.swagger.model.OSInfo;
import io.swagger.model.SWInfo;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class SystemInfoSysteminfo   {
  
  @Schema(description = "")
  private OSInfo os = null;
  
  @Schema(description = "")
  private SWInfo poolInterfaceSw = null;
  
  @Schema(description = "")
  private SWInfo miningDriverSw = null;
  
  @Schema(description = "")
  private SWInfo webServer = null;
  
  @Schema(example = "300", description = "")
  private Long uptimeSeconds = null;
  public enum BoardEnum {
    STM32MP157D_DK1("stm32mp157d-dk1"),
    STM32MP157F_DK2("stm32mp157f-dk2"),
    C1_P0("c1-p0"),
    C1_EVT("c1-evt"),
    UNKNOWN("unknown");

    private String value;

    BoardEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static BoardEnum fromValue(String text) {
      for (BoardEnum b : BoardEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(example = "c1-evt", description = "")
  private BoardEnum board = null;
  public enum SocEnum {
    STM32MP157F("STM32MP157F"),
    STM32MP157D("STM32MP157D"),
    STM32MP151F("STM32MP151F"),
    STM32MP131F("STM32MP131F"),
    UNKNOWN("unknown");

    private String value;

    SocEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static SocEnum fromValue(String text) {
      for (SocEnum b : SocEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(example = "STM32MP157F", description = "")
  private SocEnum soc = null;
  
  @Schema(example = "YWWLMMMMRRFSSSSS", description = "")
  private String cbSn = null;
 /**
   * Get os
   * @return os
  **/
  @JsonProperty("os")
  public OSInfo getOs() {
    return os;
  }

  public void setOs(OSInfo os) {
    this.os = os;
  }

  public SystemInfoSysteminfo os(OSInfo os) {
    this.os = os;
    return this;
  }

 /**
   * Get poolInterfaceSw
   * @return poolInterfaceSw
  **/
  @JsonProperty("pool_interface_sw")
  public SWInfo getPoolInterfaceSw() {
    return poolInterfaceSw;
  }

  public void setPoolInterfaceSw(SWInfo poolInterfaceSw) {
    this.poolInterfaceSw = poolInterfaceSw;
  }

  public SystemInfoSysteminfo poolInterfaceSw(SWInfo poolInterfaceSw) {
    this.poolInterfaceSw = poolInterfaceSw;
    return this;
  }

 /**
   * Get miningDriverSw
   * @return miningDriverSw
  **/
  @JsonProperty("mining_driver_sw")
  public SWInfo getMiningDriverSw() {
    return miningDriverSw;
  }

  public void setMiningDriverSw(SWInfo miningDriverSw) {
    this.miningDriverSw = miningDriverSw;
  }

  public SystemInfoSysteminfo miningDriverSw(SWInfo miningDriverSw) {
    this.miningDriverSw = miningDriverSw;
    return this;
  }

 /**
   * Get webServer
   * @return webServer
  **/
  @JsonProperty("web_server")
  public SWInfo getWebServer() {
    return webServer;
  }

  public void setWebServer(SWInfo webServer) {
    this.webServer = webServer;
  }

  public SystemInfoSysteminfo webServer(SWInfo webServer) {
    this.webServer = webServer;
    return this;
  }

 /**
   * Get uptimeSeconds
   * @return uptimeSeconds
  **/
  @JsonProperty("uptime_seconds")
  public Long getUptimeSeconds() {
    return uptimeSeconds;
  }

  public void setUptimeSeconds(Long uptimeSeconds) {
    this.uptimeSeconds = uptimeSeconds;
  }

  public SystemInfoSysteminfo uptimeSeconds(Long uptimeSeconds) {
    this.uptimeSeconds = uptimeSeconds;
    return this;
  }

 /**
   * Get board
   * @return board
  **/
  @JsonProperty("board")
  public String getBoard() {
    if (board == null) {
      return null;
    }
    return board.getValue();
  }

  public void setBoard(BoardEnum board) {
    this.board = board;
  }

  public SystemInfoSysteminfo board(BoardEnum board) {
    this.board = board;
    return this;
  }

 /**
   * Get soc
   * @return soc
  **/
  @JsonProperty("soc")
  public String getSoc() {
    if (soc == null) {
      return null;
    }
    return soc.getValue();
  }

  public void setSoc(SocEnum soc) {
    this.soc = soc;
  }

  public SystemInfoSysteminfo soc(SocEnum soc) {
    this.soc = soc;
    return this;
  }

 /**
   * Get cbSn
   * @return cbSn
  **/
  @JsonProperty("cb_sn")
  public String getCbSn() {
    return cbSn;
  }

  public void setCbSn(String cbSn) {
    this.cbSn = cbSn;
  }

  public SystemInfoSysteminfo cbSn(String cbSn) {
    this.cbSn = cbSn;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SystemInfoSysteminfo {\n");
    
    sb.append("    os: ").append(toIndentedString(os)).append("\n");
    sb.append("    poolInterfaceSw: ").append(toIndentedString(poolInterfaceSw)).append("\n");
    sb.append("    miningDriverSw: ").append(toIndentedString(miningDriverSw)).append("\n");
    sb.append("    webServer: ").append(toIndentedString(webServer)).append("\n");
    sb.append("    uptimeSeconds: ").append(toIndentedString(uptimeSeconds)).append("\n");
    sb.append("    board: ").append(toIndentedString(board)).append("\n");
    sb.append("    soc: ").append(toIndentedString(soc)).append("\n");
    sb.append("    cbSn: ").append(toIndentedString(cbSn)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
