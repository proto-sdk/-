package io.swagger.model;


import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class Aggregates   {
  
  @Schema(description = "Minimum value in data.")
 /**
   * Minimum value in data.  
  **/
  private Integer min = null;
  
  @Schema(description = "Average value in data.")
 /**
   * Average value in data.  
  **/
  private Integer avg = null;
  
  @Schema(description = "Maximum value in data.")
 /**
   * Maximum value in data.  
  **/
  private Integer max = null;
 /**
   * Minimum value in data.
   * @return min
  **/
  @JsonProperty("min")
  public Integer getMin() {
    return min;
  }

  public void setMin(Integer min) {
    this.min = min;
  }

  public Aggregates min(Integer min) {
    this.min = min;
    return this;
  }

 /**
   * Average value in data.
   * @return avg
  **/
  @JsonProperty("avg")
  public Integer getAvg() {
    return avg;
  }

  public void setAvg(Integer avg) {
    this.avg = avg;
  }

  public Aggregates avg(Integer avg) {
    this.avg = avg;
    return this;
  }

 /**
   * Maximum value in data.
   * @return max
  **/
  @JsonProperty("max")
  public Integer getMax() {
    return max;
  }

  public void setMax(Integer max) {
    this.max = max;
  }

  public Aggregates max(Integer max) {
    this.max = max;
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Aggregates {\n");
    
    sb.append("    min: ").append(toIndentedString(min)).append("\n");
    sb.append("    avg: ").append(toIndentedString(avg)).append("\n");
    sb.append("    max: ").append(toIndentedString(max)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
