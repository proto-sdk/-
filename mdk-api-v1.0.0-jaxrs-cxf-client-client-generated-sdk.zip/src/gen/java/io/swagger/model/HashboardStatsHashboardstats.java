package io.swagger.model;

import io.swagger.model.AsicStats;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.annotation.JsonCreator;

public class HashboardStatsHashboardstats   {
  
  @Schema(description = "Manufacturing serial number of the hashboard, used for subsequent API calls.")
 /**
   * Manufacturing serial number of the hashboard, used for subsequent API calls.  
  **/
  private String hbSn = null;
  
  @Schema(example = "YWWLMMMMRRFSSSSS", description = "Internal ID of the hashboard, assigned to each hashboard starting from 0.")
 /**
   * Internal ID of the hashboard, assigned to each hashboard starting from 0.  
  **/
  private String hbId = null;
  public enum StatusEnum {
    RUNNING("Running"),
    STOPPED("Stopped"),
    ERROR("Error"),
    OVERHEATED("Overheated"),
    UNKNOWN("Unknown");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }
    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }
    @JsonCreator
    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }  
  @Schema(example = "Running", description = "The current state or condition of the hashboard.")
 /**
   * The current state or condition of the hashboard.  
  **/
  private StatusEnum status = null;
  
  @Schema(example = "1000", description = "The power consumption of the hashboard in watts.")
 /**
   * The power consumption of the hashboard in watts.  
  **/
  private Integer powerUsageWatts = null;
  
  @Schema(example = "16200", description = "The present voltage being supplied to the hashboard in millivolts.")
 /**
   * The present voltage being supplied to the hashboard in millivolts.  
  **/
  private Integer voltageMv = null;
  
  @Schema(example = "75", description = "Current average temperature of the hashboard in celsius.")
 /**
   * Current average temperature of the hashboard in celsius.  
  **/
  private BigDecimal avgAsicTempC = null;
  
  @Schema(example = "300", description = "The current hash rate of the hashboard, measured in GH/s. It will be sum of all ASIC hashrate_ghs values.")
 /**
   * The current hash rate of the hashboard, measured in GH/s. It will be sum of all ASIC hashrate_ghs values.  
  **/
  private BigDecimal hashrateGhs = null;
  
  @Schema(example = "300", description = "The expected hashrate is determined by the clock frequency of the all ASIC on the hash board, measured in GH/s.")
 /**
   * The expected hashrate is determined by the clock frequency of the all ASIC on the hash board, measured in GH/s.  
  **/
  private BigDecimal idealHashrateGhs = null;
  
  @Schema(example = "40", description = "The efficiency of the hashboard in joules per terahash.")
 /**
   * The efficiency of the hashboard in joules per terahash.  
  **/
  private BigDecimal efficiencyJth = null;
  
  @Schema(description = "")
  private List<AsicStats> asics = null;
 /**
   * Manufacturing serial number of the hashboard, used for subsequent API calls.
   * @return hbSn
  **/
  @JsonProperty("hb_sn")
  public String getHbSn() {
    return hbSn;
  }

  public void setHbSn(String hbSn) {
    this.hbSn = hbSn;
  }

  public HashboardStatsHashboardstats hbSn(String hbSn) {
    this.hbSn = hbSn;
    return this;
  }

 /**
   * Internal ID of the hashboard, assigned to each hashboard starting from 0.
   * @return hbId
  **/
  @JsonProperty("hb_id")
  public String getHbId() {
    return hbId;
  }

  public void setHbId(String hbId) {
    this.hbId = hbId;
  }

  public HashboardStatsHashboardstats hbId(String hbId) {
    this.hbId = hbId;
    return this;
  }

 /**
   * The current state or condition of the hashboard.
   * @return status
  **/
  @JsonProperty("status")
  public String getStatus() {
    if (status == null) {
      return null;
    }
    return status.getValue();
  }

  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  public HashboardStatsHashboardstats status(StatusEnum status) {
    this.status = status;
    return this;
  }

 /**
   * The power consumption of the hashboard in watts.
   * @return powerUsageWatts
  **/
  @JsonProperty("power_usage_watts")
  public Integer getPowerUsageWatts() {
    return powerUsageWatts;
  }

  public void setPowerUsageWatts(Integer powerUsageWatts) {
    this.powerUsageWatts = powerUsageWatts;
  }

  public HashboardStatsHashboardstats powerUsageWatts(Integer powerUsageWatts) {
    this.powerUsageWatts = powerUsageWatts;
    return this;
  }

 /**
   * The present voltage being supplied to the hashboard in millivolts.
   * @return voltageMv
  **/
  @JsonProperty("voltage_mv")
  public Integer getVoltageMv() {
    return voltageMv;
  }

  public void setVoltageMv(Integer voltageMv) {
    this.voltageMv = voltageMv;
  }

  public HashboardStatsHashboardstats voltageMv(Integer voltageMv) {
    this.voltageMv = voltageMv;
    return this;
  }

 /**
   * Current average temperature of the hashboard in celsius.
   * @return avgAsicTempC
  **/
  @JsonProperty("avg_asic_temp_c")
  public BigDecimal getAvgAsicTempC() {
    return avgAsicTempC;
  }

  public void setAvgAsicTempC(BigDecimal avgAsicTempC) {
    this.avgAsicTempC = avgAsicTempC;
  }

  public HashboardStatsHashboardstats avgAsicTempC(BigDecimal avgAsicTempC) {
    this.avgAsicTempC = avgAsicTempC;
    return this;
  }

 /**
   * The current hash rate of the hashboard, measured in GH/s. It will be sum of all ASIC hashrate_ghs values.
   * @return hashrateGhs
  **/
  @JsonProperty("hashrate_ghs")
  public BigDecimal getHashrateGhs() {
    return hashrateGhs;
  }

  public void setHashrateGhs(BigDecimal hashrateGhs) {
    this.hashrateGhs = hashrateGhs;
  }

  public HashboardStatsHashboardstats hashrateGhs(BigDecimal hashrateGhs) {
    this.hashrateGhs = hashrateGhs;
    return this;
  }

 /**
   * The expected hashrate is determined by the clock frequency of the all ASIC on the hash board, measured in GH/s.
   * @return idealHashrateGhs
  **/
  @JsonProperty("ideal_hashrate_ghs")
  public BigDecimal getIdealHashrateGhs() {
    return idealHashrateGhs;
  }

  public void setIdealHashrateGhs(BigDecimal idealHashrateGhs) {
    this.idealHashrateGhs = idealHashrateGhs;
  }

  public HashboardStatsHashboardstats idealHashrateGhs(BigDecimal idealHashrateGhs) {
    this.idealHashrateGhs = idealHashrateGhs;
    return this;
  }

 /**
   * The efficiency of the hashboard in joules per terahash.
   * @return efficiencyJth
  **/
  @JsonProperty("efficiency_jth")
  public BigDecimal getEfficiencyJth() {
    return efficiencyJth;
  }

  public void setEfficiencyJth(BigDecimal efficiencyJth) {
    this.efficiencyJth = efficiencyJth;
  }

  public HashboardStatsHashboardstats efficiencyJth(BigDecimal efficiencyJth) {
    this.efficiencyJth = efficiencyJth;
    return this;
  }

 /**
   * Get asics
   * @return asics
  **/
  @JsonProperty("asics")
  public List<AsicStats> getAsics() {
    return asics;
  }

  public void setAsics(List<AsicStats> asics) {
    this.asics = asics;
  }

  public HashboardStatsHashboardstats asics(List<AsicStats> asics) {
    this.asics = asics;
    return this;
  }

  public HashboardStatsHashboardstats addAsicsItem(AsicStats asicsItem) {
    this.asics.add(asicsItem);
    return this;
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HashboardStatsHashboardstats {\n");
    
    sb.append("    hbSn: ").append(toIndentedString(hbSn)).append("\n");
    sb.append("    hbId: ").append(toIndentedString(hbId)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    powerUsageWatts: ").append(toIndentedString(powerUsageWatts)).append("\n");
    sb.append("    voltageMv: ").append(toIndentedString(voltageMv)).append("\n");
    sb.append("    avgAsicTempC: ").append(toIndentedString(avgAsicTempC)).append("\n");
    sb.append("    hashrateGhs: ").append(toIndentedString(hashrateGhs)).append("\n");
    sb.append("    idealHashrateGhs: ").append(toIndentedString(idealHashrateGhs)).append("\n");
    sb.append("    efficiencyJth: ").append(toIndentedString(efficiencyJth)).append("\n");
    sb.append("    asics: ").append(toIndentedString(asics)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private static String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
