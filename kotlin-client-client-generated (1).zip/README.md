# io.swagger.client - Kotlin client library for Mining Development Kit API

## Requires

* Kotlin 1.4.30
* Gradle 5.3

## Build

First, create the gradle wrapper script:

```
gradle wrapper
```

Then, run:

```
./gradlew check assemble
```

This runs all tests and packages the library.

## Features/Implementation Notes

* Supports JSON inputs/outputs, File inputs, and Form inputs.
* Supports collection formats for query parameters: csv, tsv, ssv, pipes.
* Some Kotlin and Java types are fully qualified to avoid conflicts with types defined in Swagger definitions.
* Implementation of ApiClient is intended to reduce method counts, specifically to benefit Android targets.

<a name="documentation-for-api-endpoints"></a>
## Documentation for API Endpoints

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*CoolingApi* | [**getCooling**](docs/CoolingApi.md#getcooling) | **GET** /api/v1/cooling | 
*CoolingApi* | [**setCoolingMode**](docs/CoolingApi.md#setcoolingmode) | **PUT** /api/v1/cooling | 
*EfficiencyApi* | [**getHashboardEfficiency**](docs/EfficiencyApi.md#gethashboardefficiency) | **GET** /api/v1/efficiency/{hb_sn} | 
*EfficiencyApi* | [**getMinerEfficiency**](docs/EfficiencyApi.md#getminerefficiency) | **GET** /api/v1/efficiency | 
*ErrorsApi* | [**getErrors**](docs/ErrorsApi.md#geterrors) | **GET** /api/v1/errors | 
*HashboardsApi* | [**getAllHashboards**](docs/HashboardsApi.md#getallhashboards) | **GET** /api/v1/hashboards | 
*HashboardsApi* | [**getAsicStatus**](docs/HashboardsApi.md#getasicstatus) | **GET** /api/v1/hashboards/{hb_sn}/{asic_id} | 
*HashboardsApi* | [**getHashboardLogs**](docs/HashboardsApi.md#gethashboardlogs) | **GET** /api/v1/hashboards/{hb_sn}/logs | 
*HashboardsApi* | [**getHashboardStatus**](docs/HashboardsApi.md#gethashboardstatus) | **GET** /api/v1/hashboards/{hb_sn} | 
*HashrateApi* | [**getAsicHashrate**](docs/HashrateApi.md#getasichashrate) | **GET** /api/v1/hashrate/{hb_sn}/{asic_id} | 
*HashrateApi* | [**getHashboardHashrate**](docs/HashrateApi.md#gethashboardhashrate) | **GET** /api/v1/hashrate/{hb_sn} | 
*HashrateApi* | [**getMinerHashrate**](docs/HashrateApi.md#getminerhashrate) | **GET** /api/v1/hashrate | 
*MiningApi* | [**editMiningTarget**](docs/MiningApi.md#editminingtarget) | **PUT** /api/v1/mining/target | 
*MiningApi* | [**getMiningStatus**](docs/MiningApi.md#getminingstatus) | **GET** /api/v1/mining | 
*MiningApi* | [**getMiningTarget**](docs/MiningApi.md#getminingtarget) | **GET** /api/v1/mining/target | 
*MiningApi* | [**startMining**](docs/MiningApi.md#startmining) | **POST** /api/v1/mining/start | 
*MiningApi* | [**stopMining**](docs/MiningApi.md#stopmining) | **POST** /api/v1/mining/stop | 
*NetworkApi* | [**getNetwork**](docs/NetworkApi.md#getnetwork) | **GET** /api/v1/network | 
*NetworkApi* | [**setNetworkConfig**](docs/NetworkApi.md#setnetworkconfig) | **PUT** /api/v1/network | 
*PoolsApi* | [**createPools**](docs/PoolsApi.md#createpools) | **POST** /api/v1/pools | 
*PoolsApi* | [**deletePool**](docs/PoolsApi.md#deletepool) | **DELETE** /api/v1/pools/{id} | 
*PoolsApi* | [**editPool**](docs/PoolsApi.md#editpool) | **PUT** /api/v1/pools/{id} | 
*PoolsApi* | [**getPool**](docs/PoolsApi.md#getpool) | **GET** /api/v1/pools/{id} | 
*PoolsApi* | [**listPools**](docs/PoolsApi.md#listpools) | **GET** /api/v1/pools | 
*PoolsApi* | [**testPoolConnection**](docs/PoolsApi.md#testpoolconnection) | **POST** /api/v1/pools/test-connection | 
*PowerApi* | [**getHashboardPower**](docs/PowerApi.md#gethashboardpower) | **GET** /api/v1/power/{hb_sn} | 
*PowerApi* | [**getMinerPower**](docs/PowerApi.md#getminerpower) | **GET** /api/v1/power | 
*SystemApi* | [**getSystemInfo**](docs/SystemApi.md#getsysteminfo) | **GET** /api/v1/system | 
*SystemApi* | [**getSystemLogs**](docs/SystemApi.md#getsystemlogs) | **GET** /api/v1/system/logs | 
*SystemApi* | [**locateSystem**](docs/SystemApi.md#locatesystem) | **POST** /api/v1/system/locate | 
*SystemApi* | [**rebootSystem**](docs/SystemApi.md#rebootsystem) | **POST** /api/v1/system/reboot | 
*SystemInformationApi* | [**getSystemStatus**](docs/SystemInformationApi.md#getsystemstatus) | **GET** /api/v1/system/status | 
*TemperatureApi* | [**getAsicTemperature**](docs/TemperatureApi.md#getasictemperature) | **GET** /api/v1/temperature/{hb_sn}/{asic_id} | 
*TemperatureApi* | [**getHashboardTemperature**](docs/TemperatureApi.md#gethashboardtemperature) | **GET** /api/v1/temperature/{hb_sn} | 
*TemperatureApi* | [**getMinerTemperature**](docs/TemperatureApi.md#getminertemperature) | **GET** /api/v1/temperature | 

<a name="documentation-for-models"></a>
## Documentation for Models

 - [io.swagger.client.models.Aggregates](docs/Aggregates.md)
 - [io.swagger.client.models.AsicStats](docs/AsicStats.md)
 - [io.swagger.client.models.AsicStatsResponse](docs/AsicStatsResponse.md)
 - [io.swagger.client.models.CoolingConfig](docs/CoolingConfig.md)
 - [io.swagger.client.models.CoolingStatus](docs/CoolingStatus.md)
 - [io.swagger.client.models.CoolingStatusCoolingstatus](docs/CoolingStatusCoolingstatus.md)
 - [io.swagger.client.models.EfficiencyResponse](docs/EfficiencyResponse.md)
 - [io.swagger.client.models.EfficiencyResponseEfficiencydata](docs/EfficiencyResponseEfficiencydata.md)
 - [io.swagger.client.models.Error](docs/Error.md)
 - [io.swagger.client.models.ErrorListResponse](docs/ErrorListResponse.md)
 - [io.swagger.client.models.ErrorResponse](docs/ErrorResponse.md)
 - [io.swagger.client.models.FWInfo](docs/FWInfo.md)
 - [io.swagger.client.models.FanInfo](docs/FanInfo.md)
 - [io.swagger.client.models.HashboardStats](docs/HashboardStats.md)
 - [io.swagger.client.models.HashboardStatsHashboardstats](docs/HashboardStatsHashboardstats.md)
 - [io.swagger.client.models.HashboardsInfo](docs/HashboardsInfo.md)
 - [io.swagger.client.models.HashboardsInfoHashboardsinfo](docs/HashboardsInfoHashboardsinfo.md)
 - [io.swagger.client.models.HashrateResponse](docs/HashrateResponse.md)
 - [io.swagger.client.models.HashrateResponseHashratedata](docs/HashrateResponseHashratedata.md)
 - [io.swagger.client.models.LogsResponse](docs/LogsResponse.md)
 - [io.swagger.client.models.LogsResponseLogs](docs/LogsResponseLogs.md)
 - [io.swagger.client.models.MessageResponse](docs/MessageResponse.md)
 - [io.swagger.client.models.MiningStatus](docs/MiningStatus.md)
 - [io.swagger.client.models.MiningStatusMiningstatus](docs/MiningStatusMiningstatus.md)
 - [io.swagger.client.models.MiningTarget](docs/MiningTarget.md)
 - [io.swagger.client.models.NetworkConfig](docs/NetworkConfig.md)
 - [io.swagger.client.models.NetworkConfigNetworkconfig](docs/NetworkConfigNetworkconfig.md)
 - [io.swagger.client.models.NetworkInfo](docs/NetworkInfo.md)
 - [io.swagger.client.models.NetworkInfoNetworkinfo](docs/NetworkInfoNetworkinfo.md)
 - [io.swagger.client.models.NotificationError](docs/NotificationError.md)
 - [io.swagger.client.models.OSInfo](docs/OSInfo.md)
 - [io.swagger.client.models.OSStatus](docs/OSStatus.md)
 - [io.swagger.client.models.Pool](docs/Pool.md)
 - [io.swagger.client.models.PoolConfig](docs/PoolConfig.md)
 - [io.swagger.client.models.PoolConfigInner](docs/PoolConfigInner.md)
 - [io.swagger.client.models.PoolConfigResponse](docs/PoolConfigResponse.md)
 - [io.swagger.client.models.PoolConfigResponseInner](docs/PoolConfigResponseInner.md)
 - [io.swagger.client.models.PoolResponse](docs/PoolResponse.md)
 - [io.swagger.client.models.PoolsList](docs/PoolsList.md)
 - [io.swagger.client.models.PowerResponse](docs/PowerResponse.md)
 - [io.swagger.client.models.PowerResponsePowerdata](docs/PowerResponsePowerdata.md)
 - [io.swagger.client.models.SWInfo](docs/SWInfo.md)
 - [io.swagger.client.models.SystemInfo](docs/SystemInfo.md)
 - [io.swagger.client.models.SystemInfoSysteminfo](docs/SystemInfoSysteminfo.md)
 - [io.swagger.client.models.SystemStatuses](docs/SystemStatuses.md)
 - [io.swagger.client.models.TemperatureResponse](docs/TemperatureResponse.md)
 - [io.swagger.client.models.TemperatureResponseTemperaturedata](docs/TemperatureResponseTemperaturedata.md)
 - [io.swagger.client.models.TestConnection](docs/TestConnection.md)
 - [io.swagger.client.models.TimeSeriesData](docs/TimeSeriesData.md)

<a name="documentation-for-authorization"></a>
## Documentation for Authorization

All endpoints do not require authorization.
