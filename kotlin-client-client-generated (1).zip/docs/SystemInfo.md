# SystemInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**systemInfo** | [**SystemInfoSysteminfo**](SystemInfoSysteminfo.md) |  |  [optional]
