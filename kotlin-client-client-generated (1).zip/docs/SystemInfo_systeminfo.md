# SystemInfoSysteminfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**os** | [**OSInfo**](OSInfo.md) |  |  [optional]
**poolInterfaceSw** | [**SWInfo**](SWInfo.md) |  |  [optional]
**miningDriverSw** | [**SWInfo**](SWInfo.md) |  |  [optional]
**webServer** | [**SWInfo**](SWInfo.md) |  |  [optional]
**uptimeSeconds** | [**kotlin.Long**](.md) |  |  [optional]
**board** | [**inline**](#Board) |  |  [optional]
**soc** | [**inline**](#Soc) |  |  [optional]
**cbSn** | [**kotlin.String**](.md) |  |  [optional]

<a name="Board"></a>
## Enum: board
Name | Value
---- | -----
board | stm32mp157d-dk1, stm32mp157f-dk2, c1-p0, c1-evt, unknown

<a name="Soc"></a>
## Enum: soc
Name | Value
---- | -----
soc | STM32MP157F, STM32MP157D, STM32MP151F, STM32MP131F, unknown
