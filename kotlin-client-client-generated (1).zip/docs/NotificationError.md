# NotificationError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source** | [**inline**](#Source) |  |  [optional]
**componentIndex** | [**kotlin.Int**](.md) |  |  [optional]
**hashboardIndex** | [**kotlin.Int**](.md) |  |  [optional]
**asicIndex** | [**kotlin.Int**](.md) |  |  [optional]
**errorCode** | [**kotlin.String**](.md) |  |  [optional]
**insertedAt** | [**kotlin.Int**](.md) |  |  [optional]
**expiredAt** | [**kotlin.Int**](.md) |  |  [optional]
**errorLevel** | [**inline**](#ErrorLevel) |  |  [optional]
**message** | [**kotlin.String**](.md) |  |  [optional]
**details** | [**kotlin.String**](.md) |  |  [optional]

<a name="Source"></a>
## Enum: source
Name | Value
---- | -----
source | Miner, Hashboard, ASIC

<a name="ErrorLevel"></a>
## Enum: error_level
Name | Value
---- | -----
errorLevel | Error, Warning
