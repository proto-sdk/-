# MiningApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**editMiningTarget**](MiningApi.md#editMiningTarget) | **PUT** /api/v1/mining/target | 
[**getMiningStatus**](MiningApi.md#getMiningStatus) | **GET** /api/v1/mining | 
[**getMiningTarget**](MiningApi.md#getMiningTarget) | **GET** /api/v1/mining/target | 
[**startMining**](MiningApi.md#startMining) | **POST** /api/v1/mining/start | 
[**stopMining**](MiningApi.md#stopMining) | **POST** /api/v1/mining/stop | 

<a name="editMiningTarget"></a>
# **editMiningTarget**
> MiningTarget editMiningTarget(body)



The mining target endpoint can be used to set a target power consumption for the miner. Once set, the mining device will operate to consume as close to that amount of power as possible. In the event that the device is unable to maintain its temperature within the allowed range, it may scale down and use less power.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = MiningApi()
val body : MiningTarget =  // MiningTarget | 
try {
    val result : MiningTarget = apiInstance.editMiningTarget(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling MiningApi#editMiningTarget")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling MiningApi#editMiningTarget")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**MiningTarget**](MiningTarget.md)|  |

### Return type

[**MiningTarget**](MiningTarget.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getMiningStatus"></a>
# **getMiningStatus**
> MiningStatus getMiningStatus()



The mining endpoint provides summary information about the mining operations of the device. This includes device level hashrate statistics, overall miner status, and current power usage and target information.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = MiningApi()
try {
    val result : MiningStatus = apiInstance.getMiningStatus()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling MiningApi#getMiningStatus")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling MiningApi#getMiningStatus")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MiningStatus**](MiningStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMiningTarget"></a>
# **getMiningTarget**
> MiningTarget getMiningTarget()



The mining target endpoint returns the current power target in watts that the miner is controlling for.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = MiningApi()
try {
    val result : MiningTarget = apiInstance.getMiningTarget()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling MiningApi#getMiningTarget")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling MiningApi#getMiningTarget")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MiningTarget**](MiningTarget.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="startMining"></a>
# **startMining**
> MessageResponse startMining()



The start mining endpoint can be used to make the device start mining, into account the current power target of the system.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = MiningApi()
try {
    val result : MessageResponse = apiInstance.startMining()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling MiningApi#startMining")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling MiningApi#startMining")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="stopMining"></a>
# **stopMining**
> MessageResponse stopMining()



The stop mining endpoint can be used to stop the device from mining, going into a minimal power mode with only the control board running.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = MiningApi()
try {
    val result : MessageResponse = apiInstance.stopMining()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling MiningApi#stopMining")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling MiningApi#stopMining")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

