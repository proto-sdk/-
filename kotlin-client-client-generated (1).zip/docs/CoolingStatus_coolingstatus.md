# CoolingStatusCoolingstatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fanMode** | [**inline**](#FanMode) | Parameter to show the current fan mode. |  [optional]
**fans** | [**kotlin.Array&lt;FanInfo&gt;**](FanInfo.md) | This will show speed of all fans in the system. |  [optional]

<a name="FanMode"></a>
## Enum: fan_mode
Name | Value
---- | -----
fanMode | Off, Auto, Max
