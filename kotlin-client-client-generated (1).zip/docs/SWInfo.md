# SWInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**kotlin.String**](.md) |  |  [optional]
**version** | [**kotlin.String**](.md) |  |  [optional]
