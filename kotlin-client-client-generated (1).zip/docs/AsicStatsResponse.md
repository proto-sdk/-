# AsicStatsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**asicStats** | [**AsicStats**](AsicStats.md) |  |  [optional]
