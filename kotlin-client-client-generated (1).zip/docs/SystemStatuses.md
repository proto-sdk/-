# SystemStatuses

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**onboarded** | [**kotlin.Boolean**](.md) |  |  [optional]
