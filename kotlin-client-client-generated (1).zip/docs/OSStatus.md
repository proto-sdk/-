# OSStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**memTotalKb** | [**kotlin.Int**](.md) |  |  [optional]
**memFreeKb** | [**kotlin.Int**](.md) |  |  [optional]
**cpuLoadPercent** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**rootfsTotalMb** | [**kotlin.Int**](.md) |  |  [optional]
**rootfsFreeMb** | [**kotlin.Int**](.md) |  |  [optional]
