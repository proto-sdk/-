# FanInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**kotlin.Int**](.md) | Each fan is assigned a unique identifier starting from 0. |  [optional]
**rpm** | [**kotlin.Int**](.md) | The fan&#x27;s current rotations per minute (RPM). |  [optional]
