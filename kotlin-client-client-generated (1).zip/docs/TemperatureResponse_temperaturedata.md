# TemperatureResponseTemperaturedata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**duration** | [**inline**](#Duration) | Duration of temperature data returned. |  [optional]
**&#x60;data&#x60;** | [**kotlin.Array&lt;TimeSeriesData&gt;**](TimeSeriesData.md) |  |  [optional]
**aggregates** | [**Aggregates**](Aggregates.md) |  |  [optional]

<a name="Duration"></a>
## Enum: duration
Name | Value
---- | -----
duration | 12h, 24h, 48h, 5d
