# CoolingApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getCooling**](CoolingApi.md#getCooling) | **GET** /api/v1/cooling | 
[**setCoolingMode**](CoolingApi.md#setCoolingMode) | **PUT** /api/v1/cooling | 

<a name="getCooling"></a>
# **getCooling**
> CoolingStatus getCooling()



The cooling endpoint provides information on the cooling status of the device, including mode and current fan RPM.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = CoolingApi()
try {
    val result : CoolingStatus = apiInstance.getCooling()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CoolingApi#getCooling")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CoolingApi#getCooling")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**CoolingStatus**](CoolingStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="setCoolingMode"></a>
# **setCoolingMode**
> CoolingConfig setCoolingMode(body)



The cooling configuration endpoint allows the user to control the fan mode.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = CoolingApi()
val body : CoolingConfig =  // CoolingConfig | 
try {
    val result : CoolingConfig = apiInstance.setCoolingMode(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling CoolingApi#setCoolingMode")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling CoolingApi#setCoolingMode")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CoolingConfig**](CoolingConfig.md)|  |

### Return type

[**CoolingConfig**](CoolingConfig.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

