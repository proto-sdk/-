# NetworkInfoNetworkinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mac** | [**kotlin.String**](.md) |  |  [optional]
**dhcp** | [**kotlin.Boolean**](.md) |  |  [optional]
**ip** | [**kotlin.String**](.md) |  |  [optional]
**netmask** | [**kotlin.String**](.md) |  |  [optional]
**gateway** | [**kotlin.String**](.md) |  |  [optional]
