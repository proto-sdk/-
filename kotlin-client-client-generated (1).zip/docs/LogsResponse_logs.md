# LogsResponseLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source** | [**kotlin.String**](.md) | Source of logs. |  [optional]
**lines** | [**kotlin.Int**](.md) | Number of lines returned. |  [optional]
**content** | [**kotlin.Array&lt;kotlin.String&gt;**](.md) |  |  [optional]
