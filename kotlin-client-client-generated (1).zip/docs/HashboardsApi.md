# HashboardsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAllHashboards**](HashboardsApi.md#getAllHashboards) | **GET** /api/v1/hashboards | 
[**getAsicStatus**](HashboardsApi.md#getAsicStatus) | **GET** /api/v1/hashboards/{hb_sn}/{asic_id} | 
[**getHashboardLogs**](HashboardsApi.md#getHashboardLogs) | **GET** /api/v1/hashboards/{hb_sn}/logs | 
[**getHashboardStatus**](HashboardsApi.md#getHashboardStatus) | **GET** /api/v1/hashboards/{hb_sn} | 

<a name="getAllHashboards"></a>
# **getAllHashboards**
> HashboardsInfo getAllHashboards()



The hashboards endpoint provides information about all of the hashboards connected to the system, including firmware version, MCU, ASIC count, API version, and hardware serial numbers.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = HashboardsApi()
try {
    val result : HashboardsInfo = apiInstance.getAllHashboards()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling HashboardsApi#getAllHashboards")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling HashboardsApi#getAllHashboards")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**HashboardsInfo**](HashboardsInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAsicStatus"></a>
# **getAsicStatus**
> AsicStatsResponse getAsicStatus(hbSn, asicId)



The hashboard status endpoint returns current operating statistics for a single ASIC on the specified hashboard in the system based on serial number and ASIC ID.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = HashboardsApi()
val hbSn : kotlin.String = hbSn_example // kotlin.String | The serial number of the hashboard to provide statistics for.
val asicId : kotlin.String = asicId_example // kotlin.String | The id of an ASIC to provide statistics for.
try {
    val result : AsicStatsResponse = apiInstance.getAsicStatus(hbSn, asicId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling HashboardsApi#getAsicStatus")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling HashboardsApi#getAsicStatus")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **kotlin.String**| The serial number of the hashboard to provide statistics for. |
 **asicId** | **kotlin.String**| The id of an ASIC to provide statistics for. |

### Return type

[**AsicStatsResponse**](AsicStatsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getHashboardLogs"></a>
# **getHashboardLogs**
> LogsResponse getHashboardLogs(hbSn, lines)



The hashboard logs endpoint provides the most recent log lines from the specified hashboard.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = HashboardsApi()
val hbSn : kotlin.String = hbSn_example // kotlin.String | The serial number of the hashboard to provide statistics for.
val lines : kotlin.Int = 56 // kotlin.Int | The number of most recent logs to return. Maximum of 500, defaults to 100.
try {
    val result : LogsResponse = apiInstance.getHashboardLogs(hbSn, lines)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling HashboardsApi#getHashboardLogs")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling HashboardsApi#getHashboardLogs")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **kotlin.String**| The serial number of the hashboard to provide statistics for. |
 **lines** | **kotlin.Int**| The number of most recent logs to return. Maximum of 500, defaults to 100. | [optional] [default to 100]

### Return type

[**LogsResponse**](LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getHashboardStatus"></a>
# **getHashboardStatus**
> HashboardStats getHashboardStatus(hbSn)



The hashboard status endpoint returns current operating statistics for a single hashboard in the system based on its serial number.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = HashboardsApi()
val hbSn : kotlin.String = hbSn_example // kotlin.String | The serial number of the hashboard to provide statistics for.
try {
    val result : HashboardStats = apiInstance.getHashboardStatus(hbSn)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling HashboardsApi#getHashboardStatus")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling HashboardsApi#getHashboardStatus")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **kotlin.String**| The serial number of the hashboard to provide statistics for. |

### Return type

[**HashboardStats**](HashboardStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

