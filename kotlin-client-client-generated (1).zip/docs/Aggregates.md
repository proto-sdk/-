# Aggregates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min** | [**kotlin.Int**](.md) | Minimum value in data. |  [optional]
**avg** | [**kotlin.Int**](.md) | Average value in data. |  [optional]
**max** | [**kotlin.Int**](.md) | Maximum value in data. |  [optional]
