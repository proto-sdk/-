# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | [**kotlin.String**](.md) | Error code. |  [optional]
**message** | [**kotlin.String**](.md) | Error message. |  [optional]
