# EfficiencyApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getHashboardEfficiency**](EfficiencyApi.md#getHashboardEfficiency) | **GET** /api/v1/efficiency/{hb_sn} | 
[**getMinerEfficiency**](EfficiencyApi.md#getMinerEfficiency) | **GET** /api/v1/efficiency | 

<a name="getHashboardEfficiency"></a>
# **getHashboardEfficiency**
> EfficiencyResponse getHashboardEfficiency(hbSn, duration)



The efficiency endpoint provides hashboard-level historical operation data.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = EfficiencyApi()
val hbSn : kotlin.String = hbSn_example // kotlin.String | The serial number of the hashboard to provide power information for.
val duration : kotlin.String = duration_example // kotlin.String | 
try {
    val result : EfficiencyResponse = apiInstance.getHashboardEfficiency(hbSn, duration)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling EfficiencyApi#getHashboardEfficiency")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling EfficiencyApi#getHashboardEfficiency")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **kotlin.String**| The serial number of the hashboard to provide power information for. |
 **duration** | **kotlin.String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**EfficiencyResponse**](EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMinerEfficiency"></a>
# **getMinerEfficiency**
> EfficiencyResponse getMinerEfficiency(duration)



The efficiency endpoint provides miner-level historical power operation data.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = EfficiencyApi()
val duration : kotlin.String = duration_example // kotlin.String | 
try {
    val result : EfficiencyResponse = apiInstance.getMinerEfficiency(duration)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling EfficiencyApi#getMinerEfficiency")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling EfficiencyApi#getMinerEfficiency")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **kotlin.String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**EfficiencyResponse**](EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

