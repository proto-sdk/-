# MiningStatusMiningstatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**inline**](#Status) | The indication will reveal whether the mining operation is currently active or has ceased |  [optional]
**miningUptimeS** | [**kotlin.Int**](.md) | The amount of time in seconds that has passed since the start of the mining operation. |  [optional]
**rebootUptimeS** | [**kotlin.Int**](.md) | The amount of time in seconds that has passed since the last reboot of the system. |  [optional]
**averageHashrateGhs** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | The average hash rate in giga-hashes per second, since the device started mining. average_hashrate_ghs &#x3D; Total hash count / (elapsed_time_s * 10^9) |  [optional]
**idealHashrateGhs** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | Expected hashrate determined by the current power level. |  [optional]
**powerUsageWatts** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | Amount of power being consumed by mining in watts. |  [optional]
**powerTargetWatts** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | Amount of power in watts for the system to target. |  [optional]
**averageEfficiencyJth** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | The average efficiency in joules per terahash, since the device started mining. |  [optional]
**averageAsicTempC** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | Average temperature of the ASICs in the mining device. |  [optional]
**averageHbTempC** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | Average temperature of the mining device. |  [optional]
**hwErrors** | [**kotlin.Int**](.md) | The number of hardware errors that have occurred during the mining operation. |  [optional]
**message** | [**kotlin.String**](.md) |  |  [optional]

<a name="Status"></a>
## Enum: status
Name | Value
---- | -----
status | Uninitialized, PoweringOn, Mining, DegradedMining, PoweringOff, Stopped, NoPools, Error
