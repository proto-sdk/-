# EfficiencyResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**efficiencyData** | [**EfficiencyResponseEfficiencydata**](EfficiencyResponseEfficiencydata.md) |  |  [optional]
