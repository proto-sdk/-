# NetworkApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getNetwork**](NetworkApi.md#getNetwork) | **GET** /api/v1/network | 
[**setNetworkConfig**](NetworkApi.md#setNetworkConfig) | **PUT** /api/v1/network | 

<a name="getNetwork"></a>
# **getNetwork**
> NetworkInfo getNetwork()



The network GET endpoint provides information related to the network configuration of the miner including IP address, gateways, and MAC address.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = NetworkApi()
try {
    val result : NetworkInfo = apiInstance.getNetwork()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling NetworkApi#getNetwork")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling NetworkApi#getNetwork")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="setNetworkConfig"></a>
# **setNetworkConfig**
> NetworkInfo setNetworkConfig(body)



The network PUT endpoint allows the user to change the configuration of the miner between DHCP and a static IP.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = NetworkApi()
val body : NetworkConfig =  // NetworkConfig | 
try {
    val result : NetworkInfo = apiInstance.setNetworkConfig(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling NetworkApi#setNetworkConfig")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling NetworkApi#setNetworkConfig")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NetworkConfig**](NetworkConfig.md)|  |

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

