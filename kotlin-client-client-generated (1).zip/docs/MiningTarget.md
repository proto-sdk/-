# MiningTarget

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**powerTargetWatts** | [**kotlin.Int**](.md) |  |  [optional]
