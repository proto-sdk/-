# PoolsList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pools** | [**kotlin.Array&lt;Pool&gt;**](Pool.md) |  |  [optional]
