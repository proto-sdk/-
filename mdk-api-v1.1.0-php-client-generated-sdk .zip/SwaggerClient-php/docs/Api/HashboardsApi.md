# Swagger\Client\HashboardsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAllHashboards**](HashboardsApi.md#getallhashboards) | **GET** /api/v1/hashboards | 
[**getAsicStatus**](HashboardsApi.md#getasicstatus) | **GET** /api/v1/hashboards/{hb_sn}/{asic_id} | 
[**getHashboardLogs**](HashboardsApi.md#gethashboardlogs) | **GET** /api/v1/hashboards/{hb_sn}/logs | 
[**getHashboardStatus**](HashboardsApi.md#gethashboardstatus) | **GET** /api/v1/hashboards/{hb_sn} | 

# **getAllHashboards**
> \Swagger\Client\Model\HashboardsInfo getAllHashboards()



The hashboards endpoint provides information about all of the hashboards connected to the system, including firmware version, MCU, ASIC count, API version, and hardware serial numbers.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\HashboardsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getAllHashboards();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling HashboardsApi->getAllHashboards: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\HashboardsInfo**](../Model/HashboardsInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getAsicStatus**
> \Swagger\Client\Model\AsicStatsResponse getAsicStatus($hb_sn, $asic_id)



The hashboard status endpoint returns current operating statistics for a single ASIC on the specified hashboard in the system based on serial number and ASIC ID.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\HashboardsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$hb_sn = "hb_sn_example"; // string | The serial number of the hashboard to provide statistics for.
$asic_id = "asic_id_example"; // string | The id of an ASIC to provide statistics for.

try {
    $result = $apiInstance->getAsicStatus($hb_sn, $asic_id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling HashboardsApi->getAsicStatus: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **string**| The serial number of the hashboard to provide statistics for. |
 **asic_id** | **string**| The id of an ASIC to provide statistics for. |

### Return type

[**\Swagger\Client\Model\AsicStatsResponse**](../Model/AsicStatsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getHashboardLogs**
> \Swagger\Client\Model\LogsResponse getHashboardLogs($hb_sn, $lines)



The hashboard logs endpoint provides the most recent log lines from the specified hashboard.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\HashboardsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$hb_sn = "hb_sn_example"; // string | The serial number of the hashboard to provide statistics for.
$lines = 100; // int | The number of most recent logs to return. Maximum of 500, defaults to 100.

try {
    $result = $apiInstance->getHashboardLogs($hb_sn, $lines);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling HashboardsApi->getHashboardLogs: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **string**| The serial number of the hashboard to provide statistics for. |
 **lines** | **int**| The number of most recent logs to return. Maximum of 500, defaults to 100. | [optional] [default to 100]

### Return type

[**\Swagger\Client\Model\LogsResponse**](../Model/LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getHashboardStatus**
> \Swagger\Client\Model\HashboardStats getHashboardStatus($hb_sn)



The hashboard status endpoint returns current operating statistics for a single hashboard in the system based on its serial number.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\HashboardsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$hb_sn = "hb_sn_example"; // string | The serial number of the hashboard to provide statistics for.

try {
    $result = $apiInstance->getHashboardStatus($hb_sn);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling HashboardsApi->getHashboardStatus: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **string**| The serial number of the hashboard to provide statistics for. |

### Return type

[**\Swagger\Client\Model\HashboardStats**](../Model/HashboardStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

