# Swagger\Client\AuthenticationApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiV1AuthLogoutPost**](AuthenticationApi.md#apiv1authlogoutpost) | **POST** /api/v1/auth/logout | User logout
[**apiV1AuthRefreshPost**](AuthenticationApi.md#apiv1authrefreshpost) | **POST** /api/v1/auth/refresh | Refresh JWT access token
[**login**](AuthenticationApi.md#login) | **POST** /api/v1/auth/login | 
[**setPassword**](AuthenticationApi.md#setpassword) | **PUT** /api/v1/auth/password | 

# **apiV1AuthLogoutPost**
> \Swagger\Client\Model\MessageResponse apiV1AuthLogoutPost($body)

User logout

Validates and blacklists JWT tokens, effectively logging out the user.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: BearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\AuthenticationApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\AuthTokens(); // \Swagger\Client\Model\AuthTokens | 

try {
    $result = $apiInstance->apiV1AuthLogoutPost($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AuthenticationApi->apiV1AuthLogoutPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\AuthTokens**](../Model/AuthTokens.md)|  |

### Return type

[**\Swagger\Client\Model\MessageResponse**](../Model/MessageResponse.md)

### Authorization

[BearerAuth](../../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **apiV1AuthRefreshPost**
> \Swagger\Client\Model\RefreshResponse apiV1AuthRefreshPost($body)

Refresh JWT access token

Validates the provided refresh token and returns a new JWT access token.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\AuthenticationApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\RefreshRequest(); // \Swagger\Client\Model\RefreshRequest | 

try {
    $result = $apiInstance->apiV1AuthRefreshPost($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AuthenticationApi->apiV1AuthRefreshPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\RefreshRequest**](../Model/RefreshRequest.md)|  |

### Return type

[**\Swagger\Client\Model\RefreshResponse**](../Model/RefreshResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **login**
> \Swagger\Client\Model\AuthTokens login($body)



Authenticates a user using a password and returns a JWT access and refresh token pair.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\AuthenticationApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\PasswordRequest(); // \Swagger\Client\Model\PasswordRequest | 

try {
    $result = $apiInstance->login($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AuthenticationApi->login: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\PasswordRequest**](../Model/PasswordRequest.md)|  |

### Return type

[**\Swagger\Client\Model\AuthTokens**](../Model/AuthTokens.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **setPassword**
> \Swagger\Client\Model\MessageResponse setPassword($body)



The password endpoint allows users to set a password during onboarding

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\AuthenticationApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\PasswordRequest(); // \Swagger\Client\Model\PasswordRequest | 

try {
    $result = $apiInstance->setPassword($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AuthenticationApi->setPassword: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\PasswordRequest**](../Model/PasswordRequest.md)|  |

### Return type

[**\Swagger\Client\Model\MessageResponse**](../Model/MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

