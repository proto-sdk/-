# Swagger\Client\NetworkApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getNetwork**](NetworkApi.md#getnetwork) | **GET** /api/v1/network | 
[**setNetworkConfig**](NetworkApi.md#setnetworkconfig) | **PUT** /api/v1/network | 

# **getNetwork**
> \Swagger\Client\Model\NetworkInfo getNetwork()



The network GET endpoint provides information related to the network configuration of the miner including IP address, gateways, and MAC address.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\NetworkApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getNetwork();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling NetworkApi->getNetwork: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\NetworkInfo**](../Model/NetworkInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **setNetworkConfig**
> \Swagger\Client\Model\NetworkInfo setNetworkConfig($body)



The network PUT endpoint allows the user to change the configuration of the miner between DHCP and a static IP.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');
    // Configure HTTP bearer authorization: BearerAuth
    $config = Swagger\Client\Configuration::getDefaultConfiguration()
    ->setAccessToken('YOUR_ACCESS_TOKEN');


$apiInstance = new Swagger\Client\Api\NetworkApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$body = new \Swagger\Client\Model\NetworkConfig(); // \Swagger\Client\Model\NetworkConfig | 

try {
    $result = $apiInstance->setNetworkConfig($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling NetworkApi->setNetworkConfig: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\NetworkConfig**](../Model/NetworkConfig.md)|  |

### Return type

[**\Swagger\Client\Model\NetworkInfo**](../Model/NetworkInfo.md)

### Authorization

[BearerAuth](../../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

