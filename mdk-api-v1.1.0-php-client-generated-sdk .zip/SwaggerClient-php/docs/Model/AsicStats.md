# AsicStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Unique identifier assigned to each ASIC located on a hashboard, starting from 0. | [optional] 
**row** | **int** | Physical row location of the ASIC on the hashboard. | [optional] 
**column** | **int** | Physical column location of the ASIC on the hashboard. | [optional] 
**freq_mhz** | **float** | The frequency of the ASIC measured in megahertz. | [optional] 
**temp_c** | **float** | Current temperature of the ASIC in celsius | [optional] 
**hashrate_ghs** | **float** | The current hash rate of the ASIC, measured in GH/s. | [optional] 
**ideal_hashrate_ghs** | **float** | The expected hashrate determined by the clock frequency of the ASIC, measured in GH/s. | [optional] 
**error_rate** | **float** | The number of times that the ASIC produced an incorrect hash or an error during a specific period of time.  Error Rate (%) &#x3D; (Number of incorrect hash / Total number of expected Hash) x 100% | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

