# EfficiencyResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**efficiency_data** | [**\Swagger\Client\Model\EfficiencyResponseEfficiencydata**](EfficiencyResponseEfficiencydata.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

