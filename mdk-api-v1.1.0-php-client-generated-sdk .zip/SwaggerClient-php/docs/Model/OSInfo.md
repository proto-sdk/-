# OSInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | [optional] 
**version** | **string** |  | [optional] 
**git_hash** | **string** |  | [optional] 
**variant** | **string** |  | [optional] 
**build_datetime_utc** | **string** |  | [optional] 
**machine** | **string** |  | [optional] 
**status** | [**\Swagger\Client\Model\OSStatus**](OSStatus.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

