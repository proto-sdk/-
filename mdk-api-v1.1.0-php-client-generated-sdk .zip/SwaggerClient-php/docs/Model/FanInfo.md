# FanInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Each fan is assigned a unique identifier starting from 0. | [optional] 
**rpm** | **int** | The fan&#x27;s current rotations per minute (RPM). | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

