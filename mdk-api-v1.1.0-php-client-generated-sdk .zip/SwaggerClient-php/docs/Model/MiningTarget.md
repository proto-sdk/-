# MiningTarget

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**power_target_watts** | **int** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

