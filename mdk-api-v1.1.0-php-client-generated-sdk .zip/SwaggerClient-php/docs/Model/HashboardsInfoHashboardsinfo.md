# HashboardsInfoHashboardsinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hb_sn** | **string** | Hashboard serial number. | [optional] 
**firmware** | [**\Swagger\Client\Model\FWInfo**](FWInfo.md) |  | [optional] 
**bootloader** | [**\Swagger\Client\Model\FWInfo**](FWInfo.md) |  | [optional] 
**api_version** | **string** |  | [optional] 
**board** | **string** |  | [optional] 
**chip_id** | **string** |  | [optional] 
**mining_asic** | **string** |  | [optional] 
**mining_asic_count** | **int** | Number of asics on the hashboard. | [optional] 
**temp_sensor_count** | **int** | Number of temperature sensors on the hashboard. | [optional] 
**port** | **int** | The USB port number the hashboard is connected to. | [optional] 
**ec_logs_path** | **string** | The absolute path where EC logs are stored. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

