# PowerResponsePowerdata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**duration** | **string** | Duration of power data returned. | [optional] 
**data** | [**\Swagger\Client\Model\TimeSeriesData[]**](TimeSeriesData.md) |  | [optional] 
**aggregates** | [**\Swagger\Client\Model\Aggregates**](Aggregates.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

