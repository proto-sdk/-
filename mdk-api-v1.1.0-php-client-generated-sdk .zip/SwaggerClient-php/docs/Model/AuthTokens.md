# AuthTokens

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**refresh_token** | **string** | JWT refresh token. | 
**access_token** | **string** | JWT access token. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

