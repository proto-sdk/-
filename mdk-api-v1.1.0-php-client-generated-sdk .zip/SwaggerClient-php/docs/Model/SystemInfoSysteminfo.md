# SystemInfoSysteminfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**os** | [**\Swagger\Client\Model\OSInfo**](OSInfo.md) |  | [optional] 
**pool_interface_sw** | [**\Swagger\Client\Model\SWInfo**](SWInfo.md) |  | [optional] 
**mining_driver_sw** | [**\Swagger\Client\Model\SWInfo**](SWInfo.md) |  | [optional] 
**web_server** | [**\Swagger\Client\Model\SWInfo**](SWInfo.md) |  | [optional] 
**uptime_seconds** | **int** |  | [optional] 
**board** | **string** |  | [optional] 
**soc** | **string** |  | [optional] 
**cb_sn** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

