# PoolResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pool** | [**Pool**](Pool.md) |  |  [optional]
