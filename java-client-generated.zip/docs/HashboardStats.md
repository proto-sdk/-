# HashboardStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hashboardStats** | [**HashboardStatsHashboardstats**](HashboardStatsHashboardstats.md) |  |  [optional]
