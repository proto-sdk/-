# LogsResponseLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source** | **String** | Source of logs. |  [optional]
**lines** | **Integer** | Number of lines returned. |  [optional]
**content** | **List&lt;String&gt;** |  |  [optional]
