# Aggregates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min** | **Integer** | Minimum value in data. |  [optional]
**avg** | **Integer** | Average value in data. |  [optional]
**max** | **Integer** | Maximum value in data. |  [optional]
