# CoolingStatusCoolingstatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fanMode** | [**FanModeEnum**](#FanModeEnum) | Parameter to show the current fan mode. |  [optional]
**fans** | [**List&lt;FanInfo&gt;**](FanInfo.md) | This will show speed of all fans in the system. |  [optional]

<a name="FanModeEnum"></a>
## Enum: FanModeEnum
Name | Value
---- | -----
OFF | &quot;Off&quot;
AUTO | &quot;Auto&quot;
MAX | &quot;Max&quot;
