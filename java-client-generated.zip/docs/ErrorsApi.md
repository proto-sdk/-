# ErrorsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getErrors**](ErrorsApi.md#getErrors) | **GET** /api/v1/errors | 

<a name="getErrors"></a>
# **getErrors**
> ErrorListResponse getErrors()



The errors endpoint provides alerts to be surfaced in logs.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ErrorsApi;


ErrorsApi apiInstance = new ErrorsApi();
try {
    ErrorListResponse result = apiInstance.getErrors();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ErrorsApi#getErrors");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ErrorListResponse**](ErrorListResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

