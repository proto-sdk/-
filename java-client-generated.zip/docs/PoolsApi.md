# PoolsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createPools**](PoolsApi.md#createPools) | **POST** /api/v1/pools | 
[**deletePool**](PoolsApi.md#deletePool) | **DELETE** /api/v1/pools/{id} | 
[**editPool**](PoolsApi.md#editPool) | **PUT** /api/v1/pools/{id} | 
[**getPool**](PoolsApi.md#getPool) | **GET** /api/v1/pools/{id} | 
[**listPools**](PoolsApi.md#listPools) | **GET** /api/v1/pools | 
[**testPoolConnection**](PoolsApi.md#testPoolConnection) | **POST** /api/v1/pools/test-connection | 

<a name="createPools"></a>
# **createPools**
> MessageResponse createPools(body)



The post pools endpoint allows up to three pools to be configured, replacing the previous pool configuration.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PoolsApi;


PoolsApi apiInstance = new PoolsApi();
List<PoolConfigInner> body = Arrays.asList(new PoolConfigInner()); // List<PoolConfigInner> | 
try {
    MessageResponse result = apiInstance.createPools(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PoolsApi#createPools");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**List&lt;PoolConfigInner&gt;**](PoolConfigInner.md)|  | [optional]

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deletePool"></a>
# **deletePool**
> MessageResponse deletePool(id)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PoolsApi;


PoolsApi apiInstance = new PoolsApi();
Integer id = 56; // Integer | 
try {
    MessageResponse result = apiInstance.deletePool(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PoolsApi#deletePool");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**|  |

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="editPool"></a>
# **editPool**
> PoolConfigResponse editPool(body, id)



Using this pool configuration endpoint, users can edit the properties of an existing pool.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PoolsApi;


PoolsApi apiInstance = new PoolsApi();
PoolConfigInner body = new PoolConfigInner(); // PoolConfigInner | 
Integer id = 56; // Integer | 
try {
    PoolConfigResponse result = apiInstance.editPool(body, id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PoolsApi#editPool");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PoolConfigInner**](PoolConfigInner.md)|  |
 **id** | **Integer**|  |

### Return type

[**PoolConfigResponse**](PoolConfigResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getPool"></a>
# **getPool**
> PoolResponse getPool(id)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PoolsApi;


PoolsApi apiInstance = new PoolsApi();
Integer id = 56; // Integer | 
try {
    PoolResponse result = apiInstance.getPool(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PoolsApi#getPool");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Integer**|  |

### Return type

[**PoolResponse**](PoolResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="listPools"></a>
# **listPools**
> PoolsList listPools()



The get pools endpoint returns the full list of currently configured pools.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PoolsApi;


PoolsApi apiInstance = new PoolsApi();
try {
    PoolsList result = apiInstance.listPools();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PoolsApi#listPools");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**PoolsList**](PoolsList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="testPoolConnection"></a>
# **testPoolConnection**
> MessageResponse testPoolConnection(body)



Used to test a pool connection

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.PoolsApi;


PoolsApi apiInstance = new PoolsApi();
TestConnection body = new TestConnection(); // TestConnection | 
try {
    MessageResponse result = apiInstance.testPoolConnection(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PoolsApi#testPoolConnection");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TestConnection**](TestConnection.md)|  |

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

