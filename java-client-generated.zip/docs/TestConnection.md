# TestConnection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** | The pool URL is used to establish communication with the mining pool and it is essential that it includes the port information. |  [optional]
**username** | **String** | The user is an account that is used for authentication with the mining pool. In some cases, if the user has multiple mining devices, the pool may assign a worker name as the username for each mining device. |  [optional]
**password** | **String** | A password used for authentication and accessing the mining pool, which is ignored by SV1 pools. |  [optional]
