# FWInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** |  |  [optional]
**gitHash** | **String** |  |  [optional]
**imageHash** | **String** |  |  [optional]
**build** | [**BuildEnum**](#BuildEnum) |  |  [optional]

<a name="BuildEnum"></a>
## Enum: BuildEnum
Name | Value
---- | -----
DEBUG | &quot;debug&quot;
RELEASE | &quot;release&quot;
