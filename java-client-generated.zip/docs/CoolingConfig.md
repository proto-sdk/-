# CoolingConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mode** | [**ModeEnum**](#ModeEnum) | Parameter to define the cooling mode.  Modes:  - Off: Fans will be set to off for immersion cooling.  - Auto: Fans will be controlled based on miner temperature.  - Max: Fans will be run at full speed regardless of temperature. |  [optional]

<a name="ModeEnum"></a>
## Enum: ModeEnum
Name | Value
---- | -----
OFF | &quot;Off&quot;
AUTO | &quot;Auto&quot;
MAX | &quot;Max&quot;
