# HashboardsInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hashboardsInfo** | [**List&lt;HashboardsInfoHashboardsinfo&gt;**](HashboardsInfoHashboardsinfo.md) |  |  [optional]
