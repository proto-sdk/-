# TemperatureApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAsicTemperature**](TemperatureApi.md#getAsicTemperature) | **GET** /api/v1/temperature/{hb_sn}/{asic_id} | 
[**getHashboardTemperature**](TemperatureApi.md#getHashboardTemperature) | **GET** /api/v1/temperature/{hb_sn} | 
[**getMinerTemperature**](TemperatureApi.md#getMinerTemperature) | **GET** /api/v1/temperature | 

<a name="getAsicTemperature"></a>
# **getAsicTemperature**
> TemperatureResponse getAsicTemperature(hbSn, asicId, duration, granularity)



The hashrate endpoint provides ASIC-level historical temperature operation data.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.TemperatureApi;


TemperatureApi apiInstance = new TemperatureApi();
String hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide temperature information for.
Integer asicId = 56; // Integer | The ID of the ASIC to provide temperature information for.
String duration = "12h"; // String | 
String granularity = "1m"; // String | 
try {
    TemperatureResponse result = apiInstance.getAsicTemperature(hbSn, asicId, duration, granularity);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TemperatureApi#getAsicTemperature");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide temperature information for. |
 **asicId** | **Integer**| The ID of the ASIC to provide temperature information for. |
 **duration** | **String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]
 **granularity** | **String**|  | [optional] [default to 1m] [enum: 1m, 5m, 15m]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getHashboardTemperature"></a>
# **getHashboardTemperature**
> TemperatureResponse getHashboardTemperature(hbSn, duration)



The temperature endpoint provides hashboard-level historical operation data.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.TemperatureApi;


TemperatureApi apiInstance = new TemperatureApi();
String hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide temperature information for.
String duration = "12h"; // String | 
try {
    TemperatureResponse result = apiInstance.getHashboardTemperature(hbSn, duration);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TemperatureApi#getHashboardTemperature");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide temperature information for. |
 **duration** | **String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMinerTemperature"></a>
# **getMinerTemperature**
> TemperatureResponse getMinerTemperature(duration)



The temperature endpoint provides miner-level historical temperature operation data.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.TemperatureApi;


TemperatureApi apiInstance = new TemperatureApi();
String duration = "12h"; // String | 
try {
    TemperatureResponse result = apiInstance.getMinerTemperature(duration);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TemperatureApi#getMinerTemperature");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

