# HashrateResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hashrateData** | [**HashrateResponseHashratedata**](HashrateResponseHashratedata.md) |  |  [optional]
