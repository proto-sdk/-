# HashboardsInfoHashboardsinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hbSn** | **String** | Hashboard serial number. |  [optional]
**firmware** | [**FWInfo**](FWInfo.md) |  |  [optional]
**bootloader** | [**FWInfo**](FWInfo.md) |  |  [optional]
**apiVersion** | **String** |  |  [optional]
**board** | [**BoardEnum**](#BoardEnum) |  |  [optional]
**chipId** | **String** |  |  [optional]
**miningAsic** | [**MiningAsicEnum**](#MiningAsicEnum) |  |  [optional]
**miningAsicCount** | **Integer** | Number of asics on the hashboard. |  [optional]
**tempSensorCount** | **Integer** | Number of temperature sensors on the hashboard. |  [optional]
**port** | **Integer** | The USB port number the hashboard is connected to. |  [optional]
**ecLogsPath** | **String** | The absolute path where EC logs are stored. |  [optional]

<a name="BoardEnum"></a>
## Enum: BoardEnum
Name | Value
---- | -----
NOT_SET | &quot;NOT_SET&quot;
PROTO0_A | &quot;PROTO0_A&quot;
PROTO0_B | &quot;PROTO0_B&quot;
EVT | &quot;EVT&quot;
DVT | &quot;DVT&quot;
PVT | &quot;PVT&quot;
EVB | &quot;EVB&quot;
EPIC | &quot;EPIC&quot;
EE_TEST | &quot;EE_TEST&quot;

<a name="MiningAsicEnum"></a>
## Enum: MiningAsicEnum
Name | Value
---- | -----
BZM | &quot;BZM&quot;
MC1 | &quot;MC1&quot;
MC2 | &quot;MC2&quot;
