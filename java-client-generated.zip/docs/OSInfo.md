# OSInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**version** | **String** |  |  [optional]
**gitHash** | **String** |  |  [optional]
**variant** | [**VariantEnum**](#VariantEnum) |  |  [optional]
**buildDatetimeUtc** | **String** |  |  [optional]
**machine** | **String** |  |  [optional]
**status** | [**OSStatus**](OSStatus.md) |  |  [optional]

<a name="VariantEnum"></a>
## Enum: VariantEnum
Name | Value
---- | -----
RELEASE | &quot;release&quot;
MFG | &quot;mfg&quot;
DEV | &quot;dev&quot;
UNKNOWN | &quot;unknown&quot;
