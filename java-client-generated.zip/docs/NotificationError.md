# NotificationError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source** | [**SourceEnum**](#SourceEnum) |  |  [optional]
**componentIndex** | **Integer** |  |  [optional]
**hashboardIndex** | **Integer** |  |  [optional]
**asicIndex** | **Integer** |  |  [optional]
**errorCode** | **String** |  |  [optional]
**insertedAt** | **Integer** |  |  [optional]
**expiredAt** | **Integer** |  |  [optional]
**errorLevel** | [**ErrorLevelEnum**](#ErrorLevelEnum) |  |  [optional]
**message** | **String** |  |  [optional]
**details** | **String** |  |  [optional]

<a name="SourceEnum"></a>
## Enum: SourceEnum
Name | Value
---- | -----
MINER | &quot;Miner&quot;
HASHBOARD | &quot;Hashboard&quot;
ASIC | &quot;ASIC&quot;

<a name="ErrorLevelEnum"></a>
## Enum: ErrorLevelEnum
Name | Value
---- | -----
ERROR | &quot;Error&quot;
WARNING | &quot;Warning&quot;
