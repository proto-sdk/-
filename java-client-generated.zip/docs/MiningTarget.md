# MiningTarget

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**powerTargetWatts** | **Integer** |  |  [optional]
