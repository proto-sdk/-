# EfficiencyApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getHashboardEfficiency**](EfficiencyApi.md#getHashboardEfficiency) | **GET** /api/v1/efficiency/{hb_sn} | 
[**getMinerEfficiency**](EfficiencyApi.md#getMinerEfficiency) | **GET** /api/v1/efficiency | 

<a name="getHashboardEfficiency"></a>
# **getHashboardEfficiency**
> EfficiencyResponse getHashboardEfficiency(hbSn, duration)



The efficiency endpoint provides hashboard-level historical operation data.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EfficiencyApi;


EfficiencyApi apiInstance = new EfficiencyApi();
String hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide power information for.
String duration = "12h"; // String | 
try {
    EfficiencyResponse result = apiInstance.getHashboardEfficiency(hbSn, duration);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EfficiencyApi#getHashboardEfficiency");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide power information for. |
 **duration** | **String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**EfficiencyResponse**](EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMinerEfficiency"></a>
# **getMinerEfficiency**
> EfficiencyResponse getMinerEfficiency(duration)



The efficiency endpoint provides miner-level historical power operation data.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.EfficiencyApi;


EfficiencyApi apiInstance = new EfficiencyApi();
String duration = "12h"; // String | 
try {
    EfficiencyResponse result = apiInstance.getMinerEfficiency(duration);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling EfficiencyApi#getMinerEfficiency");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **String**|  | [optional] [default to 12h] [enum: 12h, 24h, 48h, 5d]

### Return type

[**EfficiencyResponse**](EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

