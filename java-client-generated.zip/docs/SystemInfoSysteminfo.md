# SystemInfoSysteminfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**os** | [**OSInfo**](OSInfo.md) |  |  [optional]
**poolInterfaceSw** | [**SWInfo**](SWInfo.md) |  |  [optional]
**miningDriverSw** | [**SWInfo**](SWInfo.md) |  |  [optional]
**webServer** | [**SWInfo**](SWInfo.md) |  |  [optional]
**uptimeSeconds** | **Long** |  |  [optional]
**board** | [**BoardEnum**](#BoardEnum) |  |  [optional]
**soc** | [**SocEnum**](#SocEnum) |  |  [optional]
**cbSn** | **String** |  |  [optional]

<a name="BoardEnum"></a>
## Enum: BoardEnum
Name | Value
---- | -----
STM32MP157D_DK1 | &quot;stm32mp157d-dk1&quot;
STM32MP157F_DK2 | &quot;stm32mp157f-dk2&quot;
C1_P0 | &quot;c1-p0&quot;
C1_EVT | &quot;c1-evt&quot;
UNKNOWN | &quot;unknown&quot;

<a name="SocEnum"></a>
## Enum: SocEnum
Name | Value
---- | -----
STM32MP157F | &quot;STM32MP157F&quot;
STM32MP157D | &quot;STM32MP157D&quot;
STM32MP151F | &quot;STM32MP151F&quot;
STM32MP131F | &quot;STM32MP131F&quot;
UNKNOWN | &quot;unknown&quot;
