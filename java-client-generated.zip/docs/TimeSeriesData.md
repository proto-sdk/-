# TimeSeriesData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datetime** | **Integer** | Unix time epoch. |  [optional]
**value** | **Integer** | Value of data requested at the given datetime. |  [optional]
