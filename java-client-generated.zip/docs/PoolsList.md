# PoolsList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pools** | [**List&lt;Pool&gt;**](Pool.md) |  |  [optional]
