# MiningStatusMiningstatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**StatusEnum**](#StatusEnum) | The indication will reveal whether the mining operation is currently active or has ceased |  [optional]
**miningUptimeS** | **Integer** | The amount of time in seconds that has passed since the start of the mining operation. |  [optional]
**rebootUptimeS** | **Integer** | The amount of time in seconds that has passed since the last reboot of the system. |  [optional]
**averageHashrateGhs** | [**BigDecimal**](BigDecimal.md) | The average hash rate in giga-hashes per second, since the device started mining. average_hashrate_ghs &#x3D; Total hash count / (elapsed_time_s * 10^9) |  [optional]
**idealHashrateGhs** | [**BigDecimal**](BigDecimal.md) | Expected hashrate determined by the current power level. |  [optional]
**powerUsageWatts** | [**BigDecimal**](BigDecimal.md) | Amount of power being consumed by mining in watts. |  [optional]
**powerTargetWatts** | [**BigDecimal**](BigDecimal.md) | Amount of power in watts for the system to target. |  [optional]
**averageEfficiencyJth** | [**BigDecimal**](BigDecimal.md) | The average efficiency in joules per terahash, since the device started mining. |  [optional]
**averageAsicTempC** | [**BigDecimal**](BigDecimal.md) | Average temperature of the ASICs in the mining device. |  [optional]
**averageHbTempC** | [**BigDecimal**](BigDecimal.md) | Average temperature of the mining device. |  [optional]
**hwErrors** | **Integer** | The number of hardware errors that have occurred during the mining operation. |  [optional]
**message** | **String** |  |  [optional]

<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----
UNINITIALIZED | &quot;Uninitialized&quot;
POWERINGON | &quot;PoweringOn&quot;
MINING | &quot;Mining&quot;
DEGRADEDMINING | &quot;DegradedMining&quot;
POWERINGOFF | &quot;PoweringOff&quot;
STOPPED | &quot;Stopped&quot;
NOPOOLS | &quot;NoPools&quot;
ERROR | &quot;Error&quot;
