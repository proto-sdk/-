# AsicStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Unique identifier assigned to each ASIC located on a hashboard, starting from 0. |  [optional]
**row** | **Integer** | Physical row location of the ASIC on the hashboard. |  [optional]
**column** | **Integer** | Physical column location of the ASIC on the hashboard. |  [optional]
**freqMhz** | [**BigDecimal**](BigDecimal.md) | The frequency of the ASIC measured in megahertz. |  [optional]
**tempC** | [**BigDecimal**](BigDecimal.md) | Current temperature of the ASIC in celsius |  [optional]
**hashrateGhs** | [**BigDecimal**](BigDecimal.md) | The current hash rate of the ASIC, measured in GH/s. |  [optional]
**idealHashrateGhs** | [**BigDecimal**](BigDecimal.md) | The expected hashrate determined by the clock frequency of the ASIC, measured in GH/s. |  [optional]
**errorRate** | [**BigDecimal**](BigDecimal.md) | The number of times that the ASIC produced an incorrect hash or an error during a specific period of time.  Error Rate (%) &#x3D; (Number of incorrect hash / Total number of expected Hash) x 100% |  [optional]
