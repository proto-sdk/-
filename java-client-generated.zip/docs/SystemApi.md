# SystemApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getSystemInfo**](SystemApi.md#getSystemInfo) | **GET** /api/v1/system | 
[**getSystemLogs**](SystemApi.md#getSystemLogs) | **GET** /api/v1/system/logs | 
[**locateSystem**](SystemApi.md#locateSystem) | **POST** /api/v1/system/locate | 
[**rebootSystem**](SystemApi.md#rebootSystem) | **POST** /api/v1/system/reboot | 

<a name="getSystemInfo"></a>
# **getSystemInfo**
> SystemInfo getSystemInfo()



The system endpoint provides information related to the control board including OS, software, and hardware component details.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.SystemApi;


SystemApi apiInstance = new SystemApi();
try {
    SystemInfo result = apiInstance.getSystemInfo();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SystemApi#getSystemInfo");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SystemInfo**](SystemInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getSystemLogs"></a>
# **getSystemLogs**
> LogsResponse getSystemLogs(lines, source)



The logs endpoint provides the most recent log lines from a given source, either OS, pool software, or miner logs.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.SystemApi;


SystemApi apiInstance = new SystemApi();
Integer lines = 100; // Integer | Number of log lines to return from the tail of the log, up to a maximum of 10000 lines. Defaults to 100 lines.
String source = "miner_sw"; // String | Source of logs to fetch. Defaults to miner software logs.
try {
    LogsResponse result = apiInstance.getSystemLogs(lines, source);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SystemApi#getSystemLogs");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lines** | **Integer**| Number of log lines to return from the tail of the log, up to a maximum of 10000 lines. Defaults to 100 lines. | [optional] [default to 100]
 **source** | **String**| Source of logs to fetch. Defaults to miner software logs. | [optional] [default to miner_sw] [enum: os, pool_sw, miner_sw, miner_web_server]

### Return type

[**LogsResponse**](LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="locateSystem"></a>
# **locateSystem**
> MessageResponse locateSystem(ledOnTime)



The locate system endpoint can be used to flash the indicator LED on the control board to assist in finding the miner.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SystemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SystemApi apiInstance = new SystemApi();
Integer ledOnTime = 30; // Integer | The duration in seconds for which to turn on the LED, with a max value of 300 seconds. If not specified, a default value of 30 seconds will be used. Requests made while the LED is on will be ignored.
try {
    MessageResponse result = apiInstance.locateSystem(ledOnTime);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SystemApi#locateSystem");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ledOnTime** | **Integer**| The duration in seconds for which to turn on the LED, with a max value of 300 seconds. If not specified, a default value of 30 seconds will be used. Requests made while the LED is on will be ignored. | [optional] [default to 30]

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="rebootSystem"></a>
# **rebootSystem**
> MessageResponse rebootSystem()



The reboot endpoint can be used to reboot the entire system.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.SystemApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();


SystemApi apiInstance = new SystemApi();
try {
    MessageResponse result = apiInstance.rebootSystem();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SystemApi#rebootSystem");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

