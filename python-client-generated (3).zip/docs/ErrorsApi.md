# swagger_client.ErrorsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_errors**](ErrorsApi.md#get_errors) | **GET** /api/v1/errors | 

# **get_errors**
> ErrorListResponse get_errors()



The errors endpoint provides alerts to be surfaced in logs.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ErrorsApi()

try:
    api_response = api_instance.get_errors()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ErrorsApi->get_errors: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ErrorListResponse**](ErrorListResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

