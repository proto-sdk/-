# Aggregates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min** | **int** | Minimum value in data. | [optional] 
**avg** | **int** | Average value in data. | [optional] 
**max** | **int** | Maximum value in data. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

