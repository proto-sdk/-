# HashboardsInfoHashboardsinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hb_sn** | **str** | Hashboard serial number. | [optional] 
**firmware** | [**FWInfo**](FWInfo.md) |  | [optional] 
**bootloader** | [**FWInfo**](FWInfo.md) |  | [optional] 
**api_version** | **str** |  | [optional] 
**board** | **str** |  | [optional] 
**chip_id** | **str** |  | [optional] 
**mining_asic** | **str** |  | [optional] 
**mining_asic_count** | **int** | Number of asics on the hashboard. | [optional] 
**temp_sensor_count** | **int** | Number of temperature sensors on the hashboard. | [optional] 
**port** | **int** | The USB port number the hashboard is connected to. | [optional] 
**ec_logs_path** | **str** | The absolute path where EC logs are stored. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

