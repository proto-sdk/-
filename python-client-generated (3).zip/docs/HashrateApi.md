# swagger_client.HashrateApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_asic_hashrate**](HashrateApi.md#get_asic_hashrate) | **GET** /api/v1/hashrate/{hb_sn}/{asic_id} | 
[**get_hashboard_hashrate**](HashrateApi.md#get_hashboard_hashrate) | **GET** /api/v1/hashrate/{hb_sn} | 
[**get_miner_hashrate**](HashrateApi.md#get_miner_hashrate) | **GET** /api/v1/hashrate | 

# **get_asic_hashrate**
> HashrateResponse get_asic_hashrate(hb_sn, asic_id, duration=duration, granularity=granularity)



The hashrate endpoint provides ASIC-level historical hashrate operation data.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HashrateApi()
hb_sn = 'hb_sn_example' # str | The serial number of the hashboard to provide hashrate information for.
asic_id = 56 # int | The ID of the ASIC to provide hashrate information for.
duration = '12h' # str |  (optional) (default to 12h)
granularity = '1m' # str |  (optional) (default to 1m)

try:
    api_response = api_instance.get_asic_hashrate(hb_sn, asic_id, duration=duration, granularity=granularity)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HashrateApi->get_asic_hashrate: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **str**| The serial number of the hashboard to provide hashrate information for. | 
 **asic_id** | **int**| The ID of the ASIC to provide hashrate information for. | 
 **duration** | **str**|  | [optional] [default to 12h]
 **granularity** | **str**|  | [optional] [default to 1m]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_hashboard_hashrate**
> HashrateResponse get_hashboard_hashrate(hb_sn, duration=duration)



The hashrate endpoint provides hashboard-level historical operation data.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HashrateApi()
hb_sn = 'hb_sn_example' # str | The serial number of the hashboard to provide hashrate information for.
duration = '12h' # str |  (optional) (default to 12h)

try:
    api_response = api_instance.get_hashboard_hashrate(hb_sn, duration=duration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HashrateApi->get_hashboard_hashrate: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **str**| The serial number of the hashboard to provide hashrate information for. | 
 **duration** | **str**|  | [optional] [default to 12h]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_miner_hashrate**
> HashrateResponse get_miner_hashrate(duration=duration)



The hashrate endpoint provides miner-level historical hashrate operation data.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HashrateApi()
duration = '12h' # str |  (optional) (default to 12h)

try:
    api_response = api_instance.get_miner_hashrate(duration=duration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HashrateApi->get_miner_hashrate: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **str**|  | [optional] [default to 12h]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

