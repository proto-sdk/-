# HashboardsInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hashboards_info** | [**list[HashboardsInfoHashboardsinfo]**](HashboardsInfoHashboardsinfo.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

