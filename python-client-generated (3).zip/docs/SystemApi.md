# swagger_client.SystemApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_system_info**](SystemApi.md#get_system_info) | **GET** /api/v1/system | 
[**get_system_logs**](SystemApi.md#get_system_logs) | **GET** /api/v1/system/logs | 
[**locate_system**](SystemApi.md#locate_system) | **POST** /api/v1/system/locate | 
[**reboot_system**](SystemApi.md#reboot_system) | **POST** /api/v1/system/reboot | 

# **get_system_info**
> SystemInfo get_system_info()



The system endpoint provides information related to the control board including OS, software, and hardware component details.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SystemApi()

try:
    api_response = api_instance.get_system_info()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SystemApi->get_system_info: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SystemInfo**](SystemInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_system_logs**
> LogsResponse get_system_logs(lines=lines, source=source)



The logs endpoint provides the most recent log lines from a given source, either OS, pool software, or miner logs.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SystemApi()
lines = 100 # int | Number of log lines to return from the tail of the log, up to a maximum of 10000 lines. Defaults to 100 lines. (optional) (default to 100)
source = 'miner_sw' # str | Source of logs to fetch. Defaults to miner software logs. (optional) (default to miner_sw)

try:
    api_response = api_instance.get_system_logs(lines=lines, source=source)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SystemApi->get_system_logs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lines** | **int**| Number of log lines to return from the tail of the log, up to a maximum of 10000 lines. Defaults to 100 lines. | [optional] [default to 100]
 **source** | **str**| Source of logs to fetch. Defaults to miner software logs. | [optional] [default to miner_sw]

### Return type

[**LogsResponse**](LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **locate_system**
> MessageResponse locate_system(led_on_time=led_on_time)



The locate system endpoint can be used to flash the indicator LED on the control board to assist in finding the miner.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SystemApi()
led_on_time = 30 # int | The duration in seconds for which to turn on the LED, with a max value of 300 seconds. If not specified, a default value of 30 seconds will be used. Requests made while the LED is on will be ignored. (optional) (default to 30)

try:
    api_response = api_instance.locate_system(led_on_time=led_on_time)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SystemApi->locate_system: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **led_on_time** | **int**| The duration in seconds for which to turn on the LED, with a max value of 300 seconds. If not specified, a default value of 30 seconds will be used. Requests made while the LED is on will be ignored. | [optional] [default to 30]

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **reboot_system**
> MessageResponse reboot_system()



The reboot endpoint can be used to reboot the entire system.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SystemApi()

try:
    api_response = api_instance.reboot_system()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SystemApi->reboot_system: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

