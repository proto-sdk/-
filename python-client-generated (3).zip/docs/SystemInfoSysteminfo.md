# SystemInfoSysteminfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**os** | [**OSInfo**](OSInfo.md) |  | [optional] 
**pool_interface_sw** | [**SWInfo**](SWInfo.md) |  | [optional] 
**mining_driver_sw** | [**SWInfo**](SWInfo.md) |  | [optional] 
**web_server** | [**SWInfo**](SWInfo.md) |  | [optional] 
**uptime_seconds** | **int** |  | [optional] 
**board** | **str** |  | [optional] 
**soc** | **str** |  | [optional] 
**cb_sn** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

