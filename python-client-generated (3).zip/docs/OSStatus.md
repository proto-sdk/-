# OSStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mem_total_kb** | **int** |  | [optional] 
**mem_free_kb** | **int** |  | [optional] 
**cpu_load_percent** | **float** |  | [optional] 
**rootfs_total_mb** | **int** |  | [optional] 
**rootfs_free_mb** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

