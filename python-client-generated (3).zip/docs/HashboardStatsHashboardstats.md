# HashboardStatsHashboardstats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hb_sn** | **str** | Manufacturing serial number of the hashboard, used for subsequent API calls. | [optional] 
**hb_id** | **str** | Internal ID of the hashboard, assigned to each hashboard starting from 0. | [optional] 
**status** | **str** | The current state or condition of the hashboard. | [optional] 
**power_usage_watts** | **int** | The power consumption of the hashboard in watts. | [optional] 
**voltage_mv** | **int** | The present voltage being supplied to the hashboard in millivolts. | [optional] 
**avg_asic_temp_c** | **float** | Current average temperature of the hashboard in celsius. | [optional] 
**hashrate_ghs** | **float** | The current hash rate of the hashboard, measured in GH/s. It will be sum of all ASIC hashrate_ghs values. | [optional] 
**ideal_hashrate_ghs** | **float** | The expected hashrate is determined by the clock frequency of the all ASIC on the hash board, measured in GH/s. | [optional] 
**efficiency_jth** | **float** | The efficiency of the hashboard in joules per terahash. | [optional] 
**asics** | [**list[AsicStats]**](AsicStats.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

