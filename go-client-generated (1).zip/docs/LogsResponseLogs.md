# LogsResponseLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Source** | **string** | Source of logs. | [optional] [default to null]
**Lines** | **int32** | Number of lines returned. | [optional] [default to null]
**Content** | **[]string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

