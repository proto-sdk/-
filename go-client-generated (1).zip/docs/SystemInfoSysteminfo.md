# SystemInfoSysteminfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Os** | [***OsInfo**](OSInfo.md) |  | [optional] [default to null]
**PoolInterfaceSw** | [***SwInfo**](SWInfo.md) |  | [optional] [default to null]
**MiningDriverSw** | [***SwInfo**](SWInfo.md) |  | [optional] [default to null]
**WebServer** | [***SwInfo**](SWInfo.md) |  | [optional] [default to null]
**UptimeSeconds** | **int64** |  | [optional] [default to null]
**Board** | **string** |  | [optional] [default to null]
**Soc** | **string** |  | [optional] [default to null]
**CbSn** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

