# HashboardStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HashboardStats** | [***HashboardStatsHashboardstats**](HashboardStats_hashboardstats.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

