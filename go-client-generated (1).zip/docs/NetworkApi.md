# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetNetwork**](NetworkApi.md#GetNetwork) | **Get** /api/v1/network | 
[**SetNetworkConfig**](NetworkApi.md#SetNetworkConfig) | **Put** /api/v1/network | 

# **GetNetwork**
> NetworkInfo GetNetwork(ctx, )


The network GET endpoint provides information related to the network configuration of the miner including IP address, gateways, and MAC address.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SetNetworkConfig**
> NetworkInfo SetNetworkConfig(ctx, body)


The network PUT endpoint allows the user to change the configuration of the miner between DHCP and a static IP.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**NetworkConfig**](NetworkConfig.md)|  | 

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

