# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAsicTemperature**](TemperatureApi.md#GetAsicTemperature) | **Get** /api/v1/temperature/{hb_sn}/{asic_id} | 
[**GetHashboardTemperature**](TemperatureApi.md#GetHashboardTemperature) | **Get** /api/v1/temperature/{hb_sn} | 
[**GetMinerTemperature**](TemperatureApi.md#GetMinerTemperature) | **Get** /api/v1/temperature | 

# **GetAsicTemperature**
> TemperatureResponse GetAsicTemperature(ctx, hbSn, asicId, optional)


The hashrate endpoint provides ASIC-level historical temperature operation data.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **hbSn** | **string**| The serial number of the hashboard to provide temperature information for. | 
  **asicId** | **int32**| The ID of the ASIC to provide temperature information for. | 
 **optional** | ***TemperatureApiGetAsicTemperatureOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a TemperatureApiGetAsicTemperatureOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **duration** | **optional.String**|  | [default to 12h]
 **granularity** | **optional.String**|  | [default to 1m]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetHashboardTemperature**
> TemperatureResponse GetHashboardTemperature(ctx, hbSn, optional)


The temperature endpoint provides hashboard-level historical operation data.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **hbSn** | **string**| The serial number of the hashboard to provide temperature information for. | 
 **optional** | ***TemperatureApiGetHashboardTemperatureOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a TemperatureApiGetHashboardTemperatureOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **duration** | **optional.String**|  | [default to 12h]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetMinerTemperature**
> TemperatureResponse GetMinerTemperature(ctx, optional)


The temperature endpoint provides miner-level historical temperature operation data.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***TemperatureApiGetMinerTemperatureOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a TemperatureApiGetMinerTemperatureOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **optional.String**|  | [default to 12h]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

