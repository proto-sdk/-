# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetCooling**](CoolingApi.md#GetCooling) | **Get** /api/v1/cooling | 
[**SetCoolingMode**](CoolingApi.md#SetCoolingMode) | **Put** /api/v1/cooling | 

# **GetCooling**
> CoolingStatus GetCooling(ctx, )


The cooling endpoint provides information on the cooling status of the device, including mode and current fan RPM.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**CoolingStatus**](CoolingStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SetCoolingMode**
> CoolingConfig SetCoolingMode(ctx, body)


The cooling configuration endpoint allows the user to control the fan mode.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**CoolingConfig**](CoolingConfig.md)|  | 

### Return type

[**CoolingConfig**](CoolingConfig.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

