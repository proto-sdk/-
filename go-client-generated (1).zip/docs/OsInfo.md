# OsInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] [default to null]
**Version** | **string** |  | [optional] [default to null]
**GitHash** | **string** |  | [optional] [default to null]
**Variant** | **string** |  | [optional] [default to null]
**BuildDatetimeUtc** | **string** |  | [optional] [default to null]
**Machine** | **string** |  | [optional] [default to null]
**Status** | [***OsStatus**](OSStatus.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

