# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetErrors**](ErrorsApi.md#GetErrors) | **Get** /api/v1/errors | 

# **GetErrors**
> []NotificationError GetErrors(ctx, )


The errors endpoint provides alerts to be surfaced in logs.

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**[]NotificationError**](array.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

