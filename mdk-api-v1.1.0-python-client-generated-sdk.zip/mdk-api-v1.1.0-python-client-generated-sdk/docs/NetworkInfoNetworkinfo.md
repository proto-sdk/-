# NetworkInfoNetworkinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mac** | **str** |  | [optional] 
**dhcp** | **bool** |  | [optional] 
**ip** | **str** |  | [optional] 
**netmask** | **str** |  | [optional] 
**gateway** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

