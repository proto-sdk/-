# swagger_client.MiningApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**edit_mining_target**](MiningApi.md#edit_mining_target) | **PUT** /api/v1/mining/target | 
[**get_mining_status**](MiningApi.md#get_mining_status) | **GET** /api/v1/mining | 
[**get_mining_target**](MiningApi.md#get_mining_target) | **GET** /api/v1/mining/target | 
[**start_mining**](MiningApi.md#start_mining) | **POST** /api/v1/mining/start | 
[**stop_mining**](MiningApi.md#stop_mining) | **POST** /api/v1/mining/stop | 

# **edit_mining_target**
> MiningTarget edit_mining_target(body)



The mining target endpoint can be used to set a target power consumption for the miner. Once set, the mining device will operate to consume as close to that amount of power as possible. In the event that the device is unable to maintain its temperature within the allowed range, it may scale down and use less power.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.MiningApi(swagger_client.ApiClient(configuration))
body = swagger_client.MiningTarget() # MiningTarget | 

try:
    api_response = api_instance.edit_mining_target(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MiningApi->edit_mining_target: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**MiningTarget**](MiningTarget.md)|  | 

### Return type

[**MiningTarget**](MiningTarget.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_mining_status**
> MiningStatus get_mining_status()



The mining endpoint provides summary information about the mining operations of the device. This includes device level hashrate statistics, overall miner status, and current power usage and target information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.MiningApi()

try:
    api_response = api_instance.get_mining_status()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MiningApi->get_mining_status: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MiningStatus**](MiningStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_mining_target**
> MiningTarget get_mining_target()



The mining target endpoint returns the current power target in watts that the miner is controlling for.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.MiningApi()

try:
    api_response = api_instance.get_mining_target()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MiningApi->get_mining_target: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MiningTarget**](MiningTarget.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **start_mining**
> MessageResponse start_mining()



The start mining endpoint can be used to make the device start mining, into account the current power target of the system.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.MiningApi(swagger_client.ApiClient(configuration))

try:
    api_response = api_instance.start_mining()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MiningApi->start_mining: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **stop_mining**
> MessageResponse stop_mining()



The stop mining endpoint can be used to stop the device from mining, going into a minimal power mode with only the control board running.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.MiningApi(swagger_client.ApiClient(configuration))

try:
    api_response = api_instance.stop_mining()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling MiningApi->stop_mining: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

