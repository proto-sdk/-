# swagger_client.AuthenticationApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_v1_auth_logout_post**](AuthenticationApi.md#api_v1_auth_logout_post) | **POST** /api/v1/auth/logout | User logout
[**api_v1_auth_refresh_post**](AuthenticationApi.md#api_v1_auth_refresh_post) | **POST** /api/v1/auth/refresh | Refresh JWT access token
[**login**](AuthenticationApi.md#login) | **POST** /api/v1/auth/login | 
[**set_password**](AuthenticationApi.md#set_password) | **PUT** /api/v1/auth/password | 

# **api_v1_auth_logout_post**
> MessageResponse api_v1_auth_logout_post(body)

User logout

Validates and blacklists JWT tokens, effectively logging out the user.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.AuthenticationApi(swagger_client.ApiClient(configuration))
body = swagger_client.AuthTokens() # AuthTokens | 

try:
    # User logout
    api_response = api_instance.api_v1_auth_logout_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AuthenticationApi->api_v1_auth_logout_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AuthTokens**](AuthTokens.md)|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_v1_auth_refresh_post**
> RefreshResponse api_v1_auth_refresh_post(body)

Refresh JWT access token

Validates the provided refresh token and returns a new JWT access token.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.AuthenticationApi()
body = swagger_client.RefreshRequest() # RefreshRequest | 

try:
    # Refresh JWT access token
    api_response = api_instance.api_v1_auth_refresh_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AuthenticationApi->api_v1_auth_refresh_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RefreshRequest**](RefreshRequest.md)|  | 

### Return type

[**RefreshResponse**](RefreshResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **login**
> AuthTokens login(body)



Authenticates a user using a password and returns a JWT access and refresh token pair.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.AuthenticationApi()
body = swagger_client.PasswordRequest() # PasswordRequest | 

try:
    api_response = api_instance.login(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AuthenticationApi->login: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PasswordRequest**](PasswordRequest.md)|  | 

### Return type

[**AuthTokens**](AuthTokens.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_password**
> MessageResponse set_password(body)



The password endpoint allows users to set a password during onboarding

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.AuthenticationApi()
body = swagger_client.PasswordRequest() # PasswordRequest | 

try:
    api_response = api_instance.set_password(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AuthenticationApi->set_password: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PasswordRequest**](PasswordRequest.md)|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

