# CoolingStatusCoolingstatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fan_mode** | **str** | Parameter to show the current fan mode. | [optional] 
**fans** | [**list[FanInfo]**](FanInfo.md) | This will show speed of all fans in the system. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

