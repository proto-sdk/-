# PowerResponsePowerdata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**duration** | **str** | Duration of power data returned. | [optional] 
**data** | [**list[TimeSeriesData]**](TimeSeriesData.md) |  | [optional] 
**aggregates** | [**Aggregates**](Aggregates.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

