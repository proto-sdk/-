# swagger_client.EfficiencyApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_hashboard_efficiency**](EfficiencyApi.md#get_hashboard_efficiency) | **GET** /api/v1/efficiency/{hb_sn} | 
[**get_miner_efficiency**](EfficiencyApi.md#get_miner_efficiency) | **GET** /api/v1/efficiency | 

# **get_hashboard_efficiency**
> EfficiencyResponse get_hashboard_efficiency(hb_sn, duration=duration)



The efficiency endpoint provides hashboard-level historical operation data.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EfficiencyApi()
hb_sn = 'hb_sn_example' # str | The serial number of the hashboard to provide power information for.
duration = '12h' # str |  (optional) (default to 12h)

try:
    api_response = api_instance.get_hashboard_efficiency(hb_sn, duration=duration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EfficiencyApi->get_hashboard_efficiency: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **str**| The serial number of the hashboard to provide power information for. | 
 **duration** | **str**|  | [optional] [default to 12h]

### Return type

[**EfficiencyResponse**](EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_miner_efficiency**
> EfficiencyResponse get_miner_efficiency(duration=duration)



The efficiency endpoint provides miner-level historical power operation data.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.EfficiencyApi()
duration = '12h' # str |  (optional) (default to 12h)

try:
    api_response = api_instance.get_miner_efficiency(duration=duration)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EfficiencyApi->get_miner_efficiency: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **str**|  | [optional] [default to 12h]

### Return type

[**EfficiencyResponse**](EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

