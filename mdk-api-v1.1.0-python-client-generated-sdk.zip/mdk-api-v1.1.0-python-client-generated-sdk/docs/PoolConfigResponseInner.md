# PoolConfigResponseInner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** | The pool URL is used to establish communication with the mining pool and it is essential that it includes the port information. | [optional] 
**username** | **str** | The user is an account that is used for authentication with the mining pool. In some cases, if the user has multiple mining devices, the pool may assign a worker name as the username for each mining device. | [optional] 
**priority** | **int** | Connection priority for this pool. Lower numbers are higher priorities, with 0 being the maximum. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

