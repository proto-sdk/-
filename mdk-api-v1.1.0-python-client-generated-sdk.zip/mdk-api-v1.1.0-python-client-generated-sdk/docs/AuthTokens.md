# AuthTokens

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**refresh_token** | **str** | JWT refresh token. | 
**access_token** | **str** | JWT access token. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

