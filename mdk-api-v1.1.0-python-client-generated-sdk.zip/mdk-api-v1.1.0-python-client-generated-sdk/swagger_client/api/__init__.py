from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from swagger_client.api.authentication_api import AuthenticationApi
from swagger_client.api.cooling_api import CoolingApi
from swagger_client.api.efficiency_api import EfficiencyApi
from swagger_client.api.errors_api import ErrorsApi
from swagger_client.api.hashboards_api import HashboardsApi
from swagger_client.api.hashrate_api import HashrateApi
from swagger_client.api.mining_api import MiningApi
from swagger_client.api.network_api import NetworkApi
from swagger_client.api.pools_api import PoolsApi
from swagger_client.api.power_api import PowerApi
from swagger_client.api.system_api import SystemApi
from swagger_client.api.system_information_api import SystemInformationApi
from swagger_client.api.temperature_api import TemperatureApi
