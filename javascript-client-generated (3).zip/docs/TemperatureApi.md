# MiningDevelopmentKitApi.TemperatureApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAsicTemperature**](TemperatureApi.md#getAsicTemperature) | **GET** /api/v1/temperature/{hb_sn}/{asic_id} | 
[**getHashboardTemperature**](TemperatureApi.md#getHashboardTemperature) | **GET** /api/v1/temperature/{hb_sn} | 
[**getMinerTemperature**](TemperatureApi.md#getMinerTemperature) | **GET** /api/v1/temperature | 

<a name="getAsicTemperature"></a>
# **getAsicTemperature**
> TemperatureResponse getAsicTemperature(hbSn, asicId, opts)



The hashrate endpoint provides ASIC-level historical temperature operation data.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.TemperatureApi();
let hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide temperature information for.
let asicId = 56; // Number | The ID of the ASIC to provide temperature information for.
let opts = { 
  'duration': "12h", // String | 
  'granularity': "1m" // String | 
};
apiInstance.getAsicTemperature(hbSn, asicId, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide temperature information for. | 
 **asicId** | **Number**| The ID of the ASIC to provide temperature information for. | 
 **duration** | **String**|  | [optional] [default to 12h]
 **granularity** | **String**|  | [optional] [default to 1m]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getHashboardTemperature"></a>
# **getHashboardTemperature**
> TemperatureResponse getHashboardTemperature(hbSn, opts)



The temperature endpoint provides hashboard-level historical operation data.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.TemperatureApi();
let hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide temperature information for.
let opts = { 
  'duration': "12h" // String | 
};
apiInstance.getHashboardTemperature(hbSn, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide temperature information for. | 
 **duration** | **String**|  | [optional] [default to 12h]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMinerTemperature"></a>
# **getMinerTemperature**
> TemperatureResponse getMinerTemperature(opts)



The temperature endpoint provides miner-level historical temperature operation data.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.TemperatureApi();
let opts = { 
  'duration': "12h" // String | 
};
apiInstance.getMinerTemperature(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **String**|  | [optional] [default to 12h]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

