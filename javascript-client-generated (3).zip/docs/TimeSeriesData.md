# MiningDevelopmentKitApi.TimeSeriesData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datetime** | **Number** | Unix time epoch. | [optional] 
**value** | **Number** | Value of data requested at the given datetime. | [optional] 
