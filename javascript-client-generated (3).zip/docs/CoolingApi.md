# MiningDevelopmentKitApi.CoolingApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getCooling**](CoolingApi.md#getCooling) | **GET** /api/v1/cooling | 
[**setCoolingMode**](CoolingApi.md#setCoolingMode) | **PUT** /api/v1/cooling | 

<a name="getCooling"></a>
# **getCooling**
> CoolingStatus getCooling()



The cooling endpoint provides information on the cooling status of the device, including mode and current fan RPM.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.CoolingApi();
apiInstance.getCooling((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**CoolingStatus**](CoolingStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="setCoolingMode"></a>
# **setCoolingMode**
> CoolingConfig setCoolingMode(body)



The cooling configuration endpoint allows the user to control the fan mode.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.CoolingApi();
let body = new MiningDevelopmentKitApi.CoolingConfig(); // CoolingConfig | 

apiInstance.setCoolingMode(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CoolingConfig**](CoolingConfig.md)|  | 

### Return type

[**CoolingConfig**](CoolingConfig.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

