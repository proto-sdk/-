# MiningDevelopmentKitApi.OSInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**version** | **String** |  | [optional] 
**gitHash** | **String** |  | [optional] 
**variant** | **String** |  | [optional] 
**buildDatetimeUtc** | **String** |  | [optional] 
**machine** | **String** |  | [optional] 
**status** | [**OSStatus**](OSStatus.md) |  | [optional] 

<a name="VariantEnum"></a>
## Enum: VariantEnum

* `release` (value: `"release"`)
* `mfg` (value: `"mfg"`)
* `dev` (value: `"dev"`)
* `unknown` (value: `"unknown"`)

