# MiningDevelopmentKitApi.SystemInfoSysteminfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**os** | [**OSInfo**](OSInfo.md) |  | [optional] 
**poolInterfaceSw** | [**SWInfo**](SWInfo.md) |  | [optional] 
**miningDriverSw** | [**SWInfo**](SWInfo.md) |  | [optional] 
**webServer** | [**SWInfo**](SWInfo.md) |  | [optional] 
**uptimeSeconds** | **Number** |  | [optional] 
**board** | **String** |  | [optional] 
**soc** | **String** |  | [optional] 
**cbSn** | **String** |  | [optional] 

<a name="BoardEnum"></a>
## Enum: BoardEnum

* `stm32mp157dDk1` (value: `"stm32mp157d-dk1"`)
* `stm32mp157fDk2` (value: `"stm32mp157f-dk2"`)
* `c1P0` (value: `"c1-p0"`)
* `c1Evt` (value: `"c1-evt"`)
* `unknown` (value: `"unknown"`)


<a name="SocEnum"></a>
## Enum: SocEnum

* `sTM32MP157F` (value: `"STM32MP157F"`)
* `sTM32MP157D` (value: `"STM32MP157D"`)
* `sTM32MP151F` (value: `"STM32MP151F"`)
* `sTM32MP131F` (value: `"STM32MP131F"`)
* `unknown` (value: `"unknown"`)

