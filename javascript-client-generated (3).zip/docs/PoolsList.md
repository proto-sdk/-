# MiningDevelopmentKitApi.PoolsList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pools** | [**[Pool]**](Pool.md) |  | [optional] 
