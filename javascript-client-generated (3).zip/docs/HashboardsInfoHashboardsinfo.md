# MiningDevelopmentKitApi.HashboardsInfoHashboardsinfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hbSn** | **String** | Hashboard serial number. | [optional] 
**firmware** | [**FWInfo**](FWInfo.md) |  | [optional] 
**bootloader** | [**FWInfo**](FWInfo.md) |  | [optional] 
**apiVersion** | **String** |  | [optional] 
**board** | **String** |  | [optional] 
**chipId** | **String** |  | [optional] 
**miningAsic** | **String** |  | [optional] 
**miningAsicCount** | **Number** | Number of asics on the hashboard. | [optional] 
**tempSensorCount** | **Number** | Number of temperature sensors on the hashboard. | [optional] 
**port** | **Number** | The USB port number the hashboard is connected to. | [optional] 
**ecLogsPath** | **String** | The absolute path where EC logs are stored. | [optional] 

<a name="BoardEnum"></a>
## Enum: BoardEnum

* `NOT_SET` (value: `"NOT_SET"`)
* `pROTO0A` (value: `"PROTO0_A"`)
* `pROTO0B` (value: `"PROTO0_B"`)
* `EVT` (value: `"EVT"`)
* `DVT` (value: `"DVT"`)
* `PVT` (value: `"PVT"`)
* `EVB` (value: `"EVB"`)
* `EPIC` (value: `"EPIC"`)
* `EE_TEST` (value: `"EE_TEST"`)


<a name="MiningAsicEnum"></a>
## Enum: MiningAsicEnum

* `BZM` (value: `"BZM"`)
* `mC1` (value: `"MC1"`)
* `mC2` (value: `"MC2"`)

