# MiningDevelopmentKitApi.PowerResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**powerData** | [**PowerResponsePowerdata**](PowerResponsePowerdata.md) |  | [optional] 
