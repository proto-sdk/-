# MiningDevelopmentKitApi.SystemStatuses

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**onboarded** | **Boolean** |  | [optional] 
