# MiningDevelopmentKitApi.MiningApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**editMiningTarget**](MiningApi.md#editMiningTarget) | **PUT** /api/v1/mining/target | 
[**getMiningStatus**](MiningApi.md#getMiningStatus) | **GET** /api/v1/mining | 
[**getMiningTarget**](MiningApi.md#getMiningTarget) | **GET** /api/v1/mining/target | 
[**startMining**](MiningApi.md#startMining) | **POST** /api/v1/mining/start | 
[**stopMining**](MiningApi.md#stopMining) | **POST** /api/v1/mining/stop | 

<a name="editMiningTarget"></a>
# **editMiningTarget**
> MiningTarget editMiningTarget(body)



The mining target endpoint can be used to set a target power consumption for the miner. Once set, the mining device will operate to consume as close to that amount of power as possible. In the event that the device is unable to maintain its temperature within the allowed range, it may scale down and use less power.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.MiningApi();
let body = new MiningDevelopmentKitApi.MiningTarget(); // MiningTarget | 

apiInstance.editMiningTarget(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**MiningTarget**](MiningTarget.md)|  | 

### Return type

[**MiningTarget**](MiningTarget.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getMiningStatus"></a>
# **getMiningStatus**
> MiningStatus getMiningStatus()



The mining endpoint provides summary information about the mining operations of the device. This includes device level hashrate statistics, overall miner status, and current power usage and target information.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.MiningApi();
apiInstance.getMiningStatus((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MiningStatus**](MiningStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getMiningTarget"></a>
# **getMiningTarget**
> MiningTarget getMiningTarget()



The mining target endpoint returns the current power target in watts that the miner is controlling for.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.MiningApi();
apiInstance.getMiningTarget((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MiningTarget**](MiningTarget.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="startMining"></a>
# **startMining**
> MessageResponse startMining()



The start mining endpoint can be used to make the device start mining, into account the current power target of the system.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.MiningApi();
apiInstance.startMining((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="stopMining"></a>
# **stopMining**
> MessageResponse stopMining()



The stop mining endpoint can be used to stop the device from mining, going into a minimal power mode with only the control board running.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.MiningApi();
apiInstance.stopMining((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

