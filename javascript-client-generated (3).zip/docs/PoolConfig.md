# MiningDevelopmentKitApi.PoolConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
