# MiningDevelopmentKitApi.NetworkApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getNetwork**](NetworkApi.md#getNetwork) | **GET** /api/v1/network | 
[**setNetworkConfig**](NetworkApi.md#setNetworkConfig) | **PUT** /api/v1/network | 

<a name="getNetwork"></a>
# **getNetwork**
> NetworkInfo getNetwork()



The network GET endpoint provides information related to the network configuration of the miner including IP address, gateways, and MAC address.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.NetworkApi();
apiInstance.getNetwork((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="setNetworkConfig"></a>
# **setNetworkConfig**
> NetworkInfo setNetworkConfig(body)



The network PUT endpoint allows the user to change the configuration of the miner between DHCP and a static IP.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.NetworkApi();
let body = new MiningDevelopmentKitApi.NetworkConfig(); // NetworkConfig | 

apiInstance.setNetworkConfig(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NetworkConfig**](NetworkConfig.md)|  | 

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

