# MiningDevelopmentKitApi.SystemInformationApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getSystemStatus**](SystemInformationApi.md#getSystemStatus) | **GET** /api/v1/system/status | 

<a name="getSystemStatus"></a>
# **getSystemStatus**
> SystemStatuses getSystemStatus()



Get system statuses

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.SystemInformationApi();
apiInstance.getSystemStatus((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SystemStatuses**](SystemStatuses.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

