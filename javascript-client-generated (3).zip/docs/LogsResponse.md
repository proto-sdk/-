# MiningDevelopmentKitApi.LogsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**logs** | [**LogsResponseLogs**](LogsResponseLogs.md) |  | [optional] 
