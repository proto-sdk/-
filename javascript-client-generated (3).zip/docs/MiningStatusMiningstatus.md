# MiningDevelopmentKitApi.MiningStatusMiningstatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **String** | The indication will reveal whether the mining operation is currently active or has ceased | [optional] 
**miningUptimeS** | **Number** | The amount of time in seconds that has passed since the start of the mining operation. | [optional] 
**rebootUptimeS** | **Number** | The amount of time in seconds that has passed since the last reboot of the system. | [optional] 
**averageHashrateGhs** | **Number** | The average hash rate in giga-hashes per second, since the device started mining. average_hashrate_ghs &#x3D; Total hash count / (elapsed_time_s * 10^9) | [optional] 
**idealHashrateGhs** | **Number** | Expected hashrate determined by the current power level. | [optional] 
**powerUsageWatts** | **Number** | Amount of power being consumed by mining in watts. | [optional] 
**powerTargetWatts** | **Number** | Amount of power in watts for the system to target. | [optional] 
**averageEfficiencyJth** | **Number** | The average efficiency in joules per terahash, since the device started mining. | [optional] 
**averageAsicTempC** | **Number** | Average temperature of the ASICs in the mining device. | [optional] 
**averageHbTempC** | **Number** | Average temperature of the mining device. | [optional] 
**hwErrors** | **Number** | The number of hardware errors that have occurred during the mining operation. | [optional] 
**message** | **String** |  | [optional] 

<a name="StatusEnum"></a>
## Enum: StatusEnum

* `uninitialized` (value: `"Uninitialized"`)
* `poweringOn` (value: `"PoweringOn"`)
* `mining` (value: `"Mining"`)
* `degradedMining` (value: `"DegradedMining"`)
* `poweringOff` (value: `"PoweringOff"`)
* `stopped` (value: `"Stopped"`)
* `noPools` (value: `"NoPools"`)
* `error` (value: `"Error"`)

