# MiningDevelopmentKitApi.NetworkInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**networkInfo** | [**NetworkInfoNetworkinfo**](NetworkInfoNetworkinfo.md) |  | [optional] 
