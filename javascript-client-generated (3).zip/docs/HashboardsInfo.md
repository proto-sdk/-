# MiningDevelopmentKitApi.HashboardsInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hashboardsInfo** | [**[HashboardsInfoHashboardsinfo]**](HashboardsInfoHashboardsinfo.md) |  | [optional] 
