# MiningDevelopmentKitApi.MiningTarget

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**powerTargetWatts** | **Number** |  | [optional] 
