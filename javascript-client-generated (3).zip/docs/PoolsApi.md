# MiningDevelopmentKitApi.PoolsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createPools**](PoolsApi.md#createPools) | **POST** /api/v1/pools | 
[**deletePool**](PoolsApi.md#deletePool) | **DELETE** /api/v1/pools/{id} | 
[**editPool**](PoolsApi.md#editPool) | **PUT** /api/v1/pools/{id} | 
[**getPool**](PoolsApi.md#getPool) | **GET** /api/v1/pools/{id} | 
[**listPools**](PoolsApi.md#listPools) | **GET** /api/v1/pools | 
[**testPoolConnection**](PoolsApi.md#testPoolConnection) | **POST** /api/v1/pools/test-connection | 

<a name="createPools"></a>
# **createPools**
> MessageResponse createPools(opts)



The post pools endpoint allows up to three pools to be configured, replacing the previous pool configuration.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.PoolsApi();
let opts = { 
  'body': [new MiningDevelopmentKitApi.PoolConfigInner()] // [PoolConfigInner] | 
};
apiInstance.createPools(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**[PoolConfigInner]**](PoolConfigInner.md)|  | [optional] 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deletePool"></a>
# **deletePool**
> MessageResponse deletePool(id)



### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.PoolsApi();
let id = 56; // Number | 

apiInstance.deletePool(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="editPool"></a>
# **editPool**
> PoolConfigResponse editPool(body, id)



Using this pool configuration endpoint, users can edit the properties of an existing pool.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.PoolsApi();
let body = new MiningDevelopmentKitApi.PoolConfigInner(); // PoolConfigInner | 
let id = 56; // Number | 

apiInstance.editPool(body, id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PoolConfigInner**](PoolConfigInner.md)|  | 
 **id** | **Number**|  | 

### Return type

[**PoolConfigResponse**](PoolConfigResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getPool"></a>
# **getPool**
> PoolResponse getPool(id)



### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.PoolsApi();
let id = 56; // Number | 

apiInstance.getPool(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**|  | 

### Return type

[**PoolResponse**](PoolResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="listPools"></a>
# **listPools**
> PoolsList listPools()



The get pools endpoint returns the full list of currently configured pools.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.PoolsApi();
apiInstance.listPools((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**PoolsList**](PoolsList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="testPoolConnection"></a>
# **testPoolConnection**
> MessageResponse testPoolConnection(body)



Used to test a pool connection

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.PoolsApi();
let body = new MiningDevelopmentKitApi.TestConnection(); // TestConnection | 

apiInstance.testPoolConnection(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TestConnection**](TestConnection.md)|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

