# MiningDevelopmentKitApi.PoolConfigResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
