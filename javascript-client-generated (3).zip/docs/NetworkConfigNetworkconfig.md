# MiningDevelopmentKitApi.NetworkConfigNetworkconfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dhcp** | **Boolean** |  | [optional] 
**ip** | **String** |  | [optional] 
**netmask** | **String** |  | [optional] 
**gateway** | **String** |  | [optional] 
