# MiningDevelopmentKitApi.HashboardStatsHashboardstats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hbSn** | **String** | Manufacturing serial number of the hashboard, used for subsequent API calls. | [optional] 
**hbId** | **String** | Internal ID of the hashboard, assigned to each hashboard starting from 0. | [optional] 
**status** | **String** | The current state or condition of the hashboard. | [optional] 
**powerUsageWatts** | **Number** | The power consumption of the hashboard in watts. | [optional] 
**voltageMv** | **Number** | The present voltage being supplied to the hashboard in millivolts. | [optional] 
**avgAsicTempC** | **Number** | Current average temperature of the hashboard in celsius. | [optional] 
**hashrateGhs** | **Number** | The current hash rate of the hashboard, measured in GH/s. It will be sum of all ASIC hashrate_ghs values. | [optional] 
**idealHashrateGhs** | **Number** | The expected hashrate is determined by the clock frequency of the all ASIC on the hash board, measured in GH/s. | [optional] 
**efficiencyJth** | **Number** | The efficiency of the hashboard in joules per terahash. | [optional] 
**asics** | [**[AsicStats]**](AsicStats.md) |  | [optional] 

<a name="StatusEnum"></a>
## Enum: StatusEnum

* `running` (value: `"Running"`)
* `stopped` (value: `"Stopped"`)
* `error` (value: `"Error"`)
* `overheated` (value: `"Overheated"`)
* `unknown` (value: `"Unknown"`)

