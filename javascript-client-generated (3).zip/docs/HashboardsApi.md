# MiningDevelopmentKitApi.HashboardsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAllHashboards**](HashboardsApi.md#getAllHashboards) | **GET** /api/v1/hashboards | 
[**getAsicStatus**](HashboardsApi.md#getAsicStatus) | **GET** /api/v1/hashboards/{hb_sn}/{asic_id} | 
[**getHashboardLogs**](HashboardsApi.md#getHashboardLogs) | **GET** /api/v1/hashboards/{hb_sn}/logs | 
[**getHashboardStatus**](HashboardsApi.md#getHashboardStatus) | **GET** /api/v1/hashboards/{hb_sn} | 

<a name="getAllHashboards"></a>
# **getAllHashboards**
> HashboardsInfo getAllHashboards()



The hashboards endpoint provides information about all of the hashboards connected to the system, including firmware version, MCU, ASIC count, API version, and hardware serial numbers.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.HashboardsApi();
apiInstance.getAllHashboards((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**HashboardsInfo**](HashboardsInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getAsicStatus"></a>
# **getAsicStatus**
> AsicStatsResponse getAsicStatus(hbSn, asicId)



The hashboard status endpoint returns current operating statistics for a single ASIC on the specified hashboard in the system based on serial number and ASIC ID.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.HashboardsApi();
let hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide statistics for.
let asicId = "asicId_example"; // String | The id of an ASIC to provide statistics for.

apiInstance.getAsicStatus(hbSn, asicId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide statistics for. | 
 **asicId** | **String**| The id of an ASIC to provide statistics for. | 

### Return type

[**AsicStatsResponse**](AsicStatsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getHashboardLogs"></a>
# **getHashboardLogs**
> LogsResponse getHashboardLogs(hbSn, opts)



The hashboard logs endpoint provides the most recent log lines from the specified hashboard.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.HashboardsApi();
let hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide statistics for.
let opts = { 
  'lines': 100 // Number | The number of most recent logs to return. Maximum of 500, defaults to 100.
};
apiInstance.getHashboardLogs(hbSn, opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide statistics for. | 
 **lines** | **Number**| The number of most recent logs to return. Maximum of 500, defaults to 100. | [optional] [default to 100]

### Return type

[**LogsResponse**](LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getHashboardStatus"></a>
# **getHashboardStatus**
> HashboardStats getHashboardStatus(hbSn)



The hashboard status endpoint returns current operating statistics for a single hashboard in the system based on its serial number.

### Example
```javascript
import {MiningDevelopmentKitApi} from 'mining_development_kit_api';

let apiInstance = new MiningDevelopmentKitApi.HashboardsApi();
let hbSn = "hbSn_example"; // String | The serial number of the hashboard to provide statistics for.

apiInstance.getHashboardStatus(hbSn, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **String**| The serial number of the hashboard to provide statistics for. | 

### Return type

[**HashboardStats**](HashboardStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

