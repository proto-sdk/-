# MiningDevelopmentKitApi.FanInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Each fan is assigned a unique identifier starting from 0. | [optional] 
**rpm** | **Number** | The fan&#x27;s current rotations per minute (RPM). | [optional] 
