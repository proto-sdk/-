# MiningDevelopmentKitApi.CoolingConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mode** | **String** | Parameter to define the cooling mode.  Modes:  - Off: Fans will be set to off for immersion cooling.  - Auto: Fans will be controlled based on miner temperature.  - Max: Fans will be run at full speed regardless of temperature. | [optional] 

<a name="ModeEnum"></a>
## Enum: ModeEnum

* `off` (value: `"Off"`)
* `auto` (value: `"Auto"`)
* `max` (value: `"Max"`)

