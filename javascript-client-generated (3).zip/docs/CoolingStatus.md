# MiningDevelopmentKitApi.CoolingStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**coolingStatus** | [**CoolingStatusCoolingstatus**](CoolingStatusCoolingstatus.md) |  | [optional] 
