# MiningDevelopmentKitApi.AsicStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Unique identifier assigned to each ASIC located on a hashboard, starting from 0. | [optional] 
**row** | **Number** | Physical row location of the ASIC on the hashboard. | [optional] 
**column** | **Number** | Physical column location of the ASIC on the hashboard. | [optional] 
**freqMhz** | **Number** | The frequency of the ASIC measured in megahertz. | [optional] 
**tempC** | **Number** | Current temperature of the ASIC in celsius | [optional] 
**hashrateGhs** | **Number** | The current hash rate of the ASIC, measured in GH/s. | [optional] 
**idealHashrateGhs** | **Number** | The expected hashrate determined by the clock frequency of the ASIC, measured in GH/s. | [optional] 
**errorRate** | **Number** | The number of times that the ASIC produced an incorrect hash or an error during a specific period of time.  Error Rate (%) &#x3D; (Number of incorrect hash / Total number of expected Hash) x 100% | [optional] 
