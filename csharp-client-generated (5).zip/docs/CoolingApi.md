# IO.Swagger.Api.CoolingApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetCooling**](CoolingApi.md#getcooling) | **GET** /api/v1/cooling | 
[**SetCoolingMode**](CoolingApi.md#setcoolingmode) | **PUT** /api/v1/cooling | 

<a name="getcooling"></a>
# **GetCooling**
> CoolingStatus GetCooling ()



The cooling endpoint provides information on the cooling status of the device, including mode and current fan RPM.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCoolingExample
    {
        public void main()
        {
            var apiInstance = new CoolingApi();

            try
            {
                CoolingStatus result = apiInstance.GetCooling();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CoolingApi.GetCooling: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**CoolingStatus**](CoolingStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="setcoolingmode"></a>
# **SetCoolingMode**
> CoolingConfig SetCoolingMode (CoolingConfig body)



The cooling configuration endpoint allows the user to control the fan mode.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SetCoolingModeExample
    {
        public void main()
        {
            var apiInstance = new CoolingApi();
            var body = new CoolingConfig(); // CoolingConfig | 

            try
            {
                CoolingConfig result = apiInstance.SetCoolingMode(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CoolingApi.SetCoolingMode: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CoolingConfig**](CoolingConfig.md)|  | 

### Return type

[**CoolingConfig**](CoolingConfig.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
