# IO.Swagger.Api.MiningApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**EditMiningTarget**](MiningApi.md#editminingtarget) | **PUT** /api/v1/mining/target | 
[**GetMiningStatus**](MiningApi.md#getminingstatus) | **GET** /api/v1/mining | 
[**GetMiningTarget**](MiningApi.md#getminingtarget) | **GET** /api/v1/mining/target | 
[**StartMining**](MiningApi.md#startmining) | **POST** /api/v1/mining/start | 
[**StopMining**](MiningApi.md#stopmining) | **POST** /api/v1/mining/stop | 

<a name="editminingtarget"></a>
# **EditMiningTarget**
> MiningTarget EditMiningTarget (MiningTarget body)



The mining target endpoint can be used to set a target power consumption for the miner. Once set, the mining device will operate to consume as close to that amount of power as possible. In the event that the device is unable to maintain its temperature within the allowed range, it may scale down and use less power.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class EditMiningTargetExample
    {
        public void main()
        {
            var apiInstance = new MiningApi();
            var body = new MiningTarget(); // MiningTarget | 

            try
            {
                MiningTarget result = apiInstance.EditMiningTarget(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MiningApi.EditMiningTarget: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**MiningTarget**](MiningTarget.md)|  | 

### Return type

[**MiningTarget**](MiningTarget.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getminingstatus"></a>
# **GetMiningStatus**
> MiningStatus GetMiningStatus ()



The mining endpoint provides summary information about the mining operations of the device. This includes device level hashrate statistics, overall miner status, and current power usage and target information.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetMiningStatusExample
    {
        public void main()
        {
            var apiInstance = new MiningApi();

            try
            {
                MiningStatus result = apiInstance.GetMiningStatus();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MiningApi.GetMiningStatus: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MiningStatus**](MiningStatus.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getminingtarget"></a>
# **GetMiningTarget**
> MiningTarget GetMiningTarget ()



The mining target endpoint returns the current power target in watts that the miner is controlling for.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetMiningTargetExample
    {
        public void main()
        {
            var apiInstance = new MiningApi();

            try
            {
                MiningTarget result = apiInstance.GetMiningTarget();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MiningApi.GetMiningTarget: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MiningTarget**](MiningTarget.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="startmining"></a>
# **StartMining**
> MessageResponse StartMining ()



The start mining endpoint can be used to make the device start mining, into account the current power target of the system.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class StartMiningExample
    {
        public void main()
        {
            var apiInstance = new MiningApi();

            try
            {
                MessageResponse result = apiInstance.StartMining();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MiningApi.StartMining: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="stopmining"></a>
# **StopMining**
> MessageResponse StopMining ()



The stop mining endpoint can be used to stop the device from mining, going into a minimal power mode with only the control board running.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class StopMiningExample
    {
        public void main()
        {
            var apiInstance = new MiningApi();

            try
            {
                MessageResponse result = apiInstance.StopMining();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling MiningApi.StopMining: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
