# IO.Swagger.Api.PoolsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreatePools**](PoolsApi.md#createpools) | **POST** /api/v1/pools | 
[**DeletePool**](PoolsApi.md#deletepool) | **DELETE** /api/v1/pools/{id} | 
[**EditPool**](PoolsApi.md#editpool) | **PUT** /api/v1/pools/{id} | 
[**GetPool**](PoolsApi.md#getpool) | **GET** /api/v1/pools/{id} | 
[**ListPools**](PoolsApi.md#listpools) | **GET** /api/v1/pools | 
[**TestPoolConnection**](PoolsApi.md#testpoolconnection) | **POST** /api/v1/pools/test-connection | 

<a name="createpools"></a>
# **CreatePools**
> MessageResponse CreatePools (List<PoolConfigInner> body = null)



The post pools endpoint allows up to three pools to be configured, replacing the previous pool configuration.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class CreatePoolsExample
    {
        public void main()
        {
            var apiInstance = new PoolsApi();
            var body = new List<PoolConfigInner>(); // List<PoolConfigInner> |  (optional) 

            try
            {
                MessageResponse result = apiInstance.CreatePools(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PoolsApi.CreatePools: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**List&lt;PoolConfigInner&gt;**](PoolConfigInner.md)|  | [optional] 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="deletepool"></a>
# **DeletePool**
> MessageResponse DeletePool (int? id)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class DeletePoolExample
    {
        public void main()
        {
            var apiInstance = new PoolsApi();
            var id = 56;  // int? | 

            try
            {
                MessageResponse result = apiInstance.DeletePool(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PoolsApi.DeletePool: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="editpool"></a>
# **EditPool**
> PoolConfigResponse EditPool (PoolConfigInner body, int? id)



Using this pool configuration endpoint, users can edit the properties of an existing pool.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class EditPoolExample
    {
        public void main()
        {
            var apiInstance = new PoolsApi();
            var body = new PoolConfigInner(); // PoolConfigInner | 
            var id = 56;  // int? | 

            try
            {
                PoolConfigResponse result = apiInstance.EditPool(body, id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PoolsApi.EditPool: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PoolConfigInner**](PoolConfigInner.md)|  | 
 **id** | **int?**|  | 

### Return type

[**PoolConfigResponse**](PoolConfigResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getpool"></a>
# **GetPool**
> PoolResponse GetPool (int? id)



### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetPoolExample
    {
        public void main()
        {
            var apiInstance = new PoolsApi();
            var id = 56;  // int? | 

            try
            {
                PoolResponse result = apiInstance.GetPool(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PoolsApi.GetPool: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int?**|  | 

### Return type

[**PoolResponse**](PoolResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="listpools"></a>
# **ListPools**
> PoolsList ListPools ()



The get pools endpoint returns the full list of currently configured pools.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ListPoolsExample
    {
        public void main()
        {
            var apiInstance = new PoolsApi();

            try
            {
                PoolsList result = apiInstance.ListPools();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PoolsApi.ListPools: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**PoolsList**](PoolsList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="testpoolconnection"></a>
# **TestPoolConnection**
> MessageResponse TestPoolConnection (TestConnection body)



Used to test a pool connection

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TestPoolConnectionExample
    {
        public void main()
        {
            var apiInstance = new PoolsApi();
            var body = new TestConnection(); // TestConnection | 

            try
            {
                MessageResponse result = apiInstance.TestPoolConnection(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PoolsApi.TestPoolConnection: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TestConnection**](TestConnection.md)|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
