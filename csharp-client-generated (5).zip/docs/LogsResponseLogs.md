# IO.Swagger.Model.LogsResponseLogs
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Source** | **string** | Source of logs. | [optional] 
**Lines** | **int?** | Number of lines returned. | [optional] 
**Content** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

