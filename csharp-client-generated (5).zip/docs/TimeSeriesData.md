# IO.Swagger.Model.TimeSeriesData
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Datetime** | **int?** | Unix time epoch. | [optional] 
**Value** | **int?** | Value of data requested at the given datetime. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

