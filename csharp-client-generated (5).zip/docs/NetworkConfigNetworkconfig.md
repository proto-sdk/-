# IO.Swagger.Model.NetworkConfigNetworkconfig
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Dhcp** | **bool?** |  | [optional] 
**Ip** | **string** |  | [optional] 
**Netmask** | **string** |  | [optional] 
**Gateway** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

