# IO.Swagger.Model.FanInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Each fan is assigned a unique identifier starting from 0. | [optional] 
**Rpm** | **int?** | The fan&#x27;s current rotations per minute (RPM). | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

