# IO.Swagger.Model.Aggregates
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Min** | **int?** | Minimum value in data. | [optional] 
**Avg** | **int?** | Average value in data. | [optional] 
**Max** | **int?** | Maximum value in data. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

