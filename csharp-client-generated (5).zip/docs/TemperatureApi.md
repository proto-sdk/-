# IO.Swagger.Api.TemperatureApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAsicTemperature**](TemperatureApi.md#getasictemperature) | **GET** /api/v1/temperature/{hb_sn}/{asic_id} | 
[**GetHashboardTemperature**](TemperatureApi.md#gethashboardtemperature) | **GET** /api/v1/temperature/{hb_sn} | 
[**GetMinerTemperature**](TemperatureApi.md#getminertemperature) | **GET** /api/v1/temperature | 

<a name="getasictemperature"></a>
# **GetAsicTemperature**
> TemperatureResponse GetAsicTemperature (string hbSn, int? asicId, string duration = null, string granularity = null)



The hashrate endpoint provides ASIC-level historical temperature operation data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAsicTemperatureExample
    {
        public void main()
        {
            var apiInstance = new TemperatureApi();
            var hbSn = hbSn_example;  // string | The serial number of the hashboard to provide temperature information for.
            var asicId = 56;  // int? | The ID of the ASIC to provide temperature information for.
            var duration = duration_example;  // string |  (optional)  (default to 12h)
            var granularity = granularity_example;  // string |  (optional)  (default to 1m)

            try
            {
                TemperatureResponse result = apiInstance.GetAsicTemperature(hbSn, asicId, duration, granularity);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TemperatureApi.GetAsicTemperature: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **string**| The serial number of the hashboard to provide temperature information for. | 
 **asicId** | **int?**| The ID of the ASIC to provide temperature information for. | 
 **duration** | **string**|  | [optional] [default to 12h]
 **granularity** | **string**|  | [optional] [default to 1m]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="gethashboardtemperature"></a>
# **GetHashboardTemperature**
> TemperatureResponse GetHashboardTemperature (string hbSn, string duration = null)



The temperature endpoint provides hashboard-level historical operation data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetHashboardTemperatureExample
    {
        public void main()
        {
            var apiInstance = new TemperatureApi();
            var hbSn = hbSn_example;  // string | The serial number of the hashboard to provide temperature information for.
            var duration = duration_example;  // string |  (optional)  (default to 12h)

            try
            {
                TemperatureResponse result = apiInstance.GetHashboardTemperature(hbSn, duration);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TemperatureApi.GetHashboardTemperature: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **string**| The serial number of the hashboard to provide temperature information for. | 
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getminertemperature"></a>
# **GetMinerTemperature**
> TemperatureResponse GetMinerTemperature (string duration = null)



The temperature endpoint provides miner-level historical temperature operation data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetMinerTemperatureExample
    {
        public void main()
        {
            var apiInstance = new TemperatureApi();
            var duration = duration_example;  // string |  (optional)  (default to 12h)

            try
            {
                TemperatureResponse result = apiInstance.GetMinerTemperature(duration);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TemperatureApi.GetMinerTemperature: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**TemperatureResponse**](TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
