# IO.Swagger.Api.NetworkApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetNetwork**](NetworkApi.md#getnetwork) | **GET** /api/v1/network | 
[**SetNetworkConfig**](NetworkApi.md#setnetworkconfig) | **PUT** /api/v1/network | 

<a name="getnetwork"></a>
# **GetNetwork**
> NetworkInfo GetNetwork ()



The network GET endpoint provides information related to the network configuration of the miner including IP address, gateways, and MAC address.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetNetworkExample
    {
        public void main()
        {
            var apiInstance = new NetworkApi();

            try
            {
                NetworkInfo result = apiInstance.GetNetwork();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling NetworkApi.GetNetwork: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="setnetworkconfig"></a>
# **SetNetworkConfig**
> NetworkInfo SetNetworkConfig (NetworkConfig body)



The network PUT endpoint allows the user to change the configuration of the miner between DHCP and a static IP.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SetNetworkConfigExample
    {
        public void main()
        {
            var apiInstance = new NetworkApi();
            var body = new NetworkConfig(); // NetworkConfig | 

            try
            {
                NetworkInfo result = apiInstance.SetNetworkConfig(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling NetworkApi.SetNetworkConfig: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NetworkConfig**](NetworkConfig.md)|  | 

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
