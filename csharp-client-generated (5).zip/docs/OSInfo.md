# IO.Swagger.Model.OSInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Version** | **string** |  | [optional] 
**GitHash** | **string** |  | [optional] 
**Variant** | **string** |  | [optional] 
**BuildDatetimeUtc** | **string** |  | [optional] 
**Machine** | **string** |  | [optional] 
**Status** | [**OSStatus**](OSStatus.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

