# IO.Swagger.Model.MiningStatusMiningstatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Status** | **string** | The indication will reveal whether the mining operation is currently active or has ceased | [optional] 
**MiningUptimeS** | **int?** | The amount of time in seconds that has passed since the start of the mining operation. | [optional] 
**RebootUptimeS** | **int?** | The amount of time in seconds that has passed since the last reboot of the system. | [optional] 
**AverageHashrateGhs** | **decimal?** | The average hash rate in giga-hashes per second, since the device started mining. average_hashrate_ghs &#x3D; Total hash count / (elapsed_time_s * 10^9) | [optional] 
**IdealHashrateGhs** | **decimal?** | Expected hashrate determined by the current power level. | [optional] 
**PowerUsageWatts** | **decimal?** | Amount of power being consumed by mining in watts. | [optional] 
**PowerTargetWatts** | **decimal?** | Amount of power in watts for the system to target. | [optional] 
**AverageEfficiencyJth** | **decimal?** | The average efficiency in joules per terahash, since the device started mining. | [optional] 
**AverageAsicTempC** | **decimal?** | Average temperature of the ASICs in the mining device. | [optional] 
**AverageHbTempC** | **decimal?** | Average temperature of the mining device. | [optional] 
**HwErrors** | **int?** | The number of hardware errors that have occurred during the mining operation. | [optional] 
**Message** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

