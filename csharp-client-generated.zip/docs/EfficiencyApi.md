# IO.Swagger.Api.EfficiencyApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetHashboardEfficiency**](EfficiencyApi.md#gethashboardefficiency) | **GET** /api/v1/efficiency/{hb_sn} | 
[**GetMinerEfficiency**](EfficiencyApi.md#getminerefficiency) | **GET** /api/v1/efficiency | 

<a name="gethashboardefficiency"></a>
# **GetHashboardEfficiency**
> EfficiencyResponse GetHashboardEfficiency (string hbSn, string duration = null)



The efficiency endpoint provides hashboard-level historical operation data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetHashboardEfficiencyExample
    {
        public void main()
        {
            var apiInstance = new EfficiencyApi();
            var hbSn = hbSn_example;  // string | The serial number of the hashboard to provide power information for.
            var duration = duration_example;  // string |  (optional)  (default to 12h)

            try
            {
                EfficiencyResponse result = apiInstance.GetHashboardEfficiency(hbSn, duration);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EfficiencyApi.GetHashboardEfficiency: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **string**| The serial number of the hashboard to provide power information for. | 
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**EfficiencyResponse**](EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getminerefficiency"></a>
# **GetMinerEfficiency**
> EfficiencyResponse GetMinerEfficiency (string duration = null)



The efficiency endpoint provides miner-level historical power operation data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetMinerEfficiencyExample
    {
        public void main()
        {
            var apiInstance = new EfficiencyApi();
            var duration = duration_example;  // string |  (optional)  (default to 12h)

            try
            {
                EfficiencyResponse result = apiInstance.GetMinerEfficiency(duration);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling EfficiencyApi.GetMinerEfficiency: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**EfficiencyResponse**](EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
