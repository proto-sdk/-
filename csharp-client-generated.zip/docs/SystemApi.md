# IO.Swagger.Api.SystemApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetSystemInfo**](SystemApi.md#getsysteminfo) | **GET** /api/v1/system | 
[**GetSystemLogs**](SystemApi.md#getsystemlogs) | **GET** /api/v1/system/logs | 
[**LocateSystem**](SystemApi.md#locatesystem) | **POST** /api/v1/system/locate | 
[**RebootSystem**](SystemApi.md#rebootsystem) | **POST** /api/v1/system/reboot | 

<a name="getsysteminfo"></a>
# **GetSystemInfo**
> SystemInfo GetSystemInfo ()



The system endpoint provides information related to the control board including OS, software, and hardware component details.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetSystemInfoExample
    {
        public void main()
        {
            var apiInstance = new SystemApi();

            try
            {
                SystemInfo result = apiInstance.GetSystemInfo();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SystemApi.GetSystemInfo: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SystemInfo**](SystemInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getsystemlogs"></a>
# **GetSystemLogs**
> LogsResponse GetSystemLogs (int? lines = null, string source = null)



The logs endpoint provides the most recent log lines from a given source, either OS, pool software, or miner logs.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetSystemLogsExample
    {
        public void main()
        {
            var apiInstance = new SystemApi();
            var lines = 56;  // int? | Number of log lines to return from the tail of the log, up to a maximum of 10000 lines. Defaults to 100 lines. (optional)  (default to 100)
            var source = source_example;  // string | Source of logs to fetch. Defaults to miner software logs. (optional)  (default to miner_sw)

            try
            {
                LogsResponse result = apiInstance.GetSystemLogs(lines, source);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SystemApi.GetSystemLogs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lines** | **int?**| Number of log lines to return from the tail of the log, up to a maximum of 10000 lines. Defaults to 100 lines. | [optional] [default to 100]
 **source** | **string**| Source of logs to fetch. Defaults to miner software logs. | [optional] [default to miner_sw]

### Return type

[**LogsResponse**](LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="locatesystem"></a>
# **LocateSystem**
> MessageResponse LocateSystem (int? ledOnTime = null)



The locate system endpoint can be used to flash the indicator LED on the control board to assist in finding the miner.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class LocateSystemExample
    {
        public void main()
        {

            var apiInstance = new SystemApi();
            var ledOnTime = 56;  // int? | The duration in seconds for which to turn on the LED, with a max value of 300 seconds. If not specified, a default value of 30 seconds will be used. Requests made while the LED is on will be ignored. (optional)  (default to 30)

            try
            {
                MessageResponse result = apiInstance.LocateSystem(ledOnTime);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SystemApi.LocateSystem: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ledOnTime** | **int?**| The duration in seconds for which to turn on the LED, with a max value of 300 seconds. If not specified, a default value of 30 seconds will be used. Requests made while the LED is on will be ignored. | [optional] [default to 30]

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="rebootsystem"></a>
# **RebootSystem**
> MessageResponse RebootSystem ()



The reboot endpoint can be used to reboot the entire system.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class RebootSystemExample
    {
        public void main()
        {

            var apiInstance = new SystemApi();

            try
            {
                MessageResponse result = apiInstance.RebootSystem();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SystemApi.RebootSystem: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
