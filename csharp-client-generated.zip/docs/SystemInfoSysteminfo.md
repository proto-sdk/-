# IO.Swagger.Model.SystemInfoSysteminfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Os** | [**OSInfo**](OSInfo.md) |  | [optional] 
**PoolInterfaceSw** | [**SWInfo**](SWInfo.md) |  | [optional] 
**MiningDriverSw** | [**SWInfo**](SWInfo.md) |  | [optional] 
**WebServer** | [**SWInfo**](SWInfo.md) |  | [optional] 
**UptimeSeconds** | **long?** |  | [optional] 
**Board** | **string** |  | [optional] 
**Soc** | **string** |  | [optional] 
**CbSn** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

