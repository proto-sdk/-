# IO.Swagger.Model.NotificationError
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Source** | **string** |  | [optional] 
**ComponentIndex** | **int?** |  | [optional] 
**HashboardIndex** | **int?** |  | [optional] 
**AsicIndex** | **int?** |  | [optional] 
**ErrorCode** | **string** |  | [optional] 
**InsertedAt** | **int?** |  | [optional] 
**ExpiredAt** | **int?** |  | [optional] 
**ErrorLevel** | **string** |  | [optional] 
**Message** | **string** |  | [optional] 
**Details** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

