# IO.Swagger.Model.FWInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Version** | **string** |  | [optional] 
**GitHash** | **string** |  | [optional] 
**ImageHash** | **string** |  | [optional] 
**Build** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

