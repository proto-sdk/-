# IO.Swagger.Api.PowerApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetHashboardPower**](PowerApi.md#gethashboardpower) | **GET** /api/v1/power/{hb_sn} | 
[**GetMinerPower**](PowerApi.md#getminerpower) | **GET** /api/v1/power | 

<a name="gethashboardpower"></a>
# **GetHashboardPower**
> PowerResponse GetHashboardPower (string hbSn, string duration = null)



The power endpoint provides hashboard-level historical operation data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetHashboardPowerExample
    {
        public void main()
        {
            var apiInstance = new PowerApi();
            var hbSn = hbSn_example;  // string | The serial number of the hashboard to provide power information for.
            var duration = duration_example;  // string |  (optional)  (default to 12h)

            try
            {
                PowerResponse result = apiInstance.GetHashboardPower(hbSn, duration);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PowerApi.GetHashboardPower: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **string**| The serial number of the hashboard to provide power information for. | 
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**PowerResponse**](PowerResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getminerpower"></a>
# **GetMinerPower**
> PowerResponse GetMinerPower (string duration = null)



The power endpoint provides miner-level historical power operation data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetMinerPowerExample
    {
        public void main()
        {
            var apiInstance = new PowerApi();
            var duration = duration_example;  // string |  (optional)  (default to 12h)

            try
            {
                PowerResponse result = apiInstance.GetMinerPower(duration);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PowerApi.GetMinerPower: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**PowerResponse**](PowerResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
