# IO.Swagger.Api.HashboardsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAllHashboards**](HashboardsApi.md#getallhashboards) | **GET** /api/v1/hashboards | 
[**GetAsicStatus**](HashboardsApi.md#getasicstatus) | **GET** /api/v1/hashboards/{hb_sn}/{asic_id} | 
[**GetHashboardLogs**](HashboardsApi.md#gethashboardlogs) | **GET** /api/v1/hashboards/{hb_sn}/logs | 
[**GetHashboardStatus**](HashboardsApi.md#gethashboardstatus) | **GET** /api/v1/hashboards/{hb_sn} | 

<a name="getallhashboards"></a>
# **GetAllHashboards**
> HashboardsInfo GetAllHashboards ()



The hashboards endpoint provides information about all of the hashboards connected to the system, including firmware version, MCU, ASIC count, API version, and hardware serial numbers.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAllHashboardsExample
    {
        public void main()
        {
            var apiInstance = new HashboardsApi();

            try
            {
                HashboardsInfo result = apiInstance.GetAllHashboards();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling HashboardsApi.GetAllHashboards: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**HashboardsInfo**](HashboardsInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getasicstatus"></a>
# **GetAsicStatus**
> AsicStatsResponse GetAsicStatus (string hbSn, string asicId)



The hashboard status endpoint returns current operating statistics for a single ASIC on the specified hashboard in the system based on serial number and ASIC ID.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAsicStatusExample
    {
        public void main()
        {
            var apiInstance = new HashboardsApi();
            var hbSn = hbSn_example;  // string | The serial number of the hashboard to provide statistics for.
            var asicId = asicId_example;  // string | The id of an ASIC to provide statistics for.

            try
            {
                AsicStatsResponse result = apiInstance.GetAsicStatus(hbSn, asicId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling HashboardsApi.GetAsicStatus: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **string**| The serial number of the hashboard to provide statistics for. | 
 **asicId** | **string**| The id of an ASIC to provide statistics for. | 

### Return type

[**AsicStatsResponse**](AsicStatsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="gethashboardlogs"></a>
# **GetHashboardLogs**
> LogsResponse GetHashboardLogs (string hbSn, int? lines = null)



The hashboard logs endpoint provides the most recent log lines from the specified hashboard.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetHashboardLogsExample
    {
        public void main()
        {
            var apiInstance = new HashboardsApi();
            var hbSn = hbSn_example;  // string | The serial number of the hashboard to provide statistics for.
            var lines = 56;  // int? | The number of most recent logs to return. Maximum of 500, defaults to 100. (optional)  (default to 100)

            try
            {
                LogsResponse result = apiInstance.GetHashboardLogs(hbSn, lines);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling HashboardsApi.GetHashboardLogs: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **string**| The serial number of the hashboard to provide statistics for. | 
 **lines** | **int?**| The number of most recent logs to return. Maximum of 500, defaults to 100. | [optional] [default to 100]

### Return type

[**LogsResponse**](LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="gethashboardstatus"></a>
# **GetHashboardStatus**
> HashboardStats GetHashboardStatus (string hbSn)



The hashboard status endpoint returns current operating statistics for a single hashboard in the system based on its serial number.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetHashboardStatusExample
    {
        public void main()
        {
            var apiInstance = new HashboardsApi();
            var hbSn = hbSn_example;  // string | The serial number of the hashboard to provide statistics for.

            try
            {
                HashboardStats result = apiInstance.GetHashboardStatus(hbSn);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling HashboardsApi.GetHashboardStatus: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **string**| The serial number of the hashboard to provide statistics for. | 

### Return type

[**HashboardStats**](HashboardStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
