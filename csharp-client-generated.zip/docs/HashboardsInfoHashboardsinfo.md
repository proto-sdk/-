# IO.Swagger.Model.HashboardsInfoHashboardsinfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HbSn** | **string** | Hashboard serial number. | [optional] 
**Firmware** | [**FWInfo**](FWInfo.md) |  | [optional] 
**Bootloader** | [**FWInfo**](FWInfo.md) |  | [optional] 
**ApiVersion** | **string** |  | [optional] 
**Board** | **string** |  | [optional] 
**ChipId** | **string** |  | [optional] 
**MiningAsic** | **string** |  | [optional] 
**MiningAsicCount** | **int?** | Number of asics on the hashboard. | [optional] 
**TempSensorCount** | **int?** | Number of temperature sensors on the hashboard. | [optional] 
**Port** | **int?** | The USB port number the hashboard is connected to. | [optional] 
**EcLogsPath** | **string** | The absolute path where EC logs are stored. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

