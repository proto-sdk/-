# IO.Swagger.Model.TemperatureResponseTemperaturedata
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Duration** | **string** | Duration of temperature data returned. | [optional] 
**Data** | [**List&lt;TimeSeriesData&gt;**](TimeSeriesData.md) |  | [optional] 
**Aggregates** | [**Aggregates**](Aggregates.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

