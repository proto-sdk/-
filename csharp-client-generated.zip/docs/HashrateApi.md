# IO.Swagger.Api.HashrateApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAsicHashrate**](HashrateApi.md#getasichashrate) | **GET** /api/v1/hashrate/{hb_sn}/{asic_id} | 
[**GetHashboardHashrate**](HashrateApi.md#gethashboardhashrate) | **GET** /api/v1/hashrate/{hb_sn} | 
[**GetMinerHashrate**](HashrateApi.md#getminerhashrate) | **GET** /api/v1/hashrate | 

<a name="getasichashrate"></a>
# **GetAsicHashrate**
> HashrateResponse GetAsicHashrate (string hbSn, int? asicId, string duration = null, string granularity = null)



The hashrate endpoint provides ASIC-level historical hashrate operation data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAsicHashrateExample
    {
        public void main()
        {
            var apiInstance = new HashrateApi();
            var hbSn = hbSn_example;  // string | The serial number of the hashboard to provide hashrate information for.
            var asicId = 56;  // int? | The ID of the ASIC to provide hashrate information for.
            var duration = duration_example;  // string |  (optional)  (default to 12h)
            var granularity = granularity_example;  // string |  (optional)  (default to 1m)

            try
            {
                HashrateResponse result = apiInstance.GetAsicHashrate(hbSn, asicId, duration, granularity);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling HashrateApi.GetAsicHashrate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **string**| The serial number of the hashboard to provide hashrate information for. | 
 **asicId** | **int?**| The ID of the ASIC to provide hashrate information for. | 
 **duration** | **string**|  | [optional] [default to 12h]
 **granularity** | **string**|  | [optional] [default to 1m]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="gethashboardhashrate"></a>
# **GetHashboardHashrate**
> HashrateResponse GetHashboardHashrate (string hbSn, string duration = null)



The hashrate endpoint provides hashboard-level historical operation data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetHashboardHashrateExample
    {
        public void main()
        {
            var apiInstance = new HashrateApi();
            var hbSn = hbSn_example;  // string | The serial number of the hashboard to provide hashrate information for.
            var duration = duration_example;  // string |  (optional)  (default to 12h)

            try
            {
                HashrateResponse result = apiInstance.GetHashboardHashrate(hbSn, duration);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling HashrateApi.GetHashboardHashrate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hbSn** | **string**| The serial number of the hashboard to provide hashrate information for. | 
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="getminerhashrate"></a>
# **GetMinerHashrate**
> HashrateResponse GetMinerHashrate (string duration = null)



The hashrate endpoint provides miner-level historical hashrate operation data.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetMinerHashrateExample
    {
        public void main()
        {
            var apiInstance = new HashrateApi();
            var duration = duration_example;  // string |  (optional)  (default to 12h)

            try
            {
                HashrateResponse result = apiInstance.GetMinerHashrate(duration);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling HashrateApi.GetMinerHashrate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**HashrateResponse**](HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
