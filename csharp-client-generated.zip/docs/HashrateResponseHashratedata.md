# IO.Swagger.Model.HashrateResponseHashratedata
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Duration** | **string** | Duration of hashrate data returned. | [optional] 
**Data** | [**List&lt;TimeSeriesData&gt;**](TimeSeriesData.md) |  | [optional] 
**Aggregates** | [**Aggregates**](Aggregates.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

