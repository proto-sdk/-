# NetworkConfigNetworkconfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dhcp** | **bool** |  | [optional] 
**ip** | **string** |  | [optional] 
**netmask** | **string** |  | [optional] 
**gateway** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

