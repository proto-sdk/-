# CoolingConfig

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mode** | **string** | Parameter to define the cooling mode.  Modes:  - Off: Fans will be set to off for immersion cooling.  - Auto: Fans will be controlled based on miner temperature.  - Max: Fans will be run at full speed regardless of temperature. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

