# Swagger\Client\EfficiencyApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getHashboardEfficiency**](EfficiencyApi.md#gethashboardefficiency) | **GET** /api/v1/efficiency/{hb_sn} | 
[**getMinerEfficiency**](EfficiencyApi.md#getminerefficiency) | **GET** /api/v1/efficiency | 

# **getHashboardEfficiency**
> \Swagger\Client\Model\EfficiencyResponse getHashboardEfficiency($hb_sn, $duration)



The efficiency endpoint provides hashboard-level historical operation data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\EfficiencyApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$hb_sn = "hb_sn_example"; // string | The serial number of the hashboard to provide power information for.
$duration = "12h"; // string | 

try {
    $result = $apiInstance->getHashboardEfficiency($hb_sn, $duration);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling EfficiencyApi->getHashboardEfficiency: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **string**| The serial number of the hashboard to provide power information for. |
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**\Swagger\Client\Model\EfficiencyResponse**](../Model/EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getMinerEfficiency**
> \Swagger\Client\Model\EfficiencyResponse getMinerEfficiency($duration)



The efficiency endpoint provides miner-level historical power operation data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\EfficiencyApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$duration = "12h"; // string | 

try {
    $result = $apiInstance->getMinerEfficiency($duration);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling EfficiencyApi->getMinerEfficiency: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**\Swagger\Client\Model\EfficiencyResponse**](../Model/EfficiencyResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

