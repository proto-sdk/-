# Swagger\Client\PowerApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getHashboardPower**](PowerApi.md#gethashboardpower) | **GET** /api/v1/power/{hb_sn} | 
[**getMinerPower**](PowerApi.md#getminerpower) | **GET** /api/v1/power | 

# **getHashboardPower**
> \Swagger\Client\Model\PowerResponse getHashboardPower($hb_sn, $duration)



The power endpoint provides hashboard-level historical operation data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\PowerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$hb_sn = "hb_sn_example"; // string | The serial number of the hashboard to provide power information for.
$duration = "12h"; // string | 

try {
    $result = $apiInstance->getHashboardPower($hb_sn, $duration);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PowerApi->getHashboardPower: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **string**| The serial number of the hashboard to provide power information for. |
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**\Swagger\Client\Model\PowerResponse**](../Model/PowerResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getMinerPower**
> \Swagger\Client\Model\PowerResponse getMinerPower($duration)



The power endpoint provides miner-level historical power operation data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\PowerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$duration = "12h"; // string | 

try {
    $result = $apiInstance->getMinerPower($duration);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PowerApi->getMinerPower: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**\Swagger\Client\Model\PowerResponse**](../Model/PowerResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

