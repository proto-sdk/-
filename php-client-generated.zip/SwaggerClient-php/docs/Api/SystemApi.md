# Swagger\Client\SystemApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getSystemInfo**](SystemApi.md#getsysteminfo) | **GET** /api/v1/system | 
[**getSystemLogs**](SystemApi.md#getsystemlogs) | **GET** /api/v1/system/logs | 
[**locateSystem**](SystemApi.md#locatesystem) | **POST** /api/v1/system/locate | 
[**rebootSystem**](SystemApi.md#rebootsystem) | **POST** /api/v1/system/reboot | 

# **getSystemInfo**
> \Swagger\Client\Model\SystemInfo getSystemInfo()



The system endpoint provides information related to the control board including OS, software, and hardware component details.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\SystemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getSystemInfo();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SystemApi->getSystemInfo: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\SystemInfo**](../Model/SystemInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getSystemLogs**
> \Swagger\Client\Model\LogsResponse getSystemLogs($lines, $source)



The logs endpoint provides the most recent log lines from a given source, either OS, pool software, or miner logs.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\SystemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$lines = 100; // int | Number of log lines to return from the tail of the log, up to a maximum of 10000 lines. Defaults to 100 lines.
$source = "miner_sw"; // string | Source of logs to fetch. Defaults to miner software logs.

try {
    $result = $apiInstance->getSystemLogs($lines, $source);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SystemApi->getSystemLogs: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lines** | **int**| Number of log lines to return from the tail of the log, up to a maximum of 10000 lines. Defaults to 100 lines. | [optional] [default to 100]
 **source** | **string**| Source of logs to fetch. Defaults to miner software logs. | [optional] [default to miner_sw]

### Return type

[**\Swagger\Client\Model\LogsResponse**](../Model/LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **locateSystem**
> \Swagger\Client\Model\MessageResponse locateSystem($led_on_time)



The locate system endpoint can be used to flash the indicator LED on the control board to assist in finding the miner.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\SystemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$led_on_time = 30; // int | The duration in seconds for which to turn on the LED, with a max value of 300 seconds. If not specified, a default value of 30 seconds will be used. Requests made while the LED is on will be ignored.

try {
    $result = $apiInstance->locateSystem($led_on_time);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SystemApi->locateSystem: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **led_on_time** | **int**| The duration in seconds for which to turn on the LED, with a max value of 300 seconds. If not specified, a default value of 30 seconds will be used. Requests made while the LED is on will be ignored. | [optional] [default to 30]

### Return type

[**\Swagger\Client\Model\MessageResponse**](../Model/MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **rebootSystem**
> \Swagger\Client\Model\MessageResponse rebootSystem()



The reboot endpoint can be used to reboot the entire system.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\SystemApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->rebootSystem();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SystemApi->rebootSystem: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\MessageResponse**](../Model/MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

