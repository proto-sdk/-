# Swagger\Client\PoolsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createPools**](PoolsApi.md#createpools) | **POST** /api/v1/pools | 
[**deletePool**](PoolsApi.md#deletepool) | **DELETE** /api/v1/pools/{id} | 
[**editPool**](PoolsApi.md#editpool) | **PUT** /api/v1/pools/{id} | 
[**getPool**](PoolsApi.md#getpool) | **GET** /api/v1/pools/{id} | 
[**listPools**](PoolsApi.md#listpools) | **GET** /api/v1/pools | 
[**testPoolConnection**](PoolsApi.md#testpoolconnection) | **POST** /api/v1/pools/test-connection | 

# **createPools**
> \Swagger\Client\Model\MessageResponse createPools($body)



The post pools endpoint allows up to three pools to be configured, replacing the previous pool configuration.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\PoolsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = array(new \Swagger\Client\Model\PoolConfigInner()); // \Swagger\Client\Model\PoolConfigInner[] | 

try {
    $result = $apiInstance->createPools($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PoolsApi->createPools: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\PoolConfigInner[]**](../Model/PoolConfigInner.md)|  | [optional]

### Return type

[**\Swagger\Client\Model\MessageResponse**](../Model/MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **deletePool**
> \Swagger\Client\Model\MessageResponse deletePool($id)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\PoolsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$id = 56; // int | 

try {
    $result = $apiInstance->deletePool($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PoolsApi->deletePool: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  |

### Return type

[**\Swagger\Client\Model\MessageResponse**](../Model/MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **editPool**
> \Swagger\Client\Model\PoolConfigResponse editPool($body, $id)



Using this pool configuration endpoint, users can edit the properties of an existing pool.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\PoolsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\PoolConfigInner(); // \Swagger\Client\Model\PoolConfigInner | 
$id = 56; // int | 

try {
    $result = $apiInstance->editPool($body, $id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PoolsApi->editPool: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\PoolConfigInner**](../Model/PoolConfigInner.md)|  |
 **id** | **int**|  |

### Return type

[**\Swagger\Client\Model\PoolConfigResponse**](../Model/PoolConfigResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getPool**
> \Swagger\Client\Model\PoolResponse getPool($id)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\PoolsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$id = 56; // int | 

try {
    $result = $apiInstance->getPool($id);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PoolsApi->getPool: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  |

### Return type

[**\Swagger\Client\Model\PoolResponse**](../Model/PoolResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **listPools**
> \Swagger\Client\Model\PoolsList listPools()



The get pools endpoint returns the full list of currently configured pools.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\PoolsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->listPools();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PoolsApi->listPools: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\PoolsList**](../Model/PoolsList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **testPoolConnection**
> \Swagger\Client\Model\MessageResponse testPoolConnection($body)



Used to test a pool connection

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\PoolsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$body = new \Swagger\Client\Model\TestConnection(); // \Swagger\Client\Model\TestConnection | 

try {
    $result = $apiInstance->testPoolConnection($body);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PoolsApi->testPoolConnection: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**\Swagger\Client\Model\TestConnection**](../Model/TestConnection.md)|  |

### Return type

[**\Swagger\Client\Model\MessageResponse**](../Model/MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

