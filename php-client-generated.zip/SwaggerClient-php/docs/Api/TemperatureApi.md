# Swagger\Client\TemperatureApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAsicTemperature**](TemperatureApi.md#getasictemperature) | **GET** /api/v1/temperature/{hb_sn}/{asic_id} | 
[**getHashboardTemperature**](TemperatureApi.md#gethashboardtemperature) | **GET** /api/v1/temperature/{hb_sn} | 
[**getMinerTemperature**](TemperatureApi.md#getminertemperature) | **GET** /api/v1/temperature | 

# **getAsicTemperature**
> \Swagger\Client\Model\TemperatureResponse getAsicTemperature($hb_sn, $asic_id, $duration, $granularity)



The hashrate endpoint provides ASIC-level historical temperature operation data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\TemperatureApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$hb_sn = "hb_sn_example"; // string | The serial number of the hashboard to provide temperature information for.
$asic_id = 56; // int | The ID of the ASIC to provide temperature information for.
$duration = "12h"; // string | 
$granularity = "1m"; // string | 

try {
    $result = $apiInstance->getAsicTemperature($hb_sn, $asic_id, $duration, $granularity);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TemperatureApi->getAsicTemperature: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **string**| The serial number of the hashboard to provide temperature information for. |
 **asic_id** | **int**| The ID of the ASIC to provide temperature information for. |
 **duration** | **string**|  | [optional] [default to 12h]
 **granularity** | **string**|  | [optional] [default to 1m]

### Return type

[**\Swagger\Client\Model\TemperatureResponse**](../Model/TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getHashboardTemperature**
> \Swagger\Client\Model\TemperatureResponse getHashboardTemperature($hb_sn, $duration)



The temperature endpoint provides hashboard-level historical operation data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\TemperatureApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$hb_sn = "hb_sn_example"; // string | The serial number of the hashboard to provide temperature information for.
$duration = "12h"; // string | 

try {
    $result = $apiInstance->getHashboardTemperature($hb_sn, $duration);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TemperatureApi->getHashboardTemperature: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **string**| The serial number of the hashboard to provide temperature information for. |
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**\Swagger\Client\Model\TemperatureResponse**](../Model/TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getMinerTemperature**
> \Swagger\Client\Model\TemperatureResponse getMinerTemperature($duration)



The temperature endpoint provides miner-level historical temperature operation data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\TemperatureApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$duration = "12h"; // string | 

try {
    $result = $apiInstance->getMinerTemperature($duration);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TemperatureApi->getMinerTemperature: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**\Swagger\Client\Model\TemperatureResponse**](../Model/TemperatureResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

