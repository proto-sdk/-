# Swagger\Client\SystemInformationApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getSystemStatus**](SystemInformationApi.md#getsystemstatus) | **GET** /api/v1/system/status | 

# **getSystemStatus**
> \Swagger\Client\Model\SystemStatuses getSystemStatus()



Get system statuses

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\SystemInformationApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->getSystemStatus();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SystemInformationApi->getSystemStatus: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\SystemStatuses**](../Model/SystemStatuses.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

