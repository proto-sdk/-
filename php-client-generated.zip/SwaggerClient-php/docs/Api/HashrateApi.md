# Swagger\Client\HashrateApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getAsicHashrate**](HashrateApi.md#getasichashrate) | **GET** /api/v1/hashrate/{hb_sn}/{asic_id} | 
[**getHashboardHashrate**](HashrateApi.md#gethashboardhashrate) | **GET** /api/v1/hashrate/{hb_sn} | 
[**getMinerHashrate**](HashrateApi.md#getminerhashrate) | **GET** /api/v1/hashrate | 

# **getAsicHashrate**
> \Swagger\Client\Model\HashrateResponse getAsicHashrate($hb_sn, $asic_id, $duration, $granularity)



The hashrate endpoint provides ASIC-level historical hashrate operation data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\HashrateApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$hb_sn = "hb_sn_example"; // string | The serial number of the hashboard to provide hashrate information for.
$asic_id = 56; // int | The ID of the ASIC to provide hashrate information for.
$duration = "12h"; // string | 
$granularity = "1m"; // string | 

try {
    $result = $apiInstance->getAsicHashrate($hb_sn, $asic_id, $duration, $granularity);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling HashrateApi->getAsicHashrate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **string**| The serial number of the hashboard to provide hashrate information for. |
 **asic_id** | **int**| The ID of the ASIC to provide hashrate information for. |
 **duration** | **string**|  | [optional] [default to 12h]
 **granularity** | **string**|  | [optional] [default to 1m]

### Return type

[**\Swagger\Client\Model\HashrateResponse**](../Model/HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getHashboardHashrate**
> \Swagger\Client\Model\HashrateResponse getHashboardHashrate($hb_sn, $duration)



The hashrate endpoint provides hashboard-level historical operation data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\HashrateApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$hb_sn = "hb_sn_example"; // string | The serial number of the hashboard to provide hashrate information for.
$duration = "12h"; // string | 

try {
    $result = $apiInstance->getHashboardHashrate($hb_sn, $duration);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling HashrateApi->getHashboardHashrate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **string**| The serial number of the hashboard to provide hashrate information for. |
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**\Swagger\Client\Model\HashrateResponse**](../Model/HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getMinerHashrate**
> \Swagger\Client\Model\HashrateResponse getMinerHashrate($duration)



The hashrate endpoint provides miner-level historical hashrate operation data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\HashrateApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$duration = "12h"; // string | 

try {
    $result = $apiInstance->getMinerHashrate($duration);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling HashrateApi->getMinerHashrate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duration** | **string**|  | [optional] [default to 12h]

### Return type

[**\Swagger\Client\Model\HashrateResponse**](../Model/HashrateResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

