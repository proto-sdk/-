# swagger_client.NetworkApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_network**](NetworkApi.md#get_network) | **GET** /api/v1/network | 
[**set_network_config**](NetworkApi.md#set_network_config) | **PUT** /api/v1/network | 

# **get_network**
> NetworkInfo get_network()



The network GET endpoint provides information related to the network configuration of the miner including IP address, gateways, and MAC address.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.NetworkApi()

try:
    api_response = api_instance.get_network()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NetworkApi->get_network: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_network_config**
> NetworkInfo set_network_config(body)



The network PUT endpoint allows the user to change the configuration of the miner between DHCP and a static IP.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.NetworkApi(swagger_client.ApiClient(configuration))
body = swagger_client.NetworkConfig() # NetworkConfig | 

try:
    api_response = api_instance.set_network_config(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NetworkApi->set_network_config: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**NetworkConfig**](NetworkConfig.md)|  | 

### Return type

[**NetworkInfo**](NetworkInfo.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

