# swagger_client.PoolsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_pools**](PoolsApi.md#create_pools) | **POST** /api/v1/pools | 
[**delete_pool**](PoolsApi.md#delete_pool) | **DELETE** /api/v1/pools/{id} | 
[**edit_pool**](PoolsApi.md#edit_pool) | **PUT** /api/v1/pools/{id} | 
[**get_pool**](PoolsApi.md#get_pool) | **GET** /api/v1/pools/{id} | 
[**list_pools**](PoolsApi.md#list_pools) | **GET** /api/v1/pools | 
[**test_pool_connection**](PoolsApi.md#test_pool_connection) | **POST** /api/v1/pools/test-connection | 

# **create_pools**
> MessageResponse create_pools(body=body)



The post pools endpoint allows up to three pools to be configured, replacing the previous pool configuration.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.PoolsApi(swagger_client.ApiClient(configuration))
body = [swagger_client.PoolConfigInner()] # list[PoolConfigInner] |  (optional)

try:
    api_response = api_instance.create_pools(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PoolsApi->create_pools: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[PoolConfigInner]**](PoolConfigInner.md)|  | [optional] 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_pool**
> MessageResponse delete_pool(id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.PoolsApi(swagger_client.ApiClient(configuration))
id = 56 # int | 

try:
    api_response = api_instance.delete_pool(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PoolsApi->delete_pool: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **edit_pool**
> PoolConfigResponse edit_pool(body, id)



Using this pool configuration endpoint, users can edit the properties of an existing pool.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = swagger_client.PoolsApi(swagger_client.ApiClient(configuration))
body = swagger_client.PoolConfigInner() # PoolConfigInner | 
id = 56 # int | 

try:
    api_response = api_instance.edit_pool(body, id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PoolsApi->edit_pool: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PoolConfigInner**](PoolConfigInner.md)|  | 
 **id** | **int**|  | 

### Return type

[**PoolConfigResponse**](PoolConfigResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_pool**
> PoolResponse get_pool(id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.PoolsApi()
id = 56 # int | 

try:
    api_response = api_instance.get_pool(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PoolsApi->get_pool: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

[**PoolResponse**](PoolResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list_pools**
> PoolsList list_pools()



The get pools endpoint returns the full list of currently configured pools.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.PoolsApi()

try:
    api_response = api_instance.list_pools()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PoolsApi->list_pools: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**PoolsList**](PoolsList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **test_pool_connection**
> MessageResponse test_pool_connection(body)



Used to test a pool connection

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.PoolsApi()
body = swagger_client.TestConnection() # TestConnection | 

try:
    api_response = api_instance.test_pool_connection(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PoolsApi->test_pool_connection: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**TestConnection**](TestConnection.md)|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

