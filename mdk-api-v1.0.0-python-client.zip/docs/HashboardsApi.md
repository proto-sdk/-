# swagger_client.HashboardsApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_all_hashboards**](HashboardsApi.md#get_all_hashboards) | **GET** /api/v1/hashboards | 
[**get_asic_status**](HashboardsApi.md#get_asic_status) | **GET** /api/v1/hashboards/{hb_sn}/{asic_id} | 
[**get_hashboard_logs**](HashboardsApi.md#get_hashboard_logs) | **GET** /api/v1/hashboards/{hb_sn}/logs | 
[**get_hashboard_status**](HashboardsApi.md#get_hashboard_status) | **GET** /api/v1/hashboards/{hb_sn} | 

# **get_all_hashboards**
> HashboardsInfo get_all_hashboards()



The hashboards endpoint provides information about all of the hashboards connected to the system, including firmware version, MCU, ASIC count, API version, and hardware serial numbers.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HashboardsApi()

try:
    api_response = api_instance.get_all_hashboards()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HashboardsApi->get_all_hashboards: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**HashboardsInfo**](HashboardsInfo.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_asic_status**
> AsicStatsResponse get_asic_status(hb_sn, asic_id)



The hashboard status endpoint returns current operating statistics for a single ASIC on the specified hashboard in the system based on serial number and ASIC ID.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HashboardsApi()
hb_sn = 'hb_sn_example' # str | The serial number of the hashboard to provide statistics for.
asic_id = 'asic_id_example' # str | The id of an ASIC to provide statistics for.

try:
    api_response = api_instance.get_asic_status(hb_sn, asic_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HashboardsApi->get_asic_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **str**| The serial number of the hashboard to provide statistics for. | 
 **asic_id** | **str**| The id of an ASIC to provide statistics for. | 

### Return type

[**AsicStatsResponse**](AsicStatsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_hashboard_logs**
> LogsResponse get_hashboard_logs(hb_sn, lines=lines)



The hashboard logs endpoint provides the most recent log lines from the specified hashboard.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HashboardsApi()
hb_sn = 'hb_sn_example' # str | The serial number of the hashboard to provide statistics for.
lines = 100 # int | The number of most recent logs to return. Maximum of 500, defaults to 100. (optional) (default to 100)

try:
    api_response = api_instance.get_hashboard_logs(hb_sn, lines=lines)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HashboardsApi->get_hashboard_logs: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **str**| The serial number of the hashboard to provide statistics for. | 
 **lines** | **int**| The number of most recent logs to return. Maximum of 500, defaults to 100. | [optional] [default to 100]

### Return type

[**LogsResponse**](LogsResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_hashboard_status**
> HashboardStats get_hashboard_status(hb_sn)



The hashboard status endpoint returns current operating statistics for a single hashboard in the system based on its serial number.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.HashboardsApi()
hb_sn = 'hb_sn_example' # str | The serial number of the hashboard to provide statistics for.

try:
    api_response = api_instance.get_hashboard_status(hb_sn)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HashboardsApi->get_hashboard_status: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **hb_sn** | **str**| The serial number of the hashboard to provide statistics for. | 

### Return type

[**HashboardStats**](HashboardStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

