# NotificationError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source** | **str** |  | [optional] 
**component_index** | **int** |  | [optional] 
**hashboard_index** | **int** |  | [optional] 
**asic_index** | **int** |  | [optional] 
**error_code** | **str** |  | [optional] 
**inserted_at** | **int** |  | [optional] 
**expired_at** | **int** |  | [optional] 
**error_level** | **str** |  | [optional] 
**message** | **str** |  | [optional] 
**details** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

