# Pool

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Each pool has a unique ID from 0 to 2, with 0 representing the highest priority and 2 representing the lowest priority. | [optional] 
**priority** | **int** | Connection priority for this pool. Lower numbers are higher priorities, with 0 being the maximum. Duplicate priorities are not allowed. | [optional] 
**url** | **str** | The pool URL is used to establish communication with the mining pool and it is essential that it includes the port information. | [optional] 
**user** | **str** | The user is an account that is used for authentication with the mining pool. In some cases, if the user has multiple mining devices, the pool may assign a worker name as the username for each mining device. | [optional] 
**status** | **str** | The status field indicates the state of the mining pool. An \&quot;Idle\&quot; status indiciates that the pool is available but not currently in use (due to priority). An \&quot;Active\&quot; status means that the pool is currently active. A \&quot;Dead\&quot; status indicates that the mining device is unable to establish a connection with the pool. | [optional] 
**protocol** | **str** | The protocol being used for communication with the mining pool. | [optional] 
**accepted** | **int** | The number of shares that have been accepted by the mining pool as valid solutions to a mining problem. | [optional] 
**rejected** | **int** | The number of shares submitted by the miner to the pool that were not accepted because they did not meet the required difficulty level or other criteria. | [optional] 
**invalid** | **int** | The number of shares the pool interface rejected due to being too low difficulty (did not forward to the pool). | [optional] 
**notifys_received** | **int** | The number of notify messages (new jobs) received from the pool. | [optional] 
**works_generated** | **int** | The number of works that were generated from the job notify messages. | [optional] 
**blocks_seen** | **int** | The number of mined blocks seen during mining (not necessarily found by miner). | [optional] 
**current_works** | **float** | The current number of works in use by the miner. | [optional] 
**current_difficulty** | **float** | The current difficulty from the pool. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

