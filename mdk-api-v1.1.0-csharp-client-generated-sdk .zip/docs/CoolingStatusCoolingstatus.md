# IO.Swagger.Model.CoolingStatusCoolingstatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FanMode** | **string** | Parameter to show the current fan mode. | [optional] 
**Fans** | [**List&lt;FanInfo&gt;**](FanInfo.md) | This will show speed of all fans in the system. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

