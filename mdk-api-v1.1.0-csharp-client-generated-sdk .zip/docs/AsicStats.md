# IO.Swagger.Model.AsicStats
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** | Unique identifier assigned to each ASIC located on a hashboard, starting from 0. | [optional] 
**Row** | **int?** | Physical row location of the ASIC on the hashboard. | [optional] 
**Column** | **int?** | Physical column location of the ASIC on the hashboard. | [optional] 
**FreqMhz** | [**decimal?**](BigDecimal.md) | The frequency of the ASIC measured in megahertz. | [optional] 
**TempC** | [**decimal?**](BigDecimal.md) | Current temperature of the ASIC in celsius | [optional] 
**HashrateGhs** | [**decimal?**](BigDecimal.md) | The current hash rate of the ASIC, measured in GH/s. | [optional] 
**IdealHashrateGhs** | [**decimal?**](BigDecimal.md) | The expected hashrate determined by the clock frequency of the ASIC, measured in GH/s. | [optional] 
**ErrorRate** | [**decimal?**](BigDecimal.md) | The number of times that the ASIC produced an incorrect hash or an error during a specific period of time.  Error Rate (%) &#x3D; (Number of incorrect hash / Total number of expected Hash) x 100% | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

