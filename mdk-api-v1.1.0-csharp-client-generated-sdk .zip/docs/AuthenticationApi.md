# IO.Swagger.Api.AuthenticationApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiV1AuthLogoutPost**](AuthenticationApi.md#apiv1authlogoutpost) | **POST** /api/v1/auth/logout | User logout
[**ApiV1AuthRefreshPost**](AuthenticationApi.md#apiv1authrefreshpost) | **POST** /api/v1/auth/refresh | Refresh JWT access token
[**Login**](AuthenticationApi.md#login) | **POST** /api/v1/auth/login | 
[**SetPassword**](AuthenticationApi.md#setpassword) | **PUT** /api/v1/auth/password | 

<a name="apiv1authlogoutpost"></a>
# **ApiV1AuthLogoutPost**
> MessageResponse ApiV1AuthLogoutPost (AuthTokens body)

User logout

Validates and blacklists JWT tokens, effectively logging out the user.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1AuthLogoutPostExample
    {
        public void main()
        {

            var apiInstance = new AuthenticationApi();
            var body = new AuthTokens(); // AuthTokens | 

            try
            {
                // User logout
                MessageResponse result = apiInstance.ApiV1AuthLogoutPost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthenticationApi.ApiV1AuthLogoutPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AuthTokens**](AuthTokens.md)|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1authrefreshpost"></a>
# **ApiV1AuthRefreshPost**
> RefreshResponse ApiV1AuthRefreshPost (RefreshRequest body)

Refresh JWT access token

Validates the provided refresh token and returns a new JWT access token.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1AuthRefreshPostExample
    {
        public void main()
        {
            var apiInstance = new AuthenticationApi();
            var body = new RefreshRequest(); // RefreshRequest | 

            try
            {
                // Refresh JWT access token
                RefreshResponse result = apiInstance.ApiV1AuthRefreshPost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthenticationApi.ApiV1AuthRefreshPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**RefreshRequest**](RefreshRequest.md)|  | 

### Return type

[**RefreshResponse**](RefreshResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="login"></a>
# **Login**
> AuthTokens Login (PasswordRequest body)



Authenticates a user using a password and returns a JWT access and refresh token pair.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class LoginExample
    {
        public void main()
        {
            var apiInstance = new AuthenticationApi();
            var body = new PasswordRequest(); // PasswordRequest | 

            try
            {
                AuthTokens result = apiInstance.Login(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthenticationApi.Login: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PasswordRequest**](PasswordRequest.md)|  | 

### Return type

[**AuthTokens**](AuthTokens.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="setpassword"></a>
# **SetPassword**
> MessageResponse SetPassword (PasswordRequest body)



The password endpoint allows users to set a password during onboarding

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SetPasswordExample
    {
        public void main()
        {
            var apiInstance = new AuthenticationApi();
            var body = new PasswordRequest(); // PasswordRequest | 

            try
            {
                MessageResponse result = apiInstance.SetPassword(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AuthenticationApi.SetPassword: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PasswordRequest**](PasswordRequest.md)|  | 

### Return type

[**MessageResponse**](MessageResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
