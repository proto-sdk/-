# IO.Swagger.Api.SystemInformationApi

All URIs are relative to *https://virtserver.swaggerhub.com/mining_development_kit_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetSystemStatus**](SystemInformationApi.md#getsystemstatus) | **GET** /api/v1/system/status | 

<a name="getsystemstatus"></a>
# **GetSystemStatus**
> SystemStatuses GetSystemStatus ()



Get system statuses

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetSystemStatusExample
    {
        public void main()
        {
            var apiInstance = new SystemInformationApi();

            try
            {
                SystemStatuses result = apiInstance.GetSystemStatus();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SystemInformationApi.GetSystemStatus: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SystemStatuses**](SystemStatuses.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
